/**
 * @file    safe_state.h
 * @brief   Watchdog, safe state, and startup sequencer.
 *
 * Safe state policy
 * -----------------
 * If any of the following conditions are detected, the ECU enters
 * SAFE_STATE_CUTOFF immediately:
 *   - Crank signal lost (no tooth for > CRANK_TIMEOUT_MS)
 *   - Engine sync lost (crank_is_synced() drops false after running)
 *   - RPM > RPM_LIMIT (rev limiter)
 *   - Scheduler overflow > SCHED_OVERFLOW_LIMIT (runaway condition)
 *
 * In SAFE_STATE_CUTOFF:
 *   - All injectors closed
 *   - All ignition coils discharged (fire then hold low)
 *   - Fuel pump relay off (if fitted)
 *
 * The ECU remains in CUTOFF until the crank signal recovers and a new
 * full sync is established (FULL_SYNC state).
 *
 * Startup sequence
 * ----------------
 * Modules must be initialised in this order:
 *
 *   1. hal_timer_init()          — timers before anything else
 *   2. hal_gpio_init()           — outputs to safe levels
 *   3. sensors_init()            — ADC ready
 *   4. crank_init()              — state zeroed
 *   5. engine_sync_init()        — state zeroed
 *   6. angle_tracker_init()      — state zeroed
 *   7. scheduler_init()          — queue cleared
 *   8. calibration_load()        — load cal from flash (CRC verified)
 *   9. fuel_init()               — wall-film state zeroed
 *  10. safe_state_init()         — arm watchdog, enter CRANKING state
 *  11. [enable capture IRQs]     — only after all state is ready
 *
 * safe_state_update() must be called from the main loop at ≥ 100 Hz.
 */

#ifndef SAFE_STATE_H
#define SAFE_STATE_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */

/** Crank signal timeout before entering safe state [ms]. */
#define CRANK_TIMEOUT_MS       200U

/** Maximum scheduler overflow events before safe state. */
#define SCHED_OVERFLOW_LIMIT   5U

/* -----------------------------------------------------------------------
 * States
 * ----------------------------------------------------------------------- */

typedef enum {
    ECU_STATE_INIT    = 0,  /**< Module not yet started              */
    ECU_STATE_CRANKING,     /**< Waiting for first sync              */
    ECU_STATE_RUNNING,      /**< Fully synced, normal operation      */
    ECU_STATE_CUTOFF,       /**< Safe state — fuel + ignition off    */
    ECU_STATE_FAULT         /**< Non-recoverable hardware fault      */
} ecu_state_t;

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise safe-state module and arm watchdog. [TASK ONLY] */
void safe_state_init(void);

/**
 * @brief  Periodic update — call from main loop at ≥ 100 Hz. [TASK ONLY]
 *         Checks crank timeout, RPM limit, scheduler overflow.
 *         Transitions state machine and acts on outputs.
 */
void safe_state_update(void);

/** @brief  Notify that a crank tooth was received (resets timeout). ISR-safe. */
void safe_state_notify_tooth(void);

/** @brief  Get current ECU operating state. ISR-safe. */
ecu_state_t safe_state_get(void);

/**
 * @brief  Force immediate safe state entry.
 *         Call from any fault handler (watchdog ISR, hard fault, etc.).
 *         ISR-safe.
 */
void safe_state_enter_cutoff(void);

/** @brief  true if fuel and ignition outputs are permitted. ISR-safe. */
bool safe_state_outputs_enabled(void);

#endif /* SAFE_STATE_H */
