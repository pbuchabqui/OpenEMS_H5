/**
 * @file    diagnostics.c
 * @brief   Fault code (DTC) management.
 */

#include "diagnostics.h"
#include "../hal/hal.h"
#include <string.h>

/* -----------------------------------------------------------------------
 * Active fault table
 * ----------------------------------------------------------------------- */

typedef struct {
    uint16_t dtc;
    uint8_t  cycles_active;   /* incremented each diagnostics_update() */
    bool     confirmed;
} fault_entry_t;

static fault_entry_t s_active[DIAG_MAX_ACTIVE_FAULTS];
static uint8_t       s_active_count = 0;

/* -----------------------------------------------------------------------
 * Confirmed faults — small array in retention RAM or flash-backed region
 * (For simplicity, kept in regular RAM here; connect to cal_flash later)
 * ----------------------------------------------------------------------- */

#define DIAG_MAX_CONFIRMED  32U
static uint16_t s_confirmed[DIAG_MAX_CONFIRMED];
static uint8_t  s_confirmed_count = 0;

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

static fault_entry_t *find_active(uint16_t dtc)
{
    for (uint8_t i = 0; i < s_active_count; i++)
        if (s_active[i].dtc == dtc) return &s_active[i];
    return NULL;
}

static bool is_confirmed(uint16_t dtc)
{
    for (uint8_t i = 0; i < s_confirmed_count; i++)
        if (s_confirmed[i] == dtc) return true;
    return false;
}

static void add_confirmed(uint16_t dtc)
{
    if (is_confirmed(dtc)) return;
    if (s_confirmed_count < DIAG_MAX_CONFIRMED)
        s_confirmed[s_confirmed_count++] = dtc;
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void diagnostics_init(void)
{
    memset(s_active,    0, sizeof(s_active));
    memset(s_confirmed, 0, sizeof(s_confirmed));
    s_active_count    = 0;
    s_confirmed_count = 0;
}

void diagnostics_set_fault(uint16_t dtc)
{
    if (dtc == DTC_NONE) return;

    hal_irq_state_t irqs = hal_enter_critical();

    fault_entry_t *e = find_active(dtc);
    if (!e)
    {
        if (s_active_count < DIAG_MAX_ACTIVE_FAULTS)
        {
            e = &s_active[s_active_count++];
            e->dtc           = dtc;
            e->cycles_active = 0;
            e->confirmed     = is_confirmed(dtc);
        }
    }

    hal_exit_critical(irqs);
}

void diagnostics_clear_fault(uint16_t dtc)
{
    hal_irq_state_t irqs = hal_enter_critical();

    for (uint8_t i = 0; i < s_active_count; i++)
    {
        if (s_active[i].dtc == dtc)
        {
            /* Compact array */
            s_active[i] = s_active[--s_active_count];
            break;
        }
    }

    hal_exit_critical(irqs);
}

void diagnostics_update(void)
{
    hal_irq_state_t irqs = hal_enter_critical();

    for (uint8_t i = 0; i < s_active_count; i++)
    {
        s_active[i].cycles_active++;
        if (s_active[i].cycles_active >= DIAG_CONFIRM_CYCLES
            && !s_active[i].confirmed)
        {
            add_confirmed(s_active[i].dtc);
            s_active[i].confirmed = true;
        }
    }

    hal_exit_critical(irqs);
}

bool diagnostics_fault_active(uint16_t dtc)
{
    hal_irq_state_t irqs = hal_enter_critical();
    bool found = (find_active(dtc) != NULL);
    hal_exit_critical(irqs);
    return found;
}

bool diagnostics_fault_confirmed(uint16_t dtc)
{
    hal_irq_state_t irqs = hal_enter_critical();
    bool found = is_confirmed(dtc);
    hal_exit_critical(irqs);
    return found;
}

void diagnostics_clear_confirmed(uint16_t dtc)
{
    hal_irq_state_t irqs = hal_enter_critical();
    for (uint8_t i = 0; i < s_confirmed_count; i++)
    {
        if (s_confirmed[i] == dtc)
        {
            s_confirmed[i] = s_confirmed[--s_confirmed_count];
            break;
        }
    }
    hal_exit_critical(irqs);
}

uint8_t diagnostics_active_count(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint8_t n = s_active_count;
    hal_exit_critical(irqs);
    return n;
}

uint8_t diagnostics_get_active(uint16_t *buf, uint8_t max)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint8_t n = (s_active_count < max) ? s_active_count : max;
    for (uint8_t i = 0; i < n; i++)
        buf[i] = s_active[i].dtc;
    hal_exit_critical(irqs);
    return n;
}

uint8_t diagnostics_get_confirmed(uint16_t *buf, uint8_t max)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint8_t n = (s_confirmed_count < max) ? s_confirmed_count : max;
    for (uint8_t i = 0; i < n; i++)
        buf[i] = s_confirmed[i];
    hal_exit_critical(irqs);
    return n;
}
