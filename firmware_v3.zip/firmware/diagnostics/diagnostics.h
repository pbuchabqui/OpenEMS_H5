/**
 * @file    diagnostics.h
 * @brief   Fault code (DTC) management.
 *
 * DTCs are stored in two places:
 *   - RAM: active faults (current ignition cycle)
 *   - Flash: confirmed faults (persist across resets, cleared explicitly)
 *
 * A fault becomes "confirmed" after being active for CONFIRM_CYCLES
 * consecutive engine cycles without clearing.
 *
 * All functions are ISR-safe.
 */

#ifndef DIAGNOSTICS_H
#define DIAGNOSTICS_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * DTC definitions
 * ----------------------------------------------------------------------- */

#define DTC_NONE                   0x0000U

/* Sensor faults */
#define DTC_MAP_SENSOR_FAIL        0x0101U
#define DTC_MAF_SENSOR_FAIL        0x0102U
#define DTC_TPS_SENSOR_FAIL        0x0103U
#define DTC_IAT_SENSOR_FAIL        0x0104U
#define DTC_ECT_SENSOR_FAIL        0x0105U
#define DTC_LAMBDA_SENSOR_FAIL     0x0106U
#define DTC_BATT_VOLTAGE_LOW       0x0107U
#define DTC_BATT_VOLTAGE_HIGH      0x0108U

/* Sync faults */
#define DTC_CRANK_SIGNAL_LOST      0x0201U
#define DTC_CAM_SYNC_FAIL          0x0202U
#define DTC_CAM_SIGNAL_LOST        0x0203U

/* Actuator faults */
#define DTC_KNOCK_SENSOR_FAIL      0x0301U
#define DTC_INJECTOR_FAULT         0x0302U
#define DTC_IGNITION_FAULT         0x0303U

/* Combustion faults */
#define DTC_MISFIRE_CYL0           0x0401U
#define DTC_MISFIRE_CYL1           0x0402U
#define DTC_MISFIRE_CYL2           0x0403U
#define DTC_MISFIRE_CYL3           0x0404U

/* System faults */
#define DTC_SCHEDULER_OVERFLOW     0x0501U
#define DTC_CAL_CRC_FAIL           0x0502U
#define DTC_RAM_FAULT              0x0503U

/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */

#define DIAG_MAX_ACTIVE_FAULTS   16U
#define DIAG_CONFIRM_CYCLES       3U

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise diagnostics module. [TASK ONLY] */
void diagnostics_init(void);

/**
 * @brief  Set a fault as active. ISR-safe.
 *         If fault persists for CONFIRM_CYCLES it becomes confirmed.
 */
void diagnostics_set_fault(uint16_t dtc);

/**
 * @brief  Clear an active fault. ISR-safe.
 *         Does NOT clear confirmed (flash-stored) faults.
 */
void diagnostics_clear_fault(uint16_t dtc);

/**
 * @brief  Periodic update — age active faults, promote to confirmed.
 *         Call from main loop at ~10 Hz. [TASK ONLY]
 */
void diagnostics_update(void);

/** @brief  true if the given DTC is currently active. ISR-safe. */
bool diagnostics_fault_active(uint16_t dtc);

/** @brief  true if the given DTC is confirmed (stored in flash). ISR-safe. */
bool diagnostics_fault_confirmed(uint16_t dtc);

/**
 * @brief  Clear a confirmed fault from flash. [TASK ONLY]
 *         Requires explicit mechanic action — not done automatically.
 */
void diagnostics_clear_confirmed(uint16_t dtc);

/** @brief  Number of currently active faults. ISR-safe. */
uint8_t diagnostics_active_count(void);

/** @brief  Fill buf with up to max active DTC codes. Returns count. */
uint8_t diagnostics_get_active(uint16_t *buf, uint8_t max);

/** @brief  Fill buf with up to max confirmed DTC codes. Returns count. */
uint8_t diagnostics_get_confirmed(uint16_t *buf, uint8_t max);

#endif /* DIAGNOSTICS_H */
