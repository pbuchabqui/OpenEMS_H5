/**
 * @file    safe_state.c
 * @brief   Watchdog, safe state, and startup sequencer.
 */

#include "safe_state.h"
#include "../engine/crank_decoder.h"
#include "../engine/engine_sync.h"
#include "../engine/event_scheduler.h"
#include "../hal/hal.h"
#include "../calibration/calibration_ids.h"

/* Bring in GPIO pin definitions for coils/injectors */
/* These match the pin arrays in event_scheduler.c   */
static const uint8_t IGN_PINS[4]    = { 10, 11, 12, 13 };
static const uint8_t INJECT_PINS[4] = { 20, 21, 22, 23 };

#define FUEL_PUMP_PIN   30U

/* -----------------------------------------------------------------------
 * Private state
 * ----------------------------------------------------------------------- */

static volatile ecu_state_t s_state             = ECU_STATE_INIT;
static volatile uint32_t    s_last_tooth_ts_ms  = 0;   /**< Last tooth [ms, from hal_timer/1000] */
static volatile bool        s_outputs_enabled   = false;

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

static void cut_all_outputs(void)
{
    /* Fire then hold-low all coils to discharge energy safely */
    for (uint8_t i = 0; i < 4U; i++)
    {
        hal_gpio_clear(IGN_PINS[i]);
    }

    /* Close all injectors immediately */
    for (uint8_t i = 0; i < 4U; i++)
    {
        hal_gpio_clear(INJECT_PINS[i]);
    }

    /* Fuel pump off */
    hal_gpio_clear(FUEL_PUMP_PIN);
}

static void enable_outputs(void)
{
    hal_gpio_set(FUEL_PUMP_PIN);
    s_outputs_enabled = true;
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void safe_state_init(void)
{
    cut_all_outputs();
    s_outputs_enabled = false;
    s_state           = ECU_STATE_CRANKING;
    s_last_tooth_ts_ms = hal_timer_get() / HAL_TIMER_TICKS_PER_MS;
}

void safe_state_update(void)
{
    uint32_t now_ms = hal_timer_get() / HAL_TIMER_TICKS_PER_MS;

    /* --- Already in cutoff or fault: stay there until re-sync ---------- */
    if (s_state == ECU_STATE_CUTOFF || s_state == ECU_STATE_FAULT)
    {
        cut_all_outputs();
        s_outputs_enabled = false;

        /* Allow recovery once full sync is re-established */
        if (engine_sync_get_state() == ENGINE_SYNC_FULL)
        {
            s_state = ECU_STATE_RUNNING;
            enable_outputs();
        }
        return;
    }

    /* --- Crank timeout check ------------------------------------------- */
    uint32_t elapsed_ms = now_ms - s_last_tooth_ts_ms;
    if (elapsed_ms > CRANK_TIMEOUT_MS)
    {
        safe_state_enter_cutoff();
        return;
    }

    /* --- Transition CRANKING → RUNNING on first full sync --------------- */
    if (s_state == ECU_STATE_CRANKING)
    {
        if (engine_sync_get_state() == ENGINE_SYNC_FULL)
        {
            s_state = ECU_STATE_RUNNING;
            enable_outputs();
        }
        return;
    }

    /* --- Running checks ------------------------------------------------- */
    if (s_state == ECU_STATE_RUNNING)
    {
        /* Sync loss check */
        if (engine_sync_get_state() != ENGINE_SYNC_FULL)
        {
            safe_state_enter_cutoff();
            return;
        }

        /* Scheduler overflow check */
        if (scheduler_get_overflow_count() > SCHED_OVERFLOW_LIMIT)
        {
            safe_state_enter_cutoff();
            return;
        }
    }
}

void safe_state_notify_tooth(void)
{
    /* Update last-tooth timestamp (convert µs → ms inline) */
    s_last_tooth_ts_ms = hal_timer_get() / HAL_TIMER_TICKS_PER_MS;

    /* Transition CRANKING state on first crank sync */
    if (s_state == ECU_STATE_CRANKING && crank_is_synced())
    {
        /* Stay in CRANKING until full cam sync — handled in safe_state_update() */
    }
}

ecu_state_t safe_state_get(void)
{
    hal_irq_state_t s = hal_enter_critical();
    ecu_state_t v = s_state;
    hal_exit_critical(s);
    return v;
}

void safe_state_enter_cutoff(void)
{
    s_state           = ECU_STATE_CUTOFF;
    s_outputs_enabled = false;
    cut_all_outputs();
}

bool safe_state_outputs_enabled(void)
{
    hal_irq_state_t s = hal_enter_critical();
    bool v = s_outputs_enabled;
    hal_exit_critical(s);
    return v;
}
