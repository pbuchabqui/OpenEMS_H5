/**
 * @file    hal.c
 * @brief   Hardware Abstraction Layer — STM32H562RGT6 implementation.
 *
 * Peripheral assignments:
 *   TIM2   — 32-bit free-running counter at 1 MHz (crank timestamps)
 *   TIM3   — input capture ch1 (crank), ch2 (cam)
 *   TIM4   — output compare ch1-ch4 (ignition coils cyl 0-3)
 *   TIM5   — output compare ch1-ch4 (injectors cyl 0-3)
 *   ADC1   — 7-channel scan with DMA (sensors + knock)
 *   IWDG   — independent watchdog, 200 ms timeout
 *   GPIOB  — injectors (pins 20-23 = PB4-PB7)
 *   GPIOC  — ignition (pins 10-13 = PC0-PC3)
 *
 * NVIC priority scheme (lower number = higher priority):
 *   0  — TIM3 input capture (crank/cam ISR)
 *   1  — TIM4/TIM5 compare (scheduler ISR)
 *   2  — ADC1 DMA (knock sample ISR)
 *   3  — all other ISRs
 *
 * NOTE: Register-level access uses CMSIS headers. Include path must
 *       contain STM32H562xx device headers from STM32CubeH5.
 */

#include "hal.h"
#include "stm32h5xx.h"   /* CMSIS device header — STM32CubeH5 */

/* -----------------------------------------------------------------------
 * Pin mapping
 *   Pins 0-9   reserved / not used by this HAL
 *   Pins 10-13 → PC0-PC3 (ignition coils)
 *   Pins 20-23 → PB4-PB7 (injectors)
 *   Pin  30    → PB8     (fuel pump relay)
 * ----------------------------------------------------------------------- */

static GPIO_TypeDef *pin_port(uint8_t pin)
{
    if (pin >= 10 && pin <= 13) return GPIOC;
    if (pin >= 20 && pin <= 23) return GPIOB;
    if (pin == 30)              return GPIOB;
    return NULL;
}

static uint32_t pin_mask(uint8_t pin)
{
    if (pin >= 10 && pin <= 13) return (1UL << (pin - 10));   /* PC0-PC3 */
    if (pin >= 20 && pin <= 23) return (1UL << (pin - 16));   /* PB4-PB7 */
    if (pin == 30)              return (1UL << 8);             /* PB8 */
    return 0;
}

/* -----------------------------------------------------------------------
 * Compare channel → timer + channel index
 * ch 0-3: TIM4 ch1-ch4 (ignition)
 * ch 4-7: TIM5 ch1-ch4 (injection)
 * ----------------------------------------------------------------------- */

static TIM_TypeDef *compare_timer(uint8_t ch)
{
    return (ch < 4U) ? TIM4 : TIM5;
}

static uint8_t compare_tim_ch(uint8_t ch)
{
    return (ch & 3U);   /* 0-3 within the timer */
}

/* -----------------------------------------------------------------------
 * Initialisation helpers
 * ----------------------------------------------------------------------- */

static void clock_enable(void)
{
    /* Enable GPIO clocks */
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN;

    /* Enable timer clocks */
    RCC->APB1ENR1 |= RCC_APB1ENR1_TIM2EN
                   | RCC_APB1ENR1_TIM3EN
                   | RCC_APB1ENR1_TIM4EN
                   | RCC_APB1ENR1_TIM5EN;

    /* Enable ADC clock */
    RCC->AHB2ENR |= RCC_AHB2ENR_ADC12EN;

    /* Enable DMA1 */
    RCC->AHB1ENR |= RCC_AHB1ENR_DMA1EN;

    __DSB();
}

static void gpio_init_outputs(void)
{
    /* PC0-PC3: push-pull output, no pull, medium speed, start low */
    GPIOC->MODER   &= ~(0xFFUL);          /* clear bits 0-7 */
    GPIOC->MODER   |=  (0x55UL);          /* output mode (01) for PC0-PC3 */
    GPIOC->OTYPER  &= ~(0x0FUL);          /* push-pull */
    GPIOC->OSPEEDR &= ~(0xFFUL);
    GPIOC->OSPEEDR |=  (0x55UL);          /* medium speed */
    GPIOC->PUPDR   &= ~(0xFFUL);          /* no pull */
    GPIOC->BSRR     =  (0x0FUL << 16);   /* reset PC0-PC3 (safe low) */

    /* PB4-PB7: same config for injectors */
    GPIOB->MODER   &= ~(0xFF00UL);
    GPIOB->MODER   |=  (0x5500UL);
    GPIOB->OTYPER  &= ~(0x00F0UL);
    GPIOB->OSPEEDR &= ~(0xFF00UL);
    GPIOB->OSPEEDR |=  (0x5500UL);
    GPIOB->PUPDR   &= ~(0xFF00UL);
    GPIOB->BSRR     =  (0x00F0UL << 16); /* reset PB4-PB7 */

    /* PB8: fuel pump relay */
    GPIOB->MODER   &= ~(3UL << 16);
    GPIOB->MODER   |=  (1UL << 16);      /* output */
    GPIOB->BSRR     =  (1UL << (8 + 16)); /* start low */
}

static void tim2_init_freerun(void)
{
    /*
     * TIM2 as 32-bit free-running counter at 1 MHz.
     * STM32H562 APB1 timer clock = 250 MHz (with PLL).
     * PSC = 249 → timer clock = 250 MHz / 250 = 1 MHz (1 tick = 1 µs).
     */
    TIM2->CR1   = 0;
    TIM2->PSC   = 249U;          /* 250 MHz / 250 = 1 MHz */
    TIM2->ARR   = 0xFFFFFFFFUL;  /* max count — 32-bit */
    TIM2->EGR   = TIM_EGR_UG;   /* apply prescaler */
    TIM2->SR    = 0;
    TIM2->CR1   = TIM_CR1_CEN;
}

static void tim3_init_capture(void)
{
    /*
     * TIM3 input capture:
     *   CH1 — crank signal (rising edge)
     *   CH2 — cam signal   (edge configured by hal_cam_set_polarity)
     *
     * Input pins must be configured as AF in GPIO (board-specific):
     *   TIM3_CH1 = PA6 (AF2), TIM3_CH2 = PA7 (AF2)
     */
    TIM3->CR1   = 0;
    TIM3->PSC   = 249U;         /* same 1 µs base as TIM2 */
    TIM3->ARR   = 0xFFFFUL;
    TIM3->EGR   = TIM_EGR_UG;
    TIM3->SR    = 0;

    /* CH1: capture on rising edge, no filter, no prescaler */
    TIM3->CCMR1 = (TIM_CCMR1_CC1S_0);          /* IC1 mapped to TI1 */
    TIM3->CCER  = TIM_CCER_CC1E;               /* CH1 enable, rising */

    /* CH2: cam — polarity set via hal_cam_set_polarity() */
    TIM3->CCMR1 |= (TIM_CCMR1_CC2S_0);         /* IC2 mapped to TI2 */
    TIM3->CCER  |= TIM_CCER_CC2E;

    /* Enable capture interrupts */
    TIM3->DIER  = TIM_DIER_CC1IE | TIM_DIER_CC2IE;

    TIM3->CR1   = TIM_CR1_CEN;
}

static void tim4_tim5_init_compare(void)
{
    /*
     * TIM4 and TIM5 as output compare timers for event scheduler.
     * All 4 channels per timer configured as compare (no PWM output),
     * ISR fires on match. GPIO toggling is done by the ISR via hal_gpio_*.
     */
    for (TIM_TypeDef *tim = TIM4; tim <= TIM5; tim = (TIM_TypeDef *)((uint8_t *)tim + 0x400))
    {
        tim->CR1   = 0;
        tim->PSC   = 249U;
        tim->ARR   = 0xFFFFUL;
        tim->EGR   = TIM_EGR_UG;
        tim->SR    = 0;
        tim->CCMR1 = 0;   /* output compare mode, no output */
        tim->CCMR2 = 0;
        tim->CCER  = 0;   /* channels disabled until armed */
        tim->DIER  = 0;   /* interrupts enabled per-channel when armed */
        tim->CR1   = TIM_CR1_CEN;
    }
}

static void nvic_init(void)
{
    /* TIM3: highest priority (crank/cam capture) */
    NVIC_SetPriority(TIM3_IRQn, 0);
    NVIC_EnableIRQ(TIM3_IRQn);

    /* TIM4: ignition compare */
    NVIC_SetPriority(TIM4_IRQn, 1);
    NVIC_EnableIRQ(TIM4_IRQn);

    /* TIM5: injector compare */
    NVIC_SetPriority(TIM5_IRQn, 1);
    NVIC_EnableIRQ(TIM5_IRQn);

    /* ADC1: knock samples */
    NVIC_SetPriority(ADC1_IRQn, 2);
    NVIC_EnableIRQ(ADC1_IRQn);
}

static void iwdg_init(void)
{
    /*
     * IWDG timeout = ~200 ms.
     * IWDG clock = LSI ~32 kHz, prescaler /32 → 1 kHz.
     * Reload = 200 → 200 ms timeout.
     */
    IWDG->KR  = 0xCCCC;   /* start IWDG */
    IWDG->KR  = 0x5555;   /* unlock PR and RLR */
    IWDG->PR  = 3U;       /* /32 prescaler */
    IWDG->RLR = 199U;     /* reload value */
    while (IWDG->SR) {}   /* wait for registers to update */
    IWDG->KR  = 0xAAAA;   /* reload */
}

/* -----------------------------------------------------------------------
 * Public API — lifecycle
 * ----------------------------------------------------------------------- */

void hal_timer_init(void)
{
    clock_enable();
    gpio_init_outputs();
    tim2_init_freerun();
    tim3_init_capture();
    tim4_tim5_init_compare();
    nvic_init();
}

void hal_gpio_init(void)
{
    /* Already done in hal_timer_init via gpio_init_outputs().
     * Exposed separately to satisfy startup sequence contract. */
}

void hal_enable_irqs(void)
{
    iwdg_init();
    __enable_irq();
}

/* -----------------------------------------------------------------------
 * Public API — timer
 * ----------------------------------------------------------------------- */

uint32_t hal_timer_get(void)
{
    return TIM2->CNT;
}

void hal_timer_set_compare(uint8_t channel, uint32_t timestamp)
{
    if (channel >= 8U) return;

    TIM_TypeDef *tim = compare_timer(channel);
    uint8_t     ch   = compare_tim_ch(channel);

    /* Write compare register for the appropriate channel */
    volatile uint32_t *ccr = &tim->CCR1 + ch;
    *ccr = (uint16_t)(timestamp & 0xFFFFUL);

    /* Enable compare interrupt for this channel */
    tim->DIER |= (TIM_DIER_CC1IE << ch);
    tim->SR   &= ~(TIM_SR_CC1IF << ch);   /* clear any pending flag */
}

void hal_timer_clear_compare(uint8_t channel)
{
    if (channel >= 8U) return;
    TIM_TypeDef *tim = compare_timer(channel);
    uint8_t     ch   = compare_tim_ch(channel);
    tim->DIER &= ~(TIM_DIER_CC1IE << ch);
}

/* -----------------------------------------------------------------------
 * Public API — GPIO (BSRR for atomic ISR-safe set/clear)
 * ----------------------------------------------------------------------- */

void hal_gpio_set(uint8_t pin)
{
    GPIO_TypeDef *port = pin_port(pin);
    uint32_t     mask  = pin_mask(pin);
    if (port && mask)
        port->BSRR = mask;           /* set bits */
}

void hal_gpio_clear(uint8_t pin)
{
    GPIO_TypeDef *port = pin_port(pin);
    uint32_t     mask  = pin_mask(pin);
    if (port && mask)
        port->BSRR = (mask << 16);   /* reset bits */
}

/* -----------------------------------------------------------------------
 * Public API — ADC
 * ----------------------------------------------------------------------- */

uint16_t hal_adc_read(uint8_t channel)
{
    /* Blocking single-conversion. For knock use DMA ISR instead. */
    ADC1->SQR1  = (channel & 0x1FUL) << 6;   /* single conversion, ch N */
    ADC1->CR   |= ADC_CR_ADSTART;
    while (!(ADC1->ISR & ADC_ISR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0x0FFFU);
}

/* -----------------------------------------------------------------------
 * Public API — critical section
 * ----------------------------------------------------------------------- */

hal_irq_state_t hal_enter_critical(void)
{
    uint32_t state = __get_PRIMASK();
    __disable_irq();
    __DSB();
    __ISB();
    return state;
}

void hal_exit_critical(hal_irq_state_t state)
{
    __set_PRIMASK(state);
}

/* -----------------------------------------------------------------------
 * Public API — cam polarity
 * ----------------------------------------------------------------------- */

void hal_cam_set_polarity(cam_polarity_t pol)
{
    if (pol == CAM_POLARITY_FALLING)
        TIM3->CCER |=  TIM_CCER_CC2P;   /* falling edge */
    else
        TIM3->CCER &= ~TIM_CCER_CC2P;   /* rising edge (default) */
}

/* -----------------------------------------------------------------------
 * Watchdog kick — call from main loop
 * ----------------------------------------------------------------------- */

void hal_watchdog_kick(void)
{
    IWDG->KR = 0xAAAA;
}

/* -----------------------------------------------------------------------
 * IRQ handlers — forward to application layer
 * ----------------------------------------------------------------------- */

extern void ECU_CrankCapture_ISR(uint32_t timestamp);
extern void ECU_CamCapture_ISR(uint32_t timestamp);
extern void ECU_Compare_ISR(uint8_t channel);
extern void ECU_ADC_Knock_ISR(uint16_t sample);

void TIM3_IRQHandler(void)
{
    uint32_t sr = TIM3->SR;
    TIM3->SR = 0;

    if (sr & TIM_SR_CC1IF)
        ECU_CrankCapture_ISR(TIM3->CCR1);

    if (sr & TIM_SR_CC2IF)
        ECU_CamCapture_ISR(TIM3->CCR2);
}

void TIM4_IRQHandler(void)
{
    uint32_t sr = TIM4->SR;
    TIM4->SR = 0;
    for (uint8_t ch = 0; ch < 4U; ch++)
        if (sr & (TIM_SR_CC1IF << ch))
            ECU_Compare_ISR(ch);           /* channels 0-3 = ignition */
}

void TIM5_IRQHandler(void)
{
    uint32_t sr = TIM5->SR;
    TIM5->SR = 0;
    for (uint8_t ch = 0; ch < 4U; ch++)
        if (sr & (TIM_SR_CC1IF << ch))
            ECU_Compare_ISR(4U + ch);      /* channels 4-7 = injection */
}

void ADC1_IRQHandler(void)
{
    if (ADC1->ISR & ADC_ISR_EOC)
        ECU_ADC_Knock_ISR((uint16_t)(ADC1->DR & 0x0FFFU));
}
