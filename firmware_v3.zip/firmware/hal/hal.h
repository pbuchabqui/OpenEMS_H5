/**
 * @file    hal.h
 * @brief   Hardware Abstraction Layer — STM32H562RGT6
 *
 * Timer:   TIM2 running at 1 MHz (1 tick = 1 µs).
 *          All timestamps and periods are in MICROSECONDS unless noted.
 *
 * All functions callable from ISR context unless marked [TASK ONLY].
 */

#ifndef HAL_H
#define HAL_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Timer
 * TIM2 is a 32-bit free-running counter at 1 MHz.
 * Rolls over every ~71.6 minutes — use subtraction for elapsed time,
 * never direct comparison.
 * ----------------------------------------------------------------------- */

/** @brief  1 MHz tick — 1 tick = 1 µs. */
#define HAL_TIMER_TICKS_PER_US   (1U)

/** @brief  1 MHz tick — ticks per millisecond. */
#define HAL_TIMER_TICKS_PER_MS   (1000U)

/** @brief  Get current 32-bit timer value [µs]. ISR-safe. */
uint32_t hal_timer_get(void);

/** @brief  Configure a hardware compare channel for a future event [µs timestamp].
 *  @param  channel   0 = ignition, 1 = injector A, 2 = injector B, ...
 *  @param  timestamp Absolute tick value at which the compare fires.
 */
void hal_timer_set_compare(uint8_t channel, uint32_t timestamp);

/** @brief  Disable a compare channel. ISR-safe. */
void hal_timer_clear_compare(uint8_t channel);

/* -----------------------------------------------------------------------
 * GPIO
 * ----------------------------------------------------------------------- */

/** @brief  Drive pin high. ISR-safe. */
void hal_gpio_set(uint8_t pin);

/** @brief  Drive pin low. ISR-safe. */
void hal_gpio_clear(uint8_t pin);

/* -----------------------------------------------------------------------
 * ADC
 * Returns raw 12-bit counts (0–4095).  Conversion to engineering units
 * is done in the sensor layer, not here.
 * ----------------------------------------------------------------------- */

/** @brief  Read ADC channel (blocking, < 2 µs). ISR-safe. */
uint16_t hal_adc_read(uint8_t channel);

/* -----------------------------------------------------------------------
 * Critical section helpers (disable/restore IRQ)
 * Use to protect multi-word shared state between ISR and tasks.
 *
 * Example:
 *   hal_irq_state_t s = hal_enter_critical();
 *   ... read/write shared variable ...
 *   hal_exit_critical(s);
 * ----------------------------------------------------------------------- */

typedef uint32_t hal_irq_state_t;

/** @brief  Disable interrupts, return previous PRIMASK. ISR-safe. */
hal_irq_state_t hal_enter_critical(void);

/** @brief  Restore PRIMASK from saved state. ISR-safe. */
void hal_exit_critical(hal_irq_state_t state);

/* -----------------------------------------------------------------------
 * Cam sensor polarity — set before crank_init().
 * ----------------------------------------------------------------------- */

typedef enum {
    CAM_POLARITY_RISING  = 0,
    CAM_POLARITY_FALLING = 1
} cam_polarity_t;

/** @brief  Configure cam sensor edge polarity. [TASK ONLY] */
void hal_cam_set_polarity(cam_polarity_t pol);

#endif /* HAL_H */
