/**
 * @file    knock_dsp.c
 * @brief   Knock detection DSP.
 *
 * Biquad bandpass (Direct Form II Transposed):
 *   w[n] = x[n] - a1*w[n-1] - a2*w[n-2]
 *   y[n] = b0*w[n] + b1*w[n-1] + b2*w[n-2]
 *
 * For bandpass with gain=1 at centre:
 *   b0 =  sin(w0)/2 = K
 *   b1 =  0
 *   b2 = -K
 *   a1 = -2*cos(w0)*alpha  (where alpha = 1/(1 + sin(w0)/(2Q)))
 *   a2 =  1 - sin(w0)/Q ... (see DSP cookbook — Audio EQ Cookbook, R. Bristow-Johnson)
 *
 * Sample rate: ADC driven at 50 kHz by timer.
 *
 * Background noise:
 *   A slow-decaying IIR tracks the average energy outside the knock window.
 *   Knock intensity = window_energy / background_energy.
 *   This makes the detector self-normalising and immune to sensor gain variation.
 */

#include "knock_dsp.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

/* -----------------------------------------------------------------------
 * DSP constants
 * ----------------------------------------------------------------------- */

#define SAMPLE_RATE_HZ      50000.0f
#define BIQUAD_Q            4.0f

/* Background noise EMA decay: alpha = 1/64 (slow) */
#define BG_EMA_SHIFT        6U

/* -----------------------------------------------------------------------
 * Biquad state
 * ----------------------------------------------------------------------- */

typedef struct {
    float b0, b1, b2;   /* feed-forward coefficients */
    float a1, a2;        /* feed-back coefficients    */
    float w1, w2;        /* delay elements            */
} biquad_t;

static biquad_t s_filter;

/* -----------------------------------------------------------------------
 * Energy accumulator state
 * ----------------------------------------------------------------------- */

static volatile float    s_window_energy   = 0.0f;
static volatile float    s_background_energy = 1.0f;  /* seed > 0 */
static volatile float    s_knock_level     = 0.0f;
static volatile bool     s_knock_detected  = false;
static volatile bool     s_window_active   = false;
static volatile float    s_threshold       = 0.5f;

/* -----------------------------------------------------------------------
 * Coefficient computation (Audio EQ Cookbook bandpass)
 * ----------------------------------------------------------------------- */

static void compute_coefficients(float freq_hz)
{
    float w0    = 2.0f * (float)M_PI * freq_hz / SAMPLE_RATE_HZ;
    float sinw0 = sinf(w0);
    float cosw0 = cosf(w0);
    float alpha = sinw0 / (2.0f * BIQUAD_Q);

    float b0 =  alpha;
    float b1 =  0.0f;
    float b2 = -alpha;
    float a0 =  1.0f + alpha;
    float a1 = -2.0f * cosw0;
    float a2 =  1.0f - alpha;

    /* Normalise by a0 */
    s_filter.b0 = b0 / a0;
    s_filter.b1 = b1 / a0;
    s_filter.b2 = b2 / a0;
    s_filter.a1 = a1 / a0;
    s_filter.a2 = a2 / a0;
    s_filter.w1 = 0.0f;
    s_filter.w2 = 0.0f;
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void knock_init(void)
{
    float freq_hz = 7500.0f;
    calibration_get(CAL_ID_KNOCK_FREQ_HZ, &freq_hz);
    calibration_get(CAL_ID_KNOCK_THRESHOLD, &s_threshold);

    compute_coefficients(freq_hz);

    s_window_energy    = 0.0f;
    s_background_energy = 1.0f;
    s_knock_level      = 0.0f;
    s_knock_detected   = false;
    s_window_active    = false;
}

void knock_process_sample(int16_t sample)
{
    /* Centre around zero: ADC 0–4095 → -2048..2047 */
    float x = (float)(sample - 2048);

    /* Biquad Direct Form II Transposed */
    float w0 = x - s_filter.a1 * s_filter.w1 - s_filter.a2 * s_filter.w2;
    float y  = s_filter.b0 * w0 + s_filter.b1 * s_filter.w1
                                 + s_filter.b2 * s_filter.w2;
    s_filter.w2 = s_filter.w1;
    s_filter.w1 = w0;

    float energy = y * y;

    if (s_window_active)
    {
        s_window_energy += energy;
    }
    else
    {
        /* Update background with slow EMA */
        s_background_energy += (energy - s_background_energy) / (float)(1U << BG_EMA_SHIFT);
    }
}

void knock_window_start(void)
{
    s_window_energy = 0.0f;
    s_window_active = true;
}

float knock_window_end(uint8_t cylinder)
{
    (void)cylinder;  /* per-cylinder calibration can be added here */

    s_window_active = false;

    /* Normalise by background */
    float intensity = (s_background_energy > 0.0f)
                      ? s_window_energy / s_background_energy
                      : 0.0f;

    s_knock_level    = intensity;
    s_knock_detected = (intensity > s_threshold);

    /* Update background with window energy for long-term calibration */
    s_background_energy += (s_window_energy - s_background_energy)
                           / (float)(1U << BG_EMA_SHIFT);

    return intensity;
}

float knock_get_level(void)      { return s_knock_level; }
bool  knock_is_detected(void)    { return s_knock_detected; }
