/**
 * @file    knock_dsp.h
 * @brief   Knock detection DSP — bandpass + windowed energy.
 *
 * Pipeline:
 *   knock_process_sample()  →  biquad bandpass  →  energy accumulator
 *   knock_window_start()    →  begin integration window
 *   knock_window_end()      →  compute normalised knock intensity
 *
 * Filter:
 *   2nd-order IIR biquad bandpass.
 *   Centre frequency: CAL_ID_KNOCK_FREQ_HZ (default 7500 Hz).
 *   Q factor: 4.0 (±~1875 Hz bandwidth at 7500 Hz).
 *   Coefficients are computed at init from calibration.
 *   Sample rate: set by ADC trigger rate (typically 50–100 kHz).
 *
 * Window:
 *   Integration window is typically 60°–100° after TDC (per cylinder).
 *   knock_window_start() resets the accumulator.
 *   knock_window_end()   normalises by background noise level and
 *                        returns knock intensity [0.0 = none, >1.0 = knock].
 *
 * All functions are ISR-safe (called from ADC ISR or compare ISR).
 */

#ifndef KNOCK_DSP_H
#define KNOCK_DSP_H

#include <stdint.h>
#include <stdbool.h>

/** @brief  Initialise knock DSP. Computes biquad coefficients from calibration.
 *          [TASK ONLY] — call after calibration_load(). */
void knock_init(void);

/**
 * @brief  Process one ADC sample. Call from ADC ISR.
 * @param  sample  Raw 12-bit ADC value (0–4095, signed-extended around 2048).
 */
void knock_process_sample(int16_t sample);

/** @brief  Start a knock integration window. Call from angle event ISR. */
void knock_window_start(void);

/**
 * @brief  End integration window and compute knock intensity.
 *         Call from angle event ISR at window end angle.
 * @param  cylinder  Cylinder being evaluated [0..3].
 * @return Knock intensity [0.0 .. ∞]. Values > threshold indicate knock.
 */
float knock_window_end(uint8_t cylinder);

/** @brief  Latest knock intensity (last completed window). ISR-safe. */
float knock_get_level(void);

/** @brief  true if last window exceeded the knock threshold. ISR-safe. */
bool knock_is_detected(void);

#endif /* KNOCK_DSP_H */
