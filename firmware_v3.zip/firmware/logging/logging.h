/**
 * @file    logging.h
 * @brief   High-speed signal logging — ring buffer with signal IDs.
 *
 * log_write() is ISR-safe and lock-free (uses atomic index increment).
 * log_flush_can() drains entries to CAN for host-side recording.
 *
 * Signal IDs (LOG_SIG_xxx) are defined here and map directly to
 * channels in PC-side tools.
 */

#ifndef LOGGING_H
#define LOGGING_H

#include <stdint.h>

/* -----------------------------------------------------------------------
 * Signal IDs
 * ----------------------------------------------------------------------- */

#define LOG_SIG_RPM              0x01U
#define LOG_SIG_MAP              0x02U
#define LOG_SIG_TPS              0x03U
#define LOG_SIG_IAT              0x04U
#define LOG_SIG_ECT              0x05U
#define LOG_SIG_LAMBDA           0x06U
#define LOG_SIG_BATT             0x07U
#define LOG_SIG_SPARK_ADV        0x10U
#define LOG_SIG_KNOCK_LEVEL      0x11U
#define LOG_SIG_KNOCK_RETARD     0x12U
#define LOG_SIG_INJ_PW_CYL0      0x20U
#define LOG_SIG_INJ_PW_CYL1      0x21U
#define LOG_SIG_INJ_PW_CYL2      0x22U
#define LOG_SIG_INJ_PW_CYL3      0x23U
#define LOG_SIG_LAMBDA_CORR      0x30U
#define LOG_SIG_TORQUE_IDX_CYL0  0x40U
#define LOG_SIG_TORQUE_IDX_CYL1  0x41U
#define LOG_SIG_TORQUE_IDX_CYL2  0x42U
#define LOG_SIG_TORQUE_IDX_CYL3  0x43U
#define LOG_SIG_CYCLE_ANGLE      0x50U
#define LOG_SIG_ENGINE_STATE     0x60U

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise logging ring buffer. [TASK ONLY] */
void log_init(void);

/**
 * @brief  Write one sample to the ring buffer. ISR-safe, lock-free.
 * @param  signal_id  LOG_SIG_xxx constant.
 * @param  value      Sample value.
 * @param  timestamp  HAL timer value at sample time [µs].
 */
void log_write(uint16_t signal_id, float value, uint32_t timestamp);

/**
 * @brief  Drain pending log entries via CAN (up to max_frames per call).
 *         [TASK ONLY]
 */
void log_flush_can(uint8_t max_frames);

/** @brief  Number of unread entries in the ring buffer. */
uint16_t log_pending(void);

#endif /* LOGGING_H */
