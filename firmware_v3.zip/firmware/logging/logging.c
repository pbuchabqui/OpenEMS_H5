/**
 * @file    logging.c
 * @brief   Lock-free ring buffer logger.
 *
 * CAN log frame format (ID 0x300):
 *   [u16 signal_id][u32 timestamp_us][f32 value]  = 10 bytes (fits 8B DLC? no)
 *   → split: ID 0x300 = header(signal_id + timestamp low 16b)
 *            ID 0x301 = value as raw bytes
 *   Or use a compact 8-byte frame:
 *   [u16 signal_id][u16 timestamp_ms][f32 value]  = 8 bytes exactly
 */

#include "logging.h"
#include "../communication/comm.h"
#include "../hal/hal.h"
#include <string.h>
#include <stdint.h>

/* -----------------------------------------------------------------------
 * Ring buffer
 * ----------------------------------------------------------------------- */

#define LOG_RING_SIZE  256U   /* must be power of 2 */

typedef struct {
    uint16_t signal_id;
    uint16_t timestamp_ms;    /* lower 16 bits of timestamp / 1000 */
    float    value;
} log_entry_t;

static log_entry_t s_ring[LOG_RING_SIZE];
static volatile uint16_t s_head = 0;   /* write index (ISR writes) */
static volatile uint16_t s_tail = 0;   /* read index  (task reads) */

#define RING_MASK (LOG_RING_SIZE - 1U)

/* -----------------------------------------------------------------------
 * CAN log IDs
 * ----------------------------------------------------------------------- */

#define CAN_ID_LOG  0x300U

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void log_init(void)
{
    s_head = 0;
    s_tail = 0;
}

void log_write(uint16_t signal_id, float value, uint32_t timestamp)
{
    uint16_t next_head = (s_head + 1U) & RING_MASK;

    if (next_head == s_tail)
        return;   /* buffer full — drop sample */

    s_ring[s_head].signal_id    = signal_id;
    s_ring[s_head].timestamp_ms = (uint16_t)(timestamp / 1000U);
    s_ring[s_head].value        = value;

    /* Compiler barrier to ensure all fields written before head advances */
    __asm volatile ("" ::: "memory");
    s_head = next_head;
}

void log_flush_can(uint8_t max_frames)
{
    uint8_t count = 0;

    while (s_tail != s_head && count < max_frames)
    {
        log_entry_t *e = &s_ring[s_tail & RING_MASK];

        uint8_t frame[8];
        frame[0] = (uint8_t)(e->signal_id >> 8);
        frame[1] = (uint8_t)(e->signal_id);
        frame[2] = (uint8_t)(e->timestamp_ms >> 8);
        frame[3] = (uint8_t)(e->timestamp_ms);
        memcpy(&frame[4], &e->value, sizeof(float));

        comm_send_frame(CAN_ID_LOG, frame, 8);

        __asm volatile ("" ::: "memory");
        s_tail = (s_tail + 1U) & RING_MASK;
        count++;
    }
}

uint16_t log_pending(void)
{
    return (s_head - s_tail) & RING_MASK;
}
