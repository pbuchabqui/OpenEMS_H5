/**
 * @file    sensors.c
 * @brief   Sensor ADC sampling, conversion, validation — double-buffered.
 *
 * Double-buffer scheme:
 *   sensors_update() writes to s_buf[s_write_idx].
 *   When complete, it atomically swaps s_write_idx.
 *   sensors_get() reads from the non-write buffer under critical section.
 *   This guarantees tasks always read a complete consistent snapshot.
 *
 * Thermistor conversion (IAT, ECT):
 *   Steinhart-Hart simplified (Beta model):
 *   1/T = 1/T_ref + (1/Beta) * ln(R/R_ref)
 *   R from voltage divider: R = R_pull * V_adc / (Vcc - V_adc)
 */

#include "sensors.h"
#include "../hal/hal.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"
#include <math.h>

/* -----------------------------------------------------------------------
 * Constants
 * ----------------------------------------------------------------------- */

#define ADC_FULL_SCALE      4095.0f
#define ADC_VREF            3.3f        /* [V] */
#define THERMISTOR_RPULL    2200.0f     /* [Ω] pull-up resistor */
#define KELVIN_OFFSET       273.15f
#define T_REF_K             298.15f     /* 25 °C in Kelvin */

/* Sensor range limits — readings outside are flagged invalid */
#define MAP_MIN_KPA         10.0f
#define MAP_MAX_KPA         400.0f
#define MAF_MIN_G_S         0.0f
#define MAF_MAX_G_S         500.0f
#define TPS_MIN_PCT         0.0f
#define TPS_MAX_PCT         100.0f
#define IAT_MIN_C           -40.0f
#define IAT_MAX_C           120.0f
#define ECT_MIN_C           -40.0f
#define ECT_MAX_C           130.0f
#define LAMBDA_MIN          0.5f
#define LAMBDA_MAX          2.0f
#define BATT_MIN_V          6.0f
#define BATT_MAX_V          20.0f

/* -----------------------------------------------------------------------
 * Double buffer
 * ----------------------------------------------------------------------- */

static sensor_data_t  s_buf[2];
static sensor_valid_t s_valid_buf[2];
static volatile uint8_t s_write_idx = 0;

/* -----------------------------------------------------------------------
 * Conversion helpers
 * ----------------------------------------------------------------------- */

static float adc_to_volts(uint16_t adc)
{
    return ((float)adc / ADC_FULL_SCALE) * ADC_VREF;
}

static float thermistor_to_degc(uint16_t adc, float r25, float beta)
{
    float v   = adc_to_volts(adc);
    float denom = ADC_VREF - v;
    if (denom <= 0.0f) return -40.0f;   /* open circuit */

    float r   = THERMISTOR_RPULL * v / denom;
    if (r <= 0.0f) return -40.0f;

    float inv_t = (1.0f / T_REF_K) + (1.0f / beta) * logf(r / r25);
    return (1.0f / inv_t) - KELVIN_OFFSET;
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void sensors_init(void)
{
    for (uint8_t i = 0; i < 2; i++)
    {
        s_buf[i].map    = 101.3f;
        s_buf[i].maf    = 0.0f;
        s_buf[i].tps    = 0.0f;
        s_buf[i].iat    = 25.0f;
        s_buf[i].ect    = 20.0f;
        s_buf[i].lambda = 1.0f;
        s_buf[i].batt   = 14.0f;
    }
}

void sensors_update(void)
{
    uint8_t wi = s_write_idx;
    sensor_data_t  *d = &s_buf[wi];
    sensor_valid_t *v = &s_valid_buf[wi];

    /* --- MAP ----------------------------------------------------------- */
    {
        float gain   = 2.5f;
        float offset = 0.0f;
        calibration_get(CAL_ID_MAP_GAIN,   &gain);
        calibration_get(CAL_ID_MAP_OFFSET, &offset);

        float volts = adc_to_volts(hal_adc_read(SENSOR_ADC_CH_MAP));
        d->map  = volts * gain + offset;
        v->map_ok = (d->map >= MAP_MIN_KPA && d->map <= MAP_MAX_KPA);
        if (!v->map_ok) d->map = (d->map < MAP_MIN_KPA) ? MAP_MIN_KPA : MAP_MAX_KPA;
    }

    /* --- MAF ----------------------------------------------------------- */
    {
        /* Linear voltage transfer: 0–5 V → 0–500 g/s (sensor-specific) */
        float volts = adc_to_volts(hal_adc_read(SENSOR_ADC_CH_MAF));
        d->maf  = volts * (MAF_MAX_G_S / ADC_VREF);
        v->maf_ok = (d->maf >= MAF_MIN_G_S && d->maf <= MAF_MAX_G_S);
        if (!v->maf_ok) d->maf = 0.0f;
    }

    /* --- TPS ----------------------------------------------------------- */
    {
        uint16_t adc_raw    = hal_adc_read(SENSOR_ADC_CH_TPS);
        float    tps_closed = 200.0f;
        float    tps_open   = 3800.0f;
        calibration_get(CAL_ID_TPS_CLOSED_ADC, &tps_closed);
        calibration_get(CAL_ID_TPS_OPEN_ADC,   &tps_open);

        float span = tps_open - tps_closed;
        d->tps = (span > 0.0f)
                 ? ((float)(adc_raw - (uint16_t)tps_closed) / span) * 100.0f
                 : 0.0f;
        if (d->tps < TPS_MIN_PCT) d->tps = TPS_MIN_PCT;
        if (d->tps > TPS_MAX_PCT) d->tps = TPS_MAX_PCT;
        v->tps_ok = true;
    }

    /* --- IAT ----------------------------------------------------------- */
    {
        float r25  = 2200.0f;
        float beta = 3950.0f;
        calibration_get(CAL_ID_IAT_R25,  &r25);
        calibration_get(CAL_ID_IAT_BETA, &beta);
        d->iat   = thermistor_to_degc(hal_adc_read(SENSOR_ADC_CH_IAT), r25, beta);
        v->iat_ok = (d->iat >= IAT_MIN_C && d->iat <= IAT_MAX_C);
        if (!v->iat_ok) d->iat = 25.0f;   /* use ambient as fallback */
    }

    /* --- ECT ----------------------------------------------------------- */
    {
        float r25  = 2200.0f;
        float beta = 3950.0f;
        calibration_get(CAL_ID_ECT_R25,  &r25);
        calibration_get(CAL_ID_ECT_BETA, &beta);
        d->ect   = thermistor_to_degc(hal_adc_read(SENSOR_ADC_CH_ECT), r25, beta);
        v->ect_ok = (d->ect >= ECT_MIN_C && d->ect <= ECT_MAX_C);
        if (!v->ect_ok) d->ect = 90.0f;   /* use hot fallback to avoid rich fuelling */
    }

    /* --- Lambda (wideband) --------------------------------------------- */
    {
        /* Linear: 0.5 V = lambda 0.5, 4.5 V = lambda 1.5 (sensor-specific) */
        float volts  = adc_to_volts(hal_adc_read(SENSOR_ADC_CH_LAMBDA));
        d->lambda    = 0.5f + (volts / ADC_VREF) * 1.0f;
        v->lambda_ok = (d->lambda >= LAMBDA_MIN && d->lambda <= LAMBDA_MAX);
        if (!v->lambda_ok) d->lambda = 1.0f;
    }

    /* --- Battery voltage ----------------------------------------------- */
    {
        /* Resistor divider: 1/4 ratio → × 4 */
        float volts = adc_to_volts(hal_adc_read(SENSOR_ADC_CH_BATT));
        d->batt     = volts * 4.0f;
        v->batt_ok  = (d->batt >= BATT_MIN_V && d->batt <= BATT_MAX_V);
        if (!v->batt_ok) d->batt = 14.0f;
    }

    /* Atomic buffer swap */
    hal_irq_state_t irqs = hal_enter_critical();
    s_write_idx = wi ^ 1U;
    hal_exit_critical(irqs);
}

sensor_data_t sensors_get(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint8_t ri = s_write_idx ^ 1U;   /* read from the non-write buffer */
    sensor_data_t snapshot = s_buf[ri];
    hal_exit_critical(irqs);
    return snapshot;
}

sensor_valid_t sensors_get_validity(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint8_t ri = s_write_idx ^ 1U;
    sensor_valid_t snapshot = s_valid_buf[ri];
    hal_exit_critical(irqs);
    return snapshot;
}
