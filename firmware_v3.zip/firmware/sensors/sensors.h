/**
 * @file    sensors.h
 * @brief   Sensor abstraction layer — explicit units on all values.
 *
 * Units convention (enforced by typedef names):
 *
 *   kpa_t    — absolute pressure in kilopascals  [kPa]
 *   g_s_t    — mass air flow in grams/second     [g/s]
 *   pct_t    — percentage 0.0–100.0              [%]
 *   degc_t   — temperature in Celsius            [°C]
 *   lambda_t — lambda ratio (1.0 = stoich)       [-]
 *   volts_t  — voltage                           [V]
 *
 * Range limits are enforced in sensors_update().  Out-of-range readings
 * are clamped and flagged with the corresponding fault DTC.
 */

#ifndef SENSORS_H
#define SENSORS_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Unit typedefs — makes mismatches visible at review time
 * ----------------------------------------------------------------------- */

typedef float kpa_t;      /**< Pressure [kPa]          */
typedef float g_s_t;      /**< Mass flow [g/s]         */
typedef float pct_t;      /**< Percentage [0..100 %]   */
typedef float degc_t;     /**< Temperature [°C]        */
typedef float lambda_t;   /**< Lambda ratio [-]        */
typedef float volts_t;    /**< Voltage [V]             */
typedef float rpm_f_t;    /**< Engine speed [RPM]      */

/* -----------------------------------------------------------------------
 * Sensor data snapshot
 * All fields are in the units shown in the comments.
 * ----------------------------------------------------------------------- */

typedef struct {
    kpa_t    map;          /**< Manifold absolute pressure  [kPa, 10–400]  */
    g_s_t    maf;          /**< Mass air flow               [g/s, 0–500]   */
    pct_t    tps;          /**< Throttle position           [%, 0–100]     */
    degc_t   iat;          /**< Intake air temperature      [°C, -40–120]  */
    degc_t   ect;          /**< Engine coolant temperature  [°C, -40–130]  */
    lambda_t lambda;       /**< Wideband O2 lambda          [-, 0.5–2.0]   */
    volts_t  batt;         /**< Battery voltage             [V, 6–20]      */
} sensor_data_t;

/* -----------------------------------------------------------------------
 * Validity flags — one bit per sensor
 * ----------------------------------------------------------------------- */

typedef struct {
    bool map_ok;
    bool maf_ok;
    bool tps_ok;
    bool iat_ok;
    bool ect_ok;
    bool lambda_ok;
    bool batt_ok;
} sensor_valid_t;

/* -----------------------------------------------------------------------
 * ADC channel assignments (board-specific — adjust to schematic)
 * ----------------------------------------------------------------------- */

#define SENSOR_ADC_CH_MAP     0U
#define SENSOR_ADC_CH_MAF     1U
#define SENSOR_ADC_CH_TPS     2U
#define SENSOR_ADC_CH_IAT     3U
#define SENSOR_ADC_CH_ECT     4U
#define SENSOR_ADC_CH_LAMBDA  5U
#define SENSOR_ADC_CH_BATT    6U

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise sensor module. [TASK ONLY] */
void sensors_init(void);

/**
 * @brief  Sample all ADC channels, convert to engineering units, validate.
 *         Call from medium-priority task at ~1 kHz.
 *         [TASK ONLY]
 */
void sensors_update(void);

/**
 * @brief  Get latest sensor snapshot. ISR-safe (double-buffer).
 * @return Copy of the most recent complete sensor_data_t.
 */
sensor_data_t sensors_get(void);

/**
 * @brief  Get validity flags for latest snapshot. ISR-safe.
 */
sensor_valid_t sensors_get_validity(void);

#endif /* SENSORS_H */
