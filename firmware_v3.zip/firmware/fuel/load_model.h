/**
 * @file    load_model.h
 * @brief   Engine load model — Speed Density and MAF modes.
 *
 * Speed Density:
 *   air_mass_mg = (MAP * VE * displacement_cc) / (R_air * IAT_K)
 *   where R_air = 287.05 J/(kg·K), displacement_cc per cylinder.
 *
 * MAF mode:
 *   air_mass_mg = (maf_g_s * 1000) / (rpm / 60 * num_cylinders / 2)
 *   (divides total mass flow by firing events per second)
 *
 * Engine load (used as map axis for VE/spark tables):
 *   load = MAP / baro_ref * 100   [% of atmospheric]
 */

#ifndef LOAD_MODEL_H
#define LOAD_MODEL_H

#include <stdint.h>
#include "../sensors/sensors.h"

typedef enum {
    LOAD_MODE_SPEED_DENSITY = 0,
    LOAD_MODE_MAF           = 1
} load_mode_t;

/** @brief  Set active load model. Call from task context. */
void load_model_set_mode(load_mode_t mode);

/**
 * @brief  Compute air mass per cylinder per cycle.
 * @param  sensors  Current sensor snapshot.
 * @param  rpm      Current engine speed [RPM].
 * @return Air mass [mg/cylinder/cycle].
 */
float load_compute_air_mass(const sensor_data_t *sensors, float rpm);

/**
 * @brief  Compute engine load for table axis indexing.
 * @param  sensors  Current sensor snapshot.
 * @return Engine load [% of atmospheric, 0–200].
 */
float load_compute_engine_load(const sensor_data_t *sensors);

#endif /* LOAD_MODEL_H */
