/**
 * @file    lambda_ctrl.h
 * @brief   Closed-loop lambda (O2) fuel correction — PI controller.
 *
 * Enabled when:
 *   - Engine fully synced (ENGINE_SYNC_FULL)
 *   - ECT > 60°C (warm engine)
 *   - TPS < 90% (not wide-open throttle)
 *   - Lambda sensor valid and warmed up
 *
 * Controller:
 *   error = lambda_target - lambda_measured
 *   integrator += error * Ki * dt
 *   correction  = error * Kp + integrator
 *   correction clamped to [LAMBDA_CORR_MIN, LAMBDA_CORR_MAX]
 *
 * The correction is a multiplier applied to fuel_compute_base_pw():
 *   final_pw = base_pw * lambda_correction
 */

#ifndef LAMBDA_CTRL_H
#define LAMBDA_CTRL_H

#include <stdint.h>
#include <stdbool.h>
#include "../sensors/sensors.h"

/** @brief  Initialise lambda controller state. */
void lambda_ctrl_init(void);

/**
 * @brief  Update controller. Call at ~10 Hz from main loop.
 * @param  sensors       Current sensor snapshot.
 * @param  lambda_target Target lambda from calibration table.
 * @param  dt_s          Time since last call [s].
 */
void lambda_ctrl_update(const sensor_data_t *sensors,
                        float               lambda_target,
                        float               dt_s);

/**
 * @brief  Get current fuel correction multiplier [0.7 .. 1.3].
 *         1.0 = no correction. ISR-safe.
 */
float lambda_ctrl_get_correction(void);

/** @brief  true if closed-loop is currently active. ISR-safe. */
bool lambda_ctrl_is_active(void);

#endif /* LAMBDA_CTRL_H */
