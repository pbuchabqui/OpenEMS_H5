/**
 * @file    load_model.c
 * @brief   Speed Density and MAF load model implementations.
 */

#include "load_model.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"

/* Air gas constant [J/(kg·K)] */
#define R_AIR_J_KG_K    287.05f
#define KELVIN_OFFSET   273.15f
#define NUM_CYLINDERS   4U

static load_mode_t s_mode = LOAD_MODE_SPEED_DENSITY;

void load_model_set_mode(load_mode_t mode)
{
    s_mode = mode;
}

float load_compute_air_mass(const sensor_data_t *sensors, float rpm)
{
    if (s_mode == LOAD_MODE_MAF)
    {
        /*
         * MAF mode:
         *   Events per second = (RPM / 60) * (cylinders / 2)
         *   air_mass_mg = (maf [g/s] * 1000 [mg/g]) / events_per_sec
         */
        if (rpm < 50.0f) return 0.0f;
        float events_per_sec = (rpm / 60.0f) * ((float)NUM_CYLINDERS / 2.0f);
        return (sensors->maf * 1000.0f) / events_per_sec;
    }

    /* Speed Density:
     *   ideal gas law: m = P*V / (R*T)
     *   P in Pa = map_kPa * 1000
     *   V in m³ = disp_cc * 1e-6
     *   T in K  = iat_c + 273.15
     *   result in kg → × 1e6 to get mg
     */
    float ve = 80.0f;   /* default VE [%] */
    calibration_lookup_2d(CAL_ID_VE_TABLE,
                          rpm, sensors->map, &ve);

    float disp_cc = 400.0f;
    calibration_get(CAL_ID_DISPLACEMENT_CC, &disp_cc);

    float map_pa  = sensors->map * 1000.0f;
    float iat_k   = sensors->iat + KELVIN_OFFSET;
    float vol_m3  = disp_cc * 1e-6f;

    /* Ideal air mass (100% VE) in kg */
    float mass_kg = (map_pa * vol_m3) / (R_AIR_J_KG_K * iat_k);

    /* Apply VE */
    return mass_kg * (ve / 100.0f) * 1.0e6f;   /* → mg */
}

float load_compute_engine_load(const sensor_data_t *sensors)
{
    float baro = 101.3f;
    calibration_get(CAL_ID_BARO_REF_KPA, &baro);
    if (baro < 50.0f) baro = 101.3f;
    return (sensors->map / baro) * 100.0f;
}
