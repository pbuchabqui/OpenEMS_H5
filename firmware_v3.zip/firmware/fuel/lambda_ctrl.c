/**
 * @file    lambda_ctrl.c
 * @brief   Closed-loop lambda PI controller.
 */

#include "lambda_ctrl.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Tuning constants
 * ----------------------------------------------------------------------- */

#define KP                   0.05f   /* proportional gain */
#define KI                   0.01f   /* integral gain (per second) */
#define LAMBDA_CORR_MIN      0.70f
#define LAMBDA_CORR_MAX      1.30f
#define ECT_MIN_FOR_CL_C     60.0f   /* minimum ECT to enable CL [°C] */
#define TPS_MAX_FOR_CL_PCT   90.0f   /* disable CL above this TPS [%] */
#define INTEGRATOR_MIN      -0.30f
#define INTEGRATOR_MAX       0.30f

/* -----------------------------------------------------------------------
 * State
 * ----------------------------------------------------------------------- */

static volatile float s_correction  = 1.0f;
static volatile bool  s_active      = false;
static float          s_integrator  = 0.0f;

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void lambda_ctrl_init(void)
{
    s_correction = 1.0f;
    s_active     = false;
    s_integrator = 0.0f;
}

void lambda_ctrl_update(const sensor_data_t *sensors,
                        float               lambda_target,
                        float               dt_s)
{
    /* Enable conditions */
    bool enable = (sensors->ect    >= ECT_MIN_FOR_CL_C)
               && (sensors->tps    <  TPS_MAX_FOR_CL_PCT)
               && (sensors->lambda >= 0.5f)
               && (sensors->lambda <= 2.0f)
               && (lambda_target   > 0.1f);

    if (!enable)
    {
        /* Freeze integrator, hold last correction, mark inactive */
        s_active = false;
        return;
    }

    s_active = true;

    float error = lambda_target - sensors->lambda;

    /* Integrator with anti-windup clamp */
    s_integrator += error * KI * dt_s;
    if (s_integrator < INTEGRATOR_MIN) s_integrator = INTEGRATOR_MIN;
    if (s_integrator > INTEGRATOR_MAX) s_integrator = INTEGRATOR_MAX;

    float corr = 1.0f + (error * KP) + s_integrator;

    if (corr < LAMBDA_CORR_MIN) corr = LAMBDA_CORR_MIN;
    if (corr > LAMBDA_CORR_MAX) corr = LAMBDA_CORR_MAX;

    hal_irq_state_t irqs = hal_enter_critical();
    s_correction = corr;
    hal_exit_critical(irqs);
}

float lambda_ctrl_get_correction(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    float v = s_correction;
    hal_exit_critical(irqs);
    return v;
}

bool lambda_ctrl_is_active(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    bool v = s_active;
    hal_exit_critical(irqs);
    return v;
}
