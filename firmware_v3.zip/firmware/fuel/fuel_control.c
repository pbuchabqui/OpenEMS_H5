/**
 * @file    fuel_control.c
 * @brief   Fuel control pipeline — base PW, wall-wetting, dead-time, trim.
 */

#include "fuel_control.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"

/* -----------------------------------------------------------------------
 * Wall-wetting per-cylinder film state
 * ----------------------------------------------------------------------- */

typedef struct {
    float film_mg;      /**< Current wall film mass [mg] */
    float prev_base_pw; /**< Base PW from previous cycle [µs] */
} wallwet_state_t;

static wallwet_state_t s_wallwet[4];

/* -----------------------------------------------------------------------
 * Injector constants
 * -----------------------------------------------------------------------
 * Flow rate conversion:
 *   440 cc/min at 3 bar → mg/µs:
 *   440 cc/min * 0.75 g/cc (gasoline) = 330 g/min = 5.5 g/s = 5500 µg/µs
 *   → 1 µs open = 5500/1e6 mg = 0.0055 mg
 * ----------------------------------------------------------------------- */

static const uint16_t CAL_TRIM_IDS[4] = {
    CAL_ID_FUEL_TRIM_CYL0,
    CAL_ID_FUEL_TRIM_CYL1,
    CAL_ID_FUEL_TRIM_CYL2,
    CAL_ID_FUEL_TRIM_CYL3
};

/* -----------------------------------------------------------------------
 * Init
 * ----------------------------------------------------------------------- */

void fuel_init(void)
{
    for (uint8_t i = 0; i < 4U; i++)
    {
        s_wallwet[i].film_mg      = 0.0f;
        s_wallwet[i].prev_base_pw = 0.0f;
    }
}

/* -----------------------------------------------------------------------
 * Base pulse width
 * ----------------------------------------------------------------------- */

pw_us_t fuel_compute_base_pw(float air_mass_mg, float lambda_target)
{
    float stoich_afr  = 14.7f;
    float flow_cc_min = 440.0f;
    calibration_get(CAL_ID_STOICH_AFR,           &stoich_afr);
    calibration_get(CAL_ID_INJECTOR_FLOW_CC_MIN, &flow_cc_min);

    if (lambda_target < 0.1f) lambda_target = 1.0f;

    /* Fuel mass needed [mg] */
    float target_afr  = stoich_afr * lambda_target;
    float fuel_mass_mg = air_mass_mg / target_afr;

    /* Injector flow rate in mg/µs
     * 440 cc/min * 0.75 g/cc = 330 g/min = 330000 mg / 60000000 µs */
    float flow_mg_us = (flow_cc_min * 0.75f * 1000.0f) / 60000000.0f;

    if (flow_mg_us < 1e-9f) return 0U;

    float pw_f = fuel_mass_mg / flow_mg_us;
    return (pw_us_t)(pw_f > 0.0f ? pw_f : 0.0f);
}

/* -----------------------------------------------------------------------
 * Wall-wetting transient correction (Aquino model)
 * ----------------------------------------------------------------------- */

pw_us_t fuel_apply_wallwet(uint8_t               cylinder,
                            pw_us_t               base_pw,
                            const wallwet_params_t *params,
                            float                 dt_s)
{
    if (cylinder >= 4U || params == NULL)
        return base_pw;

    float x   = params->x;
    float tau = params->tau;

    if (x < 0.01f) x = 0.01f;
    if (x > 1.0f)  x = 1.0f;
    if (tau < 0.001f) tau = 0.001f;

    wallwet_state_t *w = &s_wallwet[cylinder];

    /* Film decay factor */
    float decay = (dt_s < tau * 5.0f)
                  ? (1.0f - dt_s / tau)
                  : 0.0f;

    /* Fuel arriving at cylinder from film */
    float from_film = w->film_mg * (1.0f - decay);

    /* New fuel injected */
    float injected_mg = (float)base_pw * 0.0055f;  /* rough mg from µs */

    /* Fuel going into film */
    float to_film = injected_mg * (1.0f - x);

    /* Update film */
    w->film_mg = w->film_mg * decay + to_film;
    w->prev_base_pw = (float)base_pw;

    /* Extra fuel needed to account for what sticks to wall */
    float extra_mg = to_film - from_film;
    float extra_us = extra_mg / 0.0055f;

    float corrected = (float)base_pw + extra_us;
    if (corrected < 0.0f) corrected = 0.0f;

    return (pw_us_t)corrected;
}

/* -----------------------------------------------------------------------
 * Injector dead-time compensation
 * ----------------------------------------------------------------------- */

pw_us_t fuel_apply_deadtime(pw_us_t pw, float batt_v)
{
    float base_dt = 800.0f;
    float vcoef   = -50.0f;
    calibration_get(CAL_ID_INJ_DEADTIME_BASE_US, &base_dt);
    calibration_get(CAL_ID_INJ_DEADTIME_VCOEF,   &vcoef);

    /* Dead time decreases as voltage rises */
    float deadtime = base_dt + vcoef * (batt_v - 14.0f);
    if (deadtime < 0.0f) deadtime = 0.0f;

    return pw + (pw_us_t)deadtime;
}

/* -----------------------------------------------------------------------
 * Per-cylinder trim
 * ----------------------------------------------------------------------- */

pw_us_t fuel_apply_cyl_trim(uint8_t cylinder, pw_us_t pw)
{
    if (cylinder >= 4U) return pw;
    float trim = 1.0f;
    calibration_get(CAL_TRIM_IDS[cylinder], &trim);
    if (trim < 0.5f) trim = 0.5f;
    if (trim > 1.5f) trim = 1.5f;
    return (pw_us_t)((float)pw * trim);
}

/* -----------------------------------------------------------------------
 * Final clamp
 * ----------------------------------------------------------------------- */

pw_us_t fuel_clamp_pw(pw_us_t pw)
{
    float pw_min = 500.0f;
    float pw_max = 20000.0f;
    calibration_get(CAL_ID_INJ_PW_MIN_US, &pw_min);
    calibration_get(CAL_ID_INJ_PW_MAX_US, &pw_max);

    if ((float)pw < pw_min) return 0U;          /* below min — skip injection */
    if ((float)pw > pw_max) return (pw_us_t)pw_max;
    return pw;
}
