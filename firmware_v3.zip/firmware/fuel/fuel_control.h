/**
 * @file    fuel_control.h
 * @brief   Fuel control pipeline — base PW, wall-wetting transient, final PW.
 *
 * Transient fuel model (Aquino / Takahashi wall-wetting):
 * --------------------------------------------------------
 * Fuel deposited on intake port walls delays actual in-cylinder delivery.
 *
 *   X  = fraction of injected fuel that goes directly to cylinder [0..1]
 *   tau = wall film time constant [s]
 *
 * Difference equations (per cylinder, per cycle):
 *
 *   film[n]  = film[n-1] * (1 - dt/tau) + base_pw[n] * (1 - X)
 *   extra_pw = (base_pw[n] - base_pw[n-1]) * (1-X) / X   [simplified]
 *   final_pw = base_pw[n] + extra_pw
 *
 * X and tau are calibration values that vary with ECT and TPS rate.
 * They are read from the calibration system (see calibration_ids.h).
 *
 * All pulse widths in MICROSECONDS [µs] unless noted.
 */

#ifndef FUEL_CONTROL_H
#define FUEL_CONTROL_H

#include <stdint.h>
#include "../sensors/sensors.h"

/* -----------------------------------------------------------------------
 * Types
 * ----------------------------------------------------------------------- */

/** Pulse width in microseconds */
typedef uint32_t pw_us_t;

/* -----------------------------------------------------------------------
 * Wall-wetting parameters (per cylinder)
 * Values come from calibration — this struct is passed in so the caller
 * can source them from the calibration table.
 * ----------------------------------------------------------------------- */

typedef struct {
    float x;    /**< Direct-hit fraction [0.0 .. 1.0].
                 *   Typical: 0.4–0.8 at idle, higher at WOT.
                 *   Loaded from CAL_ID_WALLWET_X table [ECT][TPS_rate]. */
    float tau;  /**< Film time constant [s].
                 *   Typical: 0.05 s (hot) – 2.0 s (cold).
                 *   Loaded from CAL_ID_WALLWET_TAU table [ECT]. */
} wallwet_params_t;

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise fuel state. Call before first update. */
void fuel_init(void);

/**
 * @brief  Compute base injector pulse width from air mass.
 * @param  air_mass_mg   Air mass per cylinder per cycle [mg].
 * @param  lambda_target Target lambda ratio [-].
 * @return Base pulse width [µs], before transient correction.
 */
pw_us_t fuel_compute_base_pw(float air_mass_mg, float lambda_target);

/**
 * @brief  Apply Aquino wall-wetting transient correction.
 * @param  cylinder   Cylinder index [0..3] — each has its own film state.
 * @param  base_pw    Base pulse width for this cycle [µs].
 * @param  params     Wall-wetting parameters (from calibration).
 * @param  dt_s       Time since last injection for this cylinder [s].
 * @return Corrected pulse width [µs].
 */
pw_us_t fuel_apply_wallwet(uint8_t               cylinder,
                            pw_us_t               base_pw,
                            const wallwet_params_t *params,
                            float                 dt_s);

/**
 * @brief  Apply injector dead-time compensation.
 * @param  pw      Pulse width before dead-time [µs].
 * @param  batt_v  Battery voltage [V] — dead time varies with voltage.
 * @return Compensated pulse width [µs].
 */
pw_us_t fuel_apply_deadtime(pw_us_t pw, float batt_v);

/**
 * @brief  Apply per-cylinder trim correction.
 * @param  cylinder  Cylinder index [0..3].
 * @param  pw        Pulse width before trim [µs].
 * @return Trimmed pulse width [µs].
 */
pw_us_t fuel_apply_cyl_trim(uint8_t cylinder, pw_us_t pw);

/**
 * @brief  Clamp final pulse width to injector limits.
 * @param  pw  Unclamped pulse width [µs].
 * @return Clamped pulse width [µs].
 */
pw_us_t fuel_clamp_pw(pw_us_t pw);

#endif /* FUEL_CONTROL_H */
