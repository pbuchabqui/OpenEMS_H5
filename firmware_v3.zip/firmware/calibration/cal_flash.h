/**
 * @file    cal_flash.h
 * @brief   Calibration flash storage — STM32H562RGT6.
 *
 * Serialisation types used by cal_flash.c and calibration.c.
 * [TASK ONLY] — never call from ISR.
 */

#ifndef CAL_FLASH_H
#define CAL_FLASH_H

#include <stdint.h>
#include <stddef.h>

/* -----------------------------------------------------------------------
 * Serialisation wire types (packed, stored in flash)
 * ----------------------------------------------------------------------- */

typedef struct __attribute__((packed)) {
    uint16_t id;
    float    value;
} cal_serial_scalar_t;

#define CAL_1D_MAX_BINS_SERIAL  16U

typedef struct __attribute__((packed)) {
    uint16_t id;
    uint8_t  bins;
    uint8_t  _pad;
    float    axis[CAL_1D_MAX_BINS_SERIAL];
    float    values[CAL_1D_MAX_BINS_SERIAL];
} cal_serial_table_1d_t;

#define CAL_2D_MAX_ROWS_SERIAL  16U
#define CAL_2D_MAX_COLS_SERIAL  16U

typedef struct __attribute__((packed)) {
    uint16_t id;
    uint8_t  rows;
    uint8_t  cols;
    float    row_axis[CAL_2D_MAX_ROWS_SERIAL];
    float    col_axis[CAL_2D_MAX_COLS_SERIAL];
    float    values[CAL_2D_MAX_ROWS_SERIAL][CAL_2D_MAX_COLS_SERIAL];
} cal_serial_table_2d_t;

/* -----------------------------------------------------------------------
 * Result codes
 * ----------------------------------------------------------------------- */

typedef enum {
    CAL_FLASH_OK          = 0,
    CAL_FLASH_ERR_MAGIC   = 1,
    CAL_FLASH_ERR_CRC     = 2,
    CAL_FLASH_ERR_WRITE   = 3
} cal_flash_result_t;

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Erase cal sector and write current RAM calibration. [TASK ONLY] */
cal_flash_result_t cal_flash_save(void);

/** @brief  Read and CRC-verify cal from flash into RAM. [TASK ONLY] */
cal_flash_result_t cal_flash_load(void);

/* Implemented in calibration.c — called by cal_flash.c */
uint16_t calibration_serialise_scalars(uint8_t *buf, size_t max);
uint16_t calibration_serialise_tables_1d(uint8_t *buf, size_t max);
uint16_t calibration_serialise_tables_2d(uint8_t *buf, size_t max);
void     calibration_deserialise_scalars(const uint8_t *buf, uint16_t count);
void     calibration_deserialise_tables_1d(const uint8_t *buf, uint16_t count);
void     calibration_deserialise_tables_2d(const uint8_t *buf, uint16_t count);

#endif /* CAL_FLASH_H */
