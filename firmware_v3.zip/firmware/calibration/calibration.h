/**
 * @file    calibration.h
 * @brief   Calibration system — flash-backed scalars and 2D maps.
 *
 * Storage layout in flash:
 *
 *   [ cal_header_t ][ cal_entry_t × N ][ CRC32 ]
 *
 * On boot, calibration_load() reads flash, verifies CRC, and copies
 * data into RAM.  All runtime access is from RAM — no flash reads during
 * engine operation.
 *
 * Table access:
 *   1D and 2D tables are stored as contiguous float arrays.
 *   Use calibration_lookup_1d() / calibration_lookup_2d() for
 *   interpolated access.  Axis values are stored alongside the table.
 *
 * Runtime updates:
 *   calibration_set_value() writes to RAM immediately.
 *   calibration_save() flushes RAM to flash (call only from task context,
 *   never during active engine control).
 */

#ifndef CALIBRATION_H
#define CALIBRATION_H

#include <stdint.h>
#include <stdbool.h>
#include "calibration_ids.h"

/* -----------------------------------------------------------------------
 * Table dimensions
 * ----------------------------------------------------------------------- */

#define CAL_VE_RPM_BINS    16U
#define CAL_VE_LOAD_BINS   16U
#define CAL_SPARK_RPM_BINS 16U
#define CAL_SPARK_LOAD_BINS 16U
#define CAL_LAMBDA_RPM_BINS 8U
#define CAL_LAMBDA_LOAD_BINS 8U
#define CAL_WALLWET_ECT_BINS    8U
#define CAL_WALLWET_TPS_BINS    4U
#define CAL_DEADTIME_VOLT_BINS  8U

/* -----------------------------------------------------------------------
 * Return codes
 * ----------------------------------------------------------------------- */

typedef enum {
    CAL_OK            = 0,
    CAL_ERR_CRC       = 1,   /**< Flash CRC mismatch            */
    CAL_ERR_VERSION   = 2,   /**< Schema version mismatch       */
    CAL_ERR_NOT_FOUND = 3,   /**< ID not in registry            */
    CAL_ERR_FLASH     = 4    /**< Flash write/erase failure     */
} cal_result_t;

/* -----------------------------------------------------------------------
 * API — lifecycle
 * ----------------------------------------------------------------------- */

/**
 * @brief  Load calibration from flash into RAM.
 *         Verifies CRC.  On failure, loads built-in defaults.
 *         [TASK ONLY]
 * @return CAL_OK or CAL_ERR_CRC / CAL_ERR_VERSION.
 */
cal_result_t calibration_load(void);

/**
 * @brief  Save current RAM calibration to flash.
 *         Writes CRC.  May take up to 50 ms (flash erase).
 *         [TASK ONLY — never call during engine running]
 * @return CAL_OK or CAL_ERR_FLASH.
 */
cal_result_t calibration_save(void);

/**
 * @brief  Load factory defaults into RAM (does NOT write to flash).
 *         [TASK ONLY]
 */
void calibration_load_defaults(void);

/* -----------------------------------------------------------------------
 * API — scalar access
 * ----------------------------------------------------------------------- */

/**
 * @brief  Read a scalar calibration value by ID.
 * @param  id     CAL_ID_xxx constant from calibration_ids.h.
 * @param  value  Output pointer.
 * @return CAL_OK or CAL_ERR_NOT_FOUND.
 */
cal_result_t calibration_get(uint16_t id, float *value);

/**
 * @brief  Write a scalar calibration value to RAM.
 * @param  id    CAL_ID_xxx constant.
 * @param  value New value.
 * @return CAL_OK or CAL_ERR_NOT_FOUND.
 */
cal_result_t calibration_set(uint16_t id, float value);

/* -----------------------------------------------------------------------
 * API — table access (interpolated)
 * ----------------------------------------------------------------------- */

/**
 * @brief  1D linear interpolation lookup.
 * @param  id     CAL_ID_xxx of a 1D table.
 * @param  x      Input axis value.
 * @param  result Output interpolated value.
 * @return CAL_OK or CAL_ERR_NOT_FOUND.
 */
cal_result_t calibration_lookup_1d(uint16_t id, float x, float *result);

/**
 * @brief  2D bilinear interpolation lookup.
 * @param  id     CAL_ID_xxx of a 2D table.
 * @param  x      Row axis value (e.g. RPM).
 * @param  y      Column axis value (e.g. load/MAP).
 * @param  result Output interpolated value.
 * @return CAL_OK or CAL_ERR_NOT_FOUND.
 */
cal_result_t calibration_lookup_2d(uint16_t id, float x, float y, float *result);

/* -----------------------------------------------------------------------
 * API — diagnostics
 * ----------------------------------------------------------------------- */

/** @brief  true if last calibration_load() succeeded with valid CRC. */
bool calibration_is_valid(void);

/** @brief  Stored data version from flash header. */
uint16_t calibration_get_version(void);

#endif /* CALIBRATION_H */
