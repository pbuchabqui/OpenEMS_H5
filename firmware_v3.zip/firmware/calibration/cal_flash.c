/**
 * @file    cal_flash.c
 * @brief   Calibration flash storage — STM32H562RGT6.
 *
 * STM32H562 flash specifics:
 *   - Bank 1: 0x08000000 – 0x080FFFFF (1 MB, 8 sectors × 128 KB)
 *   - Bank 2: 0x08100000 – 0x081FFFFF (1 MB, 8 sectors × 128 KB)
 *   - Calibration stored in Bank 2 Sector 0 (0x08100000, 128 KB)
 *   - Write granularity: 128 bits (16 bytes) — flash word
 *   - Writes must be to erased (0xFF) flash
 *
 * Layout within the sector (128 KB = 131072 bytes):
 *   Offset 0        : cal_flash_header_t (16 bytes, padded to flash word)
 *   Offset 16       : serialised scalar array
 *   Offset 16+scalars: serialised 1D table array
 *   Offset ...       : serialised 2D table array
 *   Last 4 bytes     : CRC32 of all preceding content
 *
 * [TASK ONLY] — never call from ISR or during engine running.
 */

#include "cal_flash.h"
#include "calibration.h"
#include "stm32h5xx.h"
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Flash layout
 * ----------------------------------------------------------------------- */

#define CAL_FLASH_BASE     0x08100000UL    /* Bank 2, Sector 0 */
#define CAL_FLASH_SIZE     (128U * 1024U)  /* 128 KB */
#define CAL_FLASH_BANK     FLASH_BANK_2
#define CAL_FLASH_SECTOR   FLASH_SECTOR_0

#define FLASH_WORD_BYTES   16U             /* 128-bit write granularity */
#define CAL_MAGIC          0xECU0CA15UL   /* "ECU CALS" magic */

/* -----------------------------------------------------------------------
 * Header (must be a multiple of FLASH_WORD_BYTES)
 * ----------------------------------------------------------------------- */

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t version;
    uint16_t scalar_count;
    uint16_t table_1d_count;
    uint16_t table_2d_count;
    uint8_t  _pad[4];
} cal_flash_header_t;

_Static_assert(sizeof(cal_flash_header_t) == FLASH_WORD_BYTES,
               "Header must be 16 bytes");

/* -----------------------------------------------------------------------
 * CRC32 (same poly as calibration.c)
 * ----------------------------------------------------------------------- */

static uint32_t crc32(const uint8_t *data, size_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    for (size_t i = 0; i < len; i++)
    {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc >> 1) ^ (0xEDB88320UL & -(crc & 1U));
    }
    return ~crc;
}

/* -----------------------------------------------------------------------
 * Flash unlock / lock
 * ----------------------------------------------------------------------- */

static void flash_unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = 0x45670123UL;
        FLASH->KEYR = 0xCDEF89ABUL;
    }
}

static void flash_lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

static void flash_wait_busy(void)
{
    while (FLASH->SR & FLASH_SR_BSY) {}
}

/* -----------------------------------------------------------------------
 * Sector erase
 * ----------------------------------------------------------------------- */

static bool flash_erase_sector(void)
{
    flash_wait_busy();

    /* Select bank 2 sector 0 */
    FLASH->CR &= ~(FLASH_CR_SNB_Msk | FLASH_CR_MER1 | FLASH_CR_MER2);
    FLASH->CR |= FLASH_CR_SER
               | (CAL_FLASH_SECTOR << FLASH_CR_SNB_Pos)
               | FLASH_CR_BKER;   /* bank 2 */

    FLASH->CR |= FLASH_CR_STRT;
    flash_wait_busy();

    bool ok = !(FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGSERR));
    FLASH->SR = FLASH->SR;   /* clear flags */
    FLASH->CR &= ~FLASH_CR_SER;
    return ok;
}

/* -----------------------------------------------------------------------
 * 128-bit flash write (one flash word)
 * dest must be 16-byte aligned; src must be 16-byte aligned
 * ----------------------------------------------------------------------- */

static bool flash_write_word(uint32_t dest, const uint8_t *src)
{
    /* Enable programming */
    FLASH->CR |= FLASH_CR_PG;

    const uint32_t *s = (const uint32_t *)(const void *)src;
    volatile uint32_t *d = (volatile uint32_t *)dest;

    /* Write all 4 32-bit words of the 128-bit flash word */
    for (int i = 0; i < 4; i++)
        d[i] = s[i];

    __DSB();
    flash_wait_busy();

    bool ok = !(FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGSERR));
    FLASH->SR = FLASH->SR;
    FLASH->CR &= ~FLASH_CR_PG;
    return ok;
}

/* -----------------------------------------------------------------------
 * Write buffer to flash (multiple flash words)
 * buf must be padded to multiple of FLASH_WORD_BYTES
 * ----------------------------------------------------------------------- */

static bool flash_write_buf(uint32_t dest, const uint8_t *buf, size_t len)
{
    for (size_t off = 0; off < len; off += FLASH_WORD_BYTES)
    {
        if (!flash_write_word(dest + off, buf + off))
            return false;
    }
    return true;
}

/* -----------------------------------------------------------------------
 * Serialisation buffer (static, no malloc)
 * Max calibration size: 32 scalars × 8B + 4 tables × 256B + 6 tables × 2176B
 * Allocate 16 KB to be safe.
 * ----------------------------------------------------------------------- */

#define SERIAL_BUF_SIZE  (16U * 1024U)
static uint8_t __attribute__((aligned(16))) s_serial_buf[SERIAL_BUF_SIZE];

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

cal_flash_result_t cal_flash_save(void)
{
    /* Serialise calibration into s_serial_buf */
    size_t pos = sizeof(cal_flash_header_t);  /* reserve space for header */

    /* Scalars — ask calibration module to fill them */
    uint16_t scalar_count = calibration_serialise_scalars(
        s_serial_buf + pos, SERIAL_BUF_SIZE - pos);
    pos += scalar_count * sizeof(cal_serial_scalar_t);

    uint16_t t1d_count = calibration_serialise_tables_1d(
        s_serial_buf + pos, SERIAL_BUF_SIZE - pos);
    pos += t1d_count * sizeof(cal_serial_table_1d_t);

    uint16_t t2d_count = calibration_serialise_tables_2d(
        s_serial_buf + pos, SERIAL_BUF_SIZE - pos);
    pos += t2d_count * sizeof(cal_serial_table_2d_t);

    /* Append CRC32 */
    uint32_t crc = crc32(s_serial_buf + sizeof(cal_flash_header_t),
                         pos - sizeof(cal_flash_header_t));
    memcpy(s_serial_buf + pos, &crc, sizeof(crc));
    pos += sizeof(crc);

    /* Pad to flash word size */
    while (pos % FLASH_WORD_BYTES) s_serial_buf[pos++] = 0xFFU;

    /* Write header */
    cal_flash_header_t hdr = {
        .magic          = CAL_MAGIC,
        .version        = calibration_get_version(),
        .scalar_count   = scalar_count,
        .table_1d_count = t1d_count,
        .table_2d_count = t2d_count,
        ._pad           = {0xFF, 0xFF, 0xFF, 0xFF}
    };
    memcpy(s_serial_buf, &hdr, sizeof(hdr));

    /* Erase and write */
    flash_unlock();
    bool ok = flash_erase_sector();
    if (ok)
        ok = flash_write_buf(CAL_FLASH_BASE, s_serial_buf, pos);
    flash_lock();

    return ok ? CAL_FLASH_OK : CAL_FLASH_ERR_WRITE;
}

cal_flash_result_t cal_flash_load(void)
{
    const uint8_t *flash = (const uint8_t *)CAL_FLASH_BASE;
    const cal_flash_header_t *hdr = (const cal_flash_header_t *)flash;

    if (hdr->magic != CAL_MAGIC)
        return CAL_FLASH_ERR_MAGIC;

    /* Determine payload size */
    size_t payload =
        hdr->scalar_count   * sizeof(cal_serial_scalar_t)  +
        hdr->table_1d_count * sizeof(cal_serial_table_1d_t) +
        hdr->table_2d_count * sizeof(cal_serial_table_2d_t);

    /* Verify CRC */
    uint32_t stored_crc;
    memcpy(&stored_crc, flash + sizeof(cal_flash_header_t) + payload, sizeof(uint32_t));
    uint32_t computed = crc32(flash + sizeof(cal_flash_header_t), payload);

    if (computed != stored_crc)
        return CAL_FLASH_ERR_CRC;

    /* Deserialise */
    const uint8_t *p = flash + sizeof(cal_flash_header_t);
    calibration_deserialise_scalars(p, hdr->scalar_count);
    p += hdr->scalar_count * sizeof(cal_serial_scalar_t);

    calibration_deserialise_tables_1d(p, hdr->table_1d_count);
    p += hdr->table_1d_count * sizeof(cal_serial_table_1d_t);

    calibration_deserialise_tables_2d(p, hdr->table_2d_count);

    return CAL_FLASH_OK;
}
