/**
 * @file    calibration_ids.h
 * @brief   Centralised registry of all calibration parameter IDs.
 *
 * Use these constants — never raw numbers — when calling:
 *   calibration_get_value(CAL_ID_xxx)
 *   calibration_set_value(CAL_ID_xxx, value)
 *
 * Ranges and units are documented per entry.
 * Adding a new parameter: append to the relevant section, never reuse an ID.
 */

#ifndef CALIBRATION_IDS_H
#define CALIBRATION_IDS_H

#include <stdint.h>

/* -----------------------------------------------------------------------
 * Fuel — scalars
 * ----------------------------------------------------------------------- */

/** Stoichiometric AFR [g/g]. Default 14.7 for gasoline. */
#define CAL_ID_STOICH_AFR            0x0001U

/** Injector flow rate [cc/min] at 3 bar reference pressure. */
#define CAL_ID_INJECTOR_FLOW_CC_MIN  0x0002U

/** Injector dead time base [µs] at 14 V. */
#define CAL_ID_INJ_DEADTIME_BASE_US  0x0003U

/** Injector dead time voltage coefficient [µs/V]. */
#define CAL_ID_INJ_DEADTIME_VCOEF    0x0004U

/** Minimum injector pulse width [µs]. */
#define CAL_ID_INJ_PW_MIN_US         0x0005U

/** Maximum injector pulse width [µs] (duty cycle limit). */
#define CAL_ID_INJ_PW_MAX_US         0x0006U

/* -----------------------------------------------------------------------
 * Fuel — per-cylinder trims (offset from neutral 1.0)
 * ----------------------------------------------------------------------- */

#define CAL_ID_FUEL_TRIM_CYL0        0x0010U   /**< Multiplier [0.5..1.5] */
#define CAL_ID_FUEL_TRIM_CYL1        0x0011U
#define CAL_ID_FUEL_TRIM_CYL2        0x0012U
#define CAL_ID_FUEL_TRIM_CYL3        0x0013U

/* -----------------------------------------------------------------------
 * Fuel — wall wetting (Aquino model)
 * ----------------------------------------------------------------------- */

/**
 * Direct-hit fraction X (2D table: ECT axis × TPS_rate axis).
 * Stored as a flattened array — accessor handles indexing.
 * Range: [0.1 .. 1.0]
 */
#define CAL_ID_WALLWET_X             0x0020U

/**
 * Wall film time constant tau (1D table: ECT axis).
 * Range: [0.01 .. 5.0 s]
 */
#define CAL_ID_WALLWET_TAU           0x0021U

/* -----------------------------------------------------------------------
 * Ignition — scalars
 * ----------------------------------------------------------------------- */

/** Base dwell time [µs] at 14 V. */
#define CAL_ID_IGN_DWELL_BASE_US     0x0100U

/** Dwell voltage coefficient [µs/V]. */
#define CAL_ID_IGN_DWELL_VCOEF       0x0101U

/** Maximum advance limit [°BTDC]. */
#define CAL_ID_IGN_ADVANCE_MAX_DEG   0x0102U

/** Minimum advance (retard) limit [°BTDC]. */
#define CAL_ID_IGN_ADVANCE_MIN_DEG   0x0103U

/* -----------------------------------------------------------------------
 * Ignition — knock retard
 * ----------------------------------------------------------------------- */

/** Knock retard step per event [°]. Default 1.5°. */
#define CAL_ID_KNOCK_RETARD_STEP_DEG  0x0110U

/** Knock recovery advance rate [°/rev]. Default 0.2°. */
#define CAL_ID_KNOCK_RECOVERY_DEG_REV 0x0111U

/** Knock detection threshold [-]. */
#define CAL_ID_KNOCK_THRESHOLD        0x0112U

/** Knock DSP bandpass centre frequency [Hz]. Engine-specific, e.g. 7500. */
#define CAL_ID_KNOCK_FREQ_HZ          0x0113U

/* -----------------------------------------------------------------------
 * Load model
 * ----------------------------------------------------------------------- */

/** VE table base ID (2D: RPM × MAP/load). Table accessed via cal_table API. */
#define CAL_ID_VE_TABLE              0x0200U

/** Lambda target table (2D: RPM × load). */
#define CAL_ID_LAMBDA_TARGET_TABLE   0x0201U

/** Spark advance table (2D: RPM × load). */
#define CAL_ID_SPARK_TABLE           0x0202U

/** Displacement per cylinder [cc]. */
#define CAL_ID_DISPLACEMENT_CC       0x0210U

/** Atmospheric pressure reference [kPa]. */
#define CAL_ID_BARO_REF_KPA          0x0211U

/* -----------------------------------------------------------------------
 * Sensor calibration
 * ----------------------------------------------------------------------- */

/** MAP sensor gain [kPa/V]. */
#define CAL_ID_MAP_GAIN              0x0300U
/** MAP sensor offset [kPa]. */
#define CAL_ID_MAP_OFFSET            0x0301U

/** TPS closed position [ADC counts]. */
#define CAL_ID_TPS_CLOSED_ADC        0x0302U
/** TPS wide-open position [ADC counts]. */
#define CAL_ID_TPS_OPEN_ADC          0x0303U

/** IAT thermistor R25 [Ω]. */
#define CAL_ID_IAT_R25               0x0304U
/** IAT thermistor Beta coefficient. */
#define CAL_ID_IAT_BETA              0x0305U

/** ECT thermistor R25 [Ω]. */
#define CAL_ID_ECT_R25               0x0306U
/** ECT thermistor Beta coefficient. */
#define CAL_ID_ECT_BETA              0x0307U

/* -----------------------------------------------------------------------
 * System
 * ----------------------------------------------------------------------- */

/** Cam sensor expected tooth index [0..57]. */
#define CAL_ID_CAM_EXPECTED_TOOTH    0x0400U

/** Number of engine cylinders. */
#define CAL_ID_NUM_CYLINDERS         0x0401U

/** Max RPM limit [RPM]. */
#define CAL_ID_RPM_LIMIT             0x0402U

/** Calibration data version — increment on schema change. */
#define CAL_ID_DATA_VERSION          0x0FF0U

/* -----------------------------------------------------------------------
 * Sentinel — IDs above this are invalid
 * ----------------------------------------------------------------------- */

#define CAL_ID_MAX                   0x0FFFU

#endif /* CALIBRATION_IDS_H */
