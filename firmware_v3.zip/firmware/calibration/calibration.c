/**
 * @file    calibration.c
 * @brief   Calibration system implementation.
 *
 * Flash layout (simplified for STM32H562 internal flash):
 *   Sector N   — calibration data
 *   Last 4 B   — CRC32 of all preceding bytes
 *
 * This implementation keeps all data in a single flat RAM struct for
 * fast access.  Tables are stored as value arrays; axis arrays are
 * stored separately and indexed by table ID.
 *
 * CRC32: standard polynomial 0xEDB88320 (Ethernet / PKZIP).
 */

#include "calibration.h"
#include <string.h>
#include <stddef.h>

/* -----------------------------------------------------------------------
 * CRC32 helper (software, no HAL dependency)
 * ----------------------------------------------------------------------- */

static uint32_t crc32_update(uint32_t crc, const uint8_t *data, size_t len)
{
    crc = ~crc;
    for (size_t i = 0; i < len; i++)
    {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc >> 1) ^ (0xEDB88320U & -(crc & 1U));
    }
    return ~crc;
}

/* -----------------------------------------------------------------------
 * Scalar store — simple key/value array
 * ----------------------------------------------------------------------- */

typedef struct {
    uint16_t id;
    float    value;
} cal_scalar_t;

/* Number of scalar entries */
#define CAL_SCALAR_COUNT  32U

static cal_scalar_t s_scalars[CAL_SCALAR_COUNT];
static uint8_t      s_scalar_count = 0;

static cal_scalar_t *find_scalar(uint16_t id)
{
    for (uint8_t i = 0; i < s_scalar_count; i++)
        if (s_scalars[i].id == id) return &s_scalars[i];
    return NULL;
}

static void set_scalar_default(uint16_t id, float value)
{
    cal_scalar_t *e = find_scalar(id);
    if (e)
    {
        e->value = value;
        return;
    }
    if (s_scalar_count < CAL_SCALAR_COUNT)
    {
        s_scalars[s_scalar_count].id    = id;
        s_scalars[s_scalar_count].value = value;
        s_scalar_count++;
    }
}

/* -----------------------------------------------------------------------
 * 1D table store
 * ----------------------------------------------------------------------- */

#define CAL_1D_MAX_BINS  16U
#define CAL_1D_MAX_TABLES 4U

typedef struct {
    uint16_t id;
    uint8_t  bins;
    float    axis[CAL_1D_MAX_BINS];
    float    values[CAL_1D_MAX_BINS];
} cal_table_1d_t;

static cal_table_1d_t s_tables_1d[CAL_1D_MAX_TABLES];
static uint8_t        s_table_1d_count = 0;

static cal_table_1d_t *find_table_1d(uint16_t id)
{
    for (uint8_t i = 0; i < s_table_1d_count; i++)
        if (s_tables_1d[i].id == id) return &s_tables_1d[i];
    return NULL;
}

/* -----------------------------------------------------------------------
 * 2D table store
 * ----------------------------------------------------------------------- */

#define CAL_2D_MAX_ROWS    16U
#define CAL_2D_MAX_COLS    16U
#define CAL_2D_MAX_TABLES   6U

typedef struct {
    uint16_t id;
    uint8_t  rows;
    uint8_t  cols;
    float    row_axis[CAL_2D_MAX_ROWS];
    float    col_axis[CAL_2D_MAX_COLS];
    float    values[CAL_2D_MAX_ROWS][CAL_2D_MAX_COLS];
} cal_table_2d_t;

static cal_table_2d_t s_tables_2d[CAL_2D_MAX_TABLES];
static uint8_t        s_table_2d_count = 0;

static cal_table_2d_t *find_table_2d(uint16_t id)
{
    for (uint8_t i = 0; i < s_table_2d_count; i++)
        if (s_tables_2d[i].id == id) return &s_tables_2d[i];
    return NULL;
}

/* -----------------------------------------------------------------------
 * State
 * ----------------------------------------------------------------------- */

static bool     s_valid   = false;
static uint16_t s_version = 0;

/* -----------------------------------------------------------------------
 * Interpolation helpers
 * ----------------------------------------------------------------------- */

/** Linear interpolation between two points. */
static float lerp(float x0, float x1, float y0, float y1, float x)
{
    if (x1 == x0) return y0;
    float t = (x - x0) / (x1 - x0);
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    return y0 + t * (y1 - y0);
}

/** Find lower bound index in a sorted axis array. */
static uint8_t axis_lower(const float *axis, uint8_t n, float x)
{
    if (x <= axis[0])       return 0;
    if (x >= axis[n - 1U]) return (uint8_t)(n - 2U);
    for (uint8_t i = 0; i < n - 1U; i++)
        if (x < axis[i + 1U]) return i;
    return (uint8_t)(n - 2U);
}

/* -----------------------------------------------------------------------
 * Default tables — VE, spark, lambda, wall-wetting, dead-time
 * These are placeholder values — tune on dyno.
 * ----------------------------------------------------------------------- */

static void init_default_ve_table(void)
{
    if (s_table_2d_count >= CAL_2D_MAX_TABLES) return;
    cal_table_2d_t *t = &s_tables_2d[s_table_2d_count++];
    t->id   = CAL_ID_VE_TABLE;
    t->rows = 8;
    t->cols = 8;

    /* RPM axis */
    const float rpms[8] = {500,1000,2000,3000,4000,5000,6000,8000};
    /* Load axis (MAP kPa) */
    const float loads[8] = {20,40,60,80,100,120,150,200};
    /* VE values [%] — flat 80% placeholder */
    for (uint8_t r = 0; r < 8; r++) t->row_axis[r] = rpms[r];
    for (uint8_t c = 0; c < 8; c++) t->col_axis[c] = loads[c];
    for (uint8_t r = 0; r < 8; r++)
        for (uint8_t c = 0; c < 8; c++)
            t->values[r][c] = 80.0f;
}

static void init_default_spark_table(void)
{
    if (s_table_2d_count >= CAL_2D_MAX_TABLES) return;
    cal_table_2d_t *t = &s_tables_2d[s_table_2d_count++];
    t->id   = CAL_ID_SPARK_TABLE;
    t->rows = 8;
    t->cols = 8;

    const float rpms[8]  = {500,1000,2000,3000,4000,5000,6000,8000};
    const float loads[8] = {20,40,60,80,100,120,150,200};
    for (uint8_t r = 0; r < 8; r++) t->row_axis[r] = rpms[r];
    for (uint8_t c = 0; c < 8; c++) t->col_axis[c] = loads[c];
    /* Advance [°BTDC] — conservative 15° flat placeholder */
    for (uint8_t r = 0; r < 8; r++)
        for (uint8_t c = 0; c < 8; c++)
            t->values[r][c] = 15.0f;
}

static void init_default_lambda_table(void)
{
    if (s_table_2d_count >= CAL_2D_MAX_TABLES) return;
    cal_table_2d_t *t = &s_tables_2d[s_table_2d_count++];
    t->id   = CAL_ID_LAMBDA_TARGET_TABLE;
    t->rows = 8;
    t->cols = 8;

    const float rpms[8]  = {500,1000,2000,3000,4000,5000,6000,8000};
    const float loads[8] = {20,40,60,80,100,120,150,200};
    for (uint8_t r = 0; r < 8; r++) t->row_axis[r] = rpms[r];
    for (uint8_t c = 0; c < 8; c++) t->col_axis[c] = loads[c];
    /* Stoich everywhere as safe default */
    for (uint8_t r = 0; r < 8; r++)
        for (uint8_t c = 0; c < 8; c++)
            t->values[r][c] = 1.0f;
}

static void init_default_wallwet_tau(void)
{
    if (s_table_1d_count >= CAL_1D_MAX_TABLES) return;
    cal_table_1d_t *t = &s_tables_1d[s_table_1d_count++];
    t->id   = CAL_ID_WALLWET_TAU;
    t->bins = 8;
    const float ect_axis[8]  = {-20,-10,0,20,40,60,80,100};
    const float tau_vals[8]  = {2.0f,1.5f,1.0f,0.5f,0.3f,0.15f,0.08f,0.05f};
    for (uint8_t i = 0; i < 8; i++)
    {
        t->axis[i]   = ect_axis[i];
        t->values[i] = tau_vals[i];
    }
}

/* -----------------------------------------------------------------------
 * Public — lifecycle
 * ----------------------------------------------------------------------- */

void calibration_load_defaults(void)
{
    s_scalar_count   = 0;
    s_table_1d_count = 0;
    s_table_2d_count = 0;

    /* Scalars */
    set_scalar_default(CAL_ID_STOICH_AFR,           14.7f);
    set_scalar_default(CAL_ID_INJECTOR_FLOW_CC_MIN, 440.0f);
    set_scalar_default(CAL_ID_INJ_DEADTIME_BASE_US, 800.0f);
    set_scalar_default(CAL_ID_INJ_DEADTIME_VCOEF,  -50.0f);
    set_scalar_default(CAL_ID_INJ_PW_MIN_US,        500.0f);
    set_scalar_default(CAL_ID_INJ_PW_MAX_US,       20000.0f);
    set_scalar_default(CAL_ID_FUEL_TRIM_CYL0,       1.0f);
    set_scalar_default(CAL_ID_FUEL_TRIM_CYL1,       1.0f);
    set_scalar_default(CAL_ID_FUEL_TRIM_CYL2,       1.0f);
    set_scalar_default(CAL_ID_FUEL_TRIM_CYL3,       1.0f);
    set_scalar_default(CAL_ID_IGN_DWELL_BASE_US,   3500.0f);
    set_scalar_default(CAL_ID_IGN_DWELL_VCOEF,     -100.0f);
    set_scalar_default(CAL_ID_IGN_ADVANCE_MAX_DEG,  50.0f);
    set_scalar_default(CAL_ID_IGN_ADVANCE_MIN_DEG, -10.0f);
    set_scalar_default(CAL_ID_KNOCK_RETARD_STEP_DEG, 1.5f);
    set_scalar_default(CAL_ID_KNOCK_RECOVERY_DEG_REV,0.2f);
    set_scalar_default(CAL_ID_KNOCK_THRESHOLD,       0.5f);
    set_scalar_default(CAL_ID_KNOCK_FREQ_HZ,        7500.0f);
    set_scalar_default(CAL_ID_DISPLACEMENT_CC,      400.0f);  /* per cylinder */
    set_scalar_default(CAL_ID_BARO_REF_KPA,         101.3f);
    set_scalar_default(CAL_ID_MAP_GAIN,              2.5f);
    set_scalar_default(CAL_ID_MAP_OFFSET,            0.0f);
    set_scalar_default(CAL_ID_RPM_LIMIT,            8000.0f);
    set_scalar_default(CAL_ID_DATA_VERSION,            1.0f);

    /* Tables */
    init_default_ve_table();
    init_default_spark_table();
    init_default_lambda_table();
    init_default_wallwet_tau();

    s_version = 1;
    s_valid   = true;
}

cal_result_t calibration_load(void)
{
    /*
     * Production: read from flash sector, verify CRC32.
     * Here we load defaults (flash driver is platform-specific).
     * Replace the body below with flash read + CRC check for production.
     */
    calibration_load_defaults();
    return CAL_OK;
}

cal_result_t calibration_save(void)
{
    /* Delegate to cal_flash which handles STM32H562 sector erase + write. */
    extern cal_flash_result_t cal_flash_save(void);
    return (cal_flash_save() == 0) ? CAL_OK : CAL_ERR_FLASH;
}

/* -----------------------------------------------------------------------
 * Public — scalar access
 * ----------------------------------------------------------------------- */

cal_result_t calibration_get(uint16_t id, float *value)
{
    cal_scalar_t *e = find_scalar(id);
    if (!e) return CAL_ERR_NOT_FOUND;
    *value = e->value;
    return CAL_OK;
}

cal_result_t calibration_set(uint16_t id, float value)
{
    cal_scalar_t *e = find_scalar(id);
    if (!e) return CAL_ERR_NOT_FOUND;
    e->value = value;
    return CAL_OK;
}

/* -----------------------------------------------------------------------
 * Public — table lookups
 * ----------------------------------------------------------------------- */

cal_result_t calibration_lookup_1d(uint16_t id, float x, float *result)
{
    cal_table_1d_t *t = find_table_1d(id);
    if (!t) return CAL_ERR_NOT_FOUND;
    uint8_t i = axis_lower(t->axis, t->bins, x);
    *result = lerp(t->axis[i], t->axis[i+1], t->values[i], t->values[i+1], x);
    return CAL_OK;
}

cal_result_t calibration_lookup_2d(uint16_t id, float x, float y, float *result)
{
    cal_table_2d_t *t = find_table_2d(id);
    if (!t) return CAL_ERR_NOT_FOUND;

    uint8_t ri = axis_lower(t->row_axis, t->rows, x);
    uint8_t ci = axis_lower(t->col_axis, t->cols, y);

    /* Bilinear interpolation */
    float r0 = lerp(t->col_axis[ci], t->col_axis[ci+1],
                    t->values[ri][ci], t->values[ri][ci+1], y);
    float r1 = lerp(t->col_axis[ci], t->col_axis[ci+1],
                    t->values[ri+1][ci], t->values[ri+1][ci+1], y);
    *result = lerp(t->row_axis[ri], t->row_axis[ri+1], r0, r1, x);
    return CAL_OK;
}

/* -----------------------------------------------------------------------
 * Public — diagnostics
 * ----------------------------------------------------------------------- */

bool calibration_is_valid(void)     { return s_valid;   }
uint16_t calibration_get_version(void) { return s_version; }
