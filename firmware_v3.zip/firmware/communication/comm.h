/**
 * @file    comm.h
 * @brief   Communication layer — FDCAN1 + UART.
 *
 * CAN frame IDs (11-bit standard):
 *   0x100  TX  RPM + sync state               (10 Hz)
 *   0x101  TX  MAP + TPS + IAT + ECT           (10 Hz)
 *   0x102  TX  Lambda + battery + load         (10 Hz)
 *   0x103  TX  Spark advance + knock retard    (10 Hz)
 *   0x104  TX  Injector PW cyl 0-3             (10 Hz)
 *   0x110  TX  Active DTC list                 (1 Hz)
 *   0x200  RX  Calibration write request
 *   0x201  RX  Calibration read request
 *   0x202  TX  Calibration read response
 *   0x2FF  RX  Calibration save-to-flash command
 */

#ifndef COMM_H
#define COMM_H

#include <stdint.h>
#include <stdbool.h>

/** @brief  Initialise FDCAN1 peripheral. [TASK ONLY] */
void comm_init(void);

/**
 * @brief  Process pending RX frames and queue TX telemetry.
 *         Call from main loop at background priority. [TASK ONLY]
 */
void comm_process(void);

/**
 * @brief  Transmit a raw CAN frame. ISR-safe.
 * @param  id    11-bit standard CAN ID.
 * @param  data  Payload bytes.
 * @param  len   Payload length [1..8].
 */
void comm_send_frame(uint32_t id, uint8_t *data, uint8_t len);

#endif /* COMM_H */
