/**
 * @file    comm.c
 * @brief   FDCAN1 communication — telemetry TX and calibration RX.
 *
 * FDCAN1 on STM32H562:
 *   - Clock: 20 MHz from PCLK1 (after PLL)
 *   - Bit rate: 500 kbit/s nominal
 *   - Tx buffer: 3 dedicated elements
 *   - Rx FIFO0: 8 elements
 *
 * Pin assignments (board-specific):
 *   FDCAN1_TX — PD1 (AF9)
 *   FDCAN1_RX — PD0 (AF9)
 */

#include "comm.h"
#include "../hal/hal.h"
#include "../engine/crank_decoder.h"
#include "../engine/engine_sync.h"
#include "../sensors/sensors.h"
#include "../ignition/ignition_control.h"
#include "../knock/knock_dsp.h"
#include "../diagnostics/diagnostics.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"
#include "../calibration/cal_flash.h"
#include "stm32h5xx.h"
#include <string.h>

/* -----------------------------------------------------------------------
 * FDCAN bit timing for 500 kbit/s @ 20 MHz
 * NominalPrescaler = 1, NominalTimeSeg1 = 31, NominalTimeSeg2 = 8
 * Bit rate = 20 MHz / (1 × (1 + 31 + 8)) = 500 kHz
 * ----------------------------------------------------------------------- */

#define CAN_PRESCALER   1U
#define CAN_TSEG1      31U
#define CAN_TSEG2       8U
#define CAN_SJW         8U

/* -----------------------------------------------------------------------
 * Telemetry TX IDs
 * ----------------------------------------------------------------------- */

#define CAN_ID_ENGINE      0x100U
#define CAN_ID_SENSORS     0x101U
#define CAN_ID_LAMBDA_BATT 0x102U
#define CAN_ID_IGNITION    0x103U
#define CAN_ID_FUEL        0x104U
#define CAN_ID_DTC         0x110U
#define CAN_ID_CAL_WRITE   0x200U
#define CAN_ID_CAL_READ_RQ 0x201U
#define CAN_ID_CAL_READ_RS 0x202U
#define CAN_ID_CAL_SAVE    0x2FFU

/* -----------------------------------------------------------------------
 * Telemetry rate control
 * ----------------------------------------------------------------------- */

static uint32_t s_last_telem_ts = 0;
static uint32_t s_last_dtc_ts   = 0;

#define TELEM_INTERVAL_US  100000U   /* 10 Hz */
#define DTC_INTERVAL_US   1000000U   /* 1 Hz  */

/* -----------------------------------------------------------------------
 * FDCAN init (minimal — full CMSIS-based init)
 * ----------------------------------------------------------------------- */

void comm_init(void)
{
    /* Enable FDCAN1 clock */
    RCC->APB1ENR2 |= RCC_APB1ENR2_FDCAN1EN;

    /* Enable GPIOD clock for CAN pins */
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIODEN;

    /* PD0=AF9 (FDCAN_RX), PD1=AF9 (FDCAN_TX) */
    GPIOD->MODER   &= ~(0xFUL);
    GPIOD->MODER   |=  (0xAUL);     /* AF mode */
    GPIOD->AFR[0]  &= ~(0xFFUL);
    GPIOD->AFR[0]  |=  (0x99UL);    /* AF9 for PD0 and PD1 */
    GPIOD->OSPEEDR |=  (0xFUL);     /* high speed */

    /* Enter init mode */
    FDCAN1->CCCR |= FDCAN_CCCR_INIT;
    while (!(FDCAN1->CCCR & FDCAN_CCCR_INIT)) {}
    FDCAN1->CCCR |= FDCAN_CCCR_CCE;

    /* Bit timing */
    FDCAN1->NBTP = ((CAN_SJW - 1U) << 25)
                 | ((CAN_PRESCALER - 1U) << 16)
                 | ((CAN_TSEG1 - 1U) << 8)
                 | ((CAN_TSEG2 - 1U) << 0);

    /* Classic CAN mode (not FD), no auto-retransmission */
    FDCAN1->CCCR &= ~FDCAN_CCCR_FDOE;
    FDCAN1->CCCR |=  FDCAN_CCCR_DAR;   /* disable auto-retransmission */

    /* Accept all messages into FIFO0 */
    FDCAN1->GFC &= ~(FDCAN_GFC_ANFS_Msk | FDCAN_GFC_ANFE_Msk);

    /* Enable RX FIFO0 new message interrupt */
    FDCAN1->IE  |= FDCAN_IE_RF0NE;
    FDCAN1->ILE |= FDCAN_ILE_EINT0;

    /* Leave init mode */
    FDCAN1->CCCR &= ~(FDCAN_CCCR_INIT | FDCAN_CCCR_CCE);
    while (FDCAN1->CCCR & FDCAN_CCCR_INIT) {}
}

/* -----------------------------------------------------------------------
 * Raw frame TX — writes to FDCAN Tx buffer 0
 * ----------------------------------------------------------------------- */

void comm_send_frame(uint32_t id, uint8_t *data, uint8_t len)
{
    if (len > 8U) len = 8U;

    /* Wait for Tx buffer 0 to be free (simple spin, bounded) */
    uint32_t timeout = 1000U;
    while ((FDCAN1->TXBRP & 1U) && timeout--) {}
    if (!timeout) return;

    /* Write message RAM Tx buffer 0 */
    volatile uint32_t *tb = (volatile uint32_t *)
        (SRAMCAN_BASE + FDCAN1->TXBC * 4U);  /* simplified — use actual offset */

    tb[0] = (id & 0x7FFU) << 18;   /* standard ID */
    tb[1] = (uint32_t)(len & 0xFU) << 16;

    uint8_t padded[8] = {0};
    for (uint8_t i = 0; i < len; i++) padded[i] = data[i];
    memcpy((void *)&tb[2], padded, 8);

    /* Request transmission */
    FDCAN1->TXBAR |= 1U;
}

/* -----------------------------------------------------------------------
 * Serialise helpers (big-endian for CAN convention)
 * ----------------------------------------------------------------------- */

static void pack_u16(uint8_t *buf, uint16_t v)
{
    buf[0] = (uint8_t)(v >> 8);
    buf[1] = (uint8_t)(v);
}

static void pack_i16(uint8_t *buf, int16_t v)
{
    pack_u16(buf, (uint16_t)v);
}

static uint16_t unpack_u16(const uint8_t *buf)
{
    return ((uint16_t)buf[0] << 8) | buf[1];
}

/* -----------------------------------------------------------------------
 * Telemetry TX
 * ----------------------------------------------------------------------- */

static void send_engine_frame(void)
{
    uint8_t d[8] = {0};
    pack_u16(&d[0], crank_get_rpm());
    d[2] = (uint8_t)engine_sync_get_state();
    d[3] = crank_get_tooth_index();
    comm_send_frame(CAN_ID_ENGINE, d, 4);
}

static void send_sensors_frame(void)
{
    sensor_data_t s = sensors_get();
    uint8_t d[8] = {0};
    pack_u16(&d[0], (uint16_t)(s.map * 10.0f));   /* MAP × 10 → 0.1 kPa LSB */
    pack_u16(&d[2], (uint16_t)(s.tps * 10.0f));   /* TPS × 10 → 0.1 % LSB  */
    pack_i16(&d[4], (int16_t)(s.iat * 10.0f));    /* IAT × 10 → 0.1 °C LSB */
    pack_i16(&d[6], (int16_t)(s.ect * 10.0f));    /* ECT × 10              */
    comm_send_frame(CAN_ID_SENSORS, d, 8);
}

static void send_ignition_frame(void)
{
    uint8_t d[8] = {0};
    pack_i16(&d[0], (int16_t)(ignition_get_knock_retard() * 10.0f));
    pack_u16(&d[2], (uint16_t)(knock_get_level() * 1000.0f));
    comm_send_frame(CAN_ID_IGNITION, d, 4);
}

static void send_dtc_frame(void)
{
    uint16_t dtcs[3] = {0};
    uint8_t  n = diagnostics_get_active(dtcs, 3);
    uint8_t  d[8] = {0};
    d[0] = n;
    for (uint8_t i = 0; i < n && i < 3U; i++)
        pack_u16(&d[1 + i * 2], dtcs[i]);
    comm_send_frame(CAN_ID_DTC, d, 7);
}

/* -----------------------------------------------------------------------
 * RX processing — calibration write/read/save
 * ----------------------------------------------------------------------- */

static void process_rx_frame(uint32_t id, const uint8_t *data, uint8_t len)
{
    if (id == CAN_ID_CAL_WRITE && len >= 6)
    {
        /* [u16 id][f32 value] */
        uint16_t cal_id = unpack_u16(data);
        float    value;
        memcpy(&value, data + 2, sizeof(float));
        calibration_set(cal_id, value);
    }
    else if (id == CAN_ID_CAL_READ_RQ && len >= 2)
    {
        uint16_t cal_id = unpack_u16(data);
        float    value  = 0.0f;
        calibration_get(cal_id, &value);
        uint8_t resp[6];
        pack_u16(resp, cal_id);
        memcpy(resp + 2, &value, sizeof(float));
        comm_send_frame(CAN_ID_CAL_READ_RS, resp, 6);
    }
    else if (id == CAN_ID_CAL_SAVE)
    {
        cal_flash_save();   /* WARNING: blocking ~50 ms — only safe at idle */
    }
}

/* -----------------------------------------------------------------------
 * Main process loop
 * ----------------------------------------------------------------------- */

void comm_process(void)
{
    uint32_t now = hal_timer_get();

    /* TX telemetry at 10 Hz */
    if ((now - s_last_telem_ts) >= TELEM_INTERVAL_US)
    {
        s_last_telem_ts = now;
        send_engine_frame();
        send_sensors_frame();
        send_ignition_frame();
    }

    /* TX DTC list at 1 Hz */
    if ((now - s_last_dtc_ts) >= DTC_INTERVAL_US)
    {
        s_last_dtc_ts = now;
        send_dtc_frame();
    }

    /* Poll RX FIFO0 */
    while (FDCAN1->RXF0S & FDCAN_RXF0S_F0FL_Msk)
    {
        uint8_t gi = (FDCAN1->RXF0S & FDCAN_RXF0S_F0GI_Msk)
                     >> FDCAN_RXF0S_F0GI_Pos;

        volatile uint32_t *rb = (volatile uint32_t *)
            (SRAMCAN_BASE + gi * 4U * 4U); /* simplified offset */

        uint32_t id  = (rb[0] >> 18) & 0x7FFU;
        uint8_t  dlc = (rb[1] >> 16) & 0xFU;
        uint8_t  payload[8];
        memcpy(payload, (const void *)&rb[2], 8);

        process_rx_frame(id, payload, dlc);

        /* Acknowledge read */
        FDCAN1->RXF0A = gi;
    }
}
