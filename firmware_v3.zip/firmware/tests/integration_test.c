/**
 * @file    integration_test.c
 * @brief   End-to-end integration test — 720° cycle with hal_mock.
 *
 * Simulates:
 *   1. Crank signal: full 720° (2 × 58 teeth) at 3000 RPM
 *   2. Cam pulse at expected tooth
 *   3. Engine control scheduling of injection + ignition
 *   4. hal_mock_tick() fires scheduled compare events
 *   5. Verifies GPIO state changes at correct times
 *
 * Build:
 *   gcc -I.. \
 *       engine/crank_decoder.c engine/engine_sync.c engine/angle_tracker.c \
 *       engine/event_scheduler.c \
 *       fuel/fuel_control.c fuel/load_model.c fuel/lambda_ctrl.c \
 *       ignition/ignition_control.c ignition/rev_limiter.c \
 *       knock/knock_dsp.c sensors/sensors.c \
 *       calibration/calibration.c diagnostics/safe_state.c \
 *       tests/hal_mock.c tests/integration_test.c \
 *       -o test_integration -lm -I.
 *   ./test_integration
 */

#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "tests/hal_mock.h"
#include "engine/crank_decoder.h"
#include "engine/engine_sync.h"
#include "engine/angle_tracker.h"
#include "engine/event_scheduler.h"
#include "fuel/fuel_control.h"
#include "fuel/load_model.h"
#include "fuel/lambda_ctrl.h"
#include "ignition/ignition_control.h"
#include "ignition/rev_limiter.h"
#include "sensors/sensors.h"
#include "calibration/calibration.h"
#include "calibration/calibration_ids.h"
#include "diagnostics/safe_state.h"

/* -----------------------------------------------------------------------
 * Re-implement engine_control_update() inline for the test
 * (avoids HAL-dependent main.c)
 * ----------------------------------------------------------------------- */

static void schedule_cylinder(uint8_t cyl)
{
    sensor_data_t sensors;
    memset(&sensors, 0, sizeof(sensors));
    sensors.map    = 100.0f;
    sensors.tps    = 30.0f;
    sensors.iat    = 25.0f;
    sensors.ect    = 90.0f;
    sensors.lambda = 1.0f;
    sensors.batt   = 14.0f;

    float rpm  = (float)crank_get_rpm();
    float load = load_compute_engine_load(&sensors);

    /* Fuel */
    float air_mass = load_compute_air_mass(&sensors, rpm);
    pw_us_t base_pw = fuel_compute_base_pw(air_mass, 1.0f);
    pw_us_t final_pw = fuel_apply_deadtime(
                           fuel_apply_cyl_trim(cyl,
                               fuel_clamp_pw(base_pw)),
                           sensors.batt);

    float inj_open_angle  = 300.0f + (float)cyl * 180.0f;
    if (inj_open_angle >= 720.0f) inj_open_angle -= 720.0f;
    uint32_t inj_open_ts  = angle_tracker_angle_to_timestamp(inj_open_angle);
    uint32_t inj_close_ts = inj_open_ts + final_pw;
    scheduler_schedule_injection(cyl, inj_open_ts, inj_close_ts);

    /* Ignition */
    ignition_output_t ign = ignition_compute(rpm, load, &sensors);
    float tdc_angle   = (float)cyl * 180.0f;
    float fire_angle  = tdc_angle - ign.advance_deg;
    float dwell_angle = fire_angle - 10.0f;
    if (fire_angle  < 0.0f) fire_angle  += 720.0f;
    if (dwell_angle < 0.0f) dwell_angle += 720.0f;

    uint32_t dwell_ts = angle_tracker_angle_to_timestamp(dwell_angle);
    uint32_t fire_ts  = angle_tracker_angle_to_timestamp(fire_angle);
    scheduler_schedule_ignition(cyl, dwell_ts, fire_ts);
}

/* -----------------------------------------------------------------------
 * Constants for 3000 RPM with 1 µs timer
 * period_us = 60_000_000 / (3000 × 58) ≈ 344 µs per tooth
 * ----------------------------------------------------------------------- */

#define TEST_RPM         3000U
#define TEST_PERIOD_US   344U

/* -----------------------------------------------------------------------
 * Test 1 — After 720° cycle + cam pulse, state is FULL_SYNC
 * ----------------------------------------------------------------------- */

static void test_full_720_sync(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    crank_init();
    engine_sync_init();
    angle_tracker_init();
    scheduler_init();
    fuel_init();
    ignition_init();

    uint32_t t = 0;

    /* Feed 5 teeth to prime prev_period, then gap tooth */
    for (int i = 0; i < 5; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    /* Gap */
    t += TEST_PERIOD_US * 5 / 2;
    hal_mock_set_timer(t);
    crank_tooth_interrupt(t);
    engine_sync_on_tooth(0, t);
    angle_tracker_on_tooth(0, t);

    /* Advance to cam expected tooth */
    for (int i = 0; i < ENGINE_CAM_EXPECTED_TOOTH; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }

    /* Cam pulse */
    engine_sync_on_cam_pulse(t);
    assert(engine_sync_get_state() == ENGINE_SYNC_FULL);
    printf("PASS test_full_720_sync — ENGINE_SYNC_FULL achieved\n");
}

/* -----------------------------------------------------------------------
 * Test 2 — Scheduler has events queued after scheduling cylinder 0
 * ----------------------------------------------------------------------- */

static void test_scheduler_queues_events(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    crank_init();
    engine_sync_init();
    angle_tracker_init();
    scheduler_init();
    fuel_init();
    ignition_init();

    /* Get to FULL_SYNC (reuse setup) */
    uint32_t t = 0;
    for (int i = 0; i < 5; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    t += TEST_PERIOD_US * 5 / 2;
    hal_mock_set_timer(t);
    crank_tooth_interrupt(t);
    engine_sync_on_tooth(0, t);
    angle_tracker_on_tooth(0, t);
    for (int i = 0; i < ENGINE_CAM_EXPECTED_TOOTH; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    engine_sync_on_cam_pulse(t);

    /* Schedule cylinder 0 */
    schedule_cylinder(0);

    /* Should have 4 events: dwell + fire + inject_open + inject_close */
    uint8_t pending = scheduler_get_pending_count();
    assert(pending == 4U);
    assert(scheduler_get_overflow_count() == 0U);
    printf("PASS test_scheduler_queues_events (pending=%u)\n", pending);
}

/* -----------------------------------------------------------------------
 * Test 3 — Compare ISR fires events and clears queue
 * ----------------------------------------------------------------------- */

static void test_compare_fires_and_clears(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    crank_init();
    engine_sync_init();
    angle_tracker_init();
    scheduler_init();
    fuel_init();
    ignition_init();

    /* Quick sync */
    uint32_t t = 0;
    for (int i = 0; i < 5; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    t += TEST_PERIOD_US * 5 / 2;
    hal_mock_set_timer(t); crank_tooth_interrupt(t);
    engine_sync_on_tooth(0, t); angle_tracker_on_tooth(0, t);
    for (int i = 0; i < ENGINE_CAM_EXPECTED_TOOTH; i++) {
        t += TEST_PERIOD_US;
        hal_mock_set_timer(t); crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    engine_sync_on_cam_pulse(t);

    schedule_cylinder(0);

    /* Advance timer far past all scheduled events and tick */
    hal_mock_advance_timer(100000U);   /* +100 ms — all events should have fired */
    hal_mock_tick();

    /* All 4 events should have fired and been cleared */
    uint8_t pending = scheduler_get_pending_count();
    assert(pending == 0U);
    assert(scheduler_get_overflow_count() == 0U);
    printf("PASS test_compare_fires_and_clears (pending=%u after tick)\n", pending);
}

/* -----------------------------------------------------------------------
 * Test 4 — No scheduler overflow for all 4 cylinders in one cycle
 * ----------------------------------------------------------------------- */

static void test_no_overflow_four_cylinders(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    crank_init();
    engine_sync_init();
    angle_tracker_init();
    scheduler_init();
    fuel_init();
    ignition_init();

    /* Quick sync */
    uint32_t t = 0;
    for (int i = 0; i < 5; i++) {
        t += TEST_PERIOD_US; hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    t += TEST_PERIOD_US * 5 / 2; hal_mock_set_timer(t);
    crank_tooth_interrupt(t); engine_sync_on_tooth(0, t);
    angle_tracker_on_tooth(0, t);
    for (int i = 0; i < ENGINE_CAM_EXPECTED_TOOTH; i++) {
        t += TEST_PERIOD_US; hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    engine_sync_on_cam_pulse(t);

    /* Schedule all 4 cylinders sequentially (fire previous before scheduling next) */
    for (uint8_t cyl = 0; cyl < 4; cyl++) {
        /* Fire all pending events from previous cylinder */
        hal_mock_advance_timer(50000U);
        hal_mock_tick();
        schedule_cylinder(cyl);
    }

    assert(scheduler_get_overflow_count() == 0U);
    printf("PASS test_no_overflow_four_cylinders\n");
}

/* -----------------------------------------------------------------------
 * Main
 * ----------------------------------------------------------------------- */

int main(void)
{
    printf("=== integration tests ===\n");
    test_full_720_sync();
    test_scheduler_queues_events();
    test_compare_fires_and_clears();
    test_no_overflow_four_cylinders();
    printf("All tests passed.\n");
    return 0;
}
