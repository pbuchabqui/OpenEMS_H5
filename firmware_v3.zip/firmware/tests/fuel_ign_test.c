/**
 * @file    fuel_ign_test.c
 * @brief   Unit tests for fuel_control and ignition_control pipelines.
 *
 * Build:
 *   gcc -I.. fuel_control.c load_model.c ignition_control.c \
 *       calibration/calibration.c ../tests/hal_mock.c \
 *       fuel_ign_test.c -o test_fuel_ign -lm
 *   ./test_fuel_ign
 */

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <stdbool.h>

#include "../tests/hal_mock.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"
#include "../fuel/fuel_control.h"
#include "../fuel/load_model.h"
#include "../ignition/ignition_control.h"
#include "../sensors/sensors.h"

/* Tolerance for float comparisons */
#define FLOAT_TOL  0.05f   /* 5% */

static bool approx(float a, float b, float tol)
{
    float ref = (fabsf(b) > 1e-6f) ? fabsf(b) : 1.0f;
    return (fabsf(a - b) / ref) < tol;
}

/* -----------------------------------------------------------------------
 * Test 1 — Base PW at stoichiometry matches analytic formula
 *
 * Given:
 *   air_mass = 200 mg/cyl/cycle
 *   lambda   = 1.0  (stoich AFR 14.7)
 *   fuel_mass = 200 / 14.7 = 13.605 mg
 *   injector  = 440 cc/min × 0.75 g/cc = 330 g/min = 5500 µg/µs
 *   base_pw   = 13605 µg / 5.5 µg/µs = 2474 µs
 * ----------------------------------------------------------------------- */

static void test_base_pw_stoich(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    fuel_init();

    float air_mass_mg    = 200.0f;
    float lambda_target  = 1.0f;
    float stoich_afr     = 14.7f;
    float flow_cc_min    = 440.0f;

    pw_us_t pw = fuel_compute_base_pw(air_mass_mg, lambda_target);

    /* Analytic */
    float fuel_mass_mg = air_mass_mg / (stoich_afr * lambda_target);
    float flow_mg_us   = (flow_cc_min * 0.75f * 1000.0f) / 60000000.0f;
    float expected_us  = fuel_mass_mg / flow_mg_us;

    assert(approx((float)pw, expected_us, FLOAT_TOL));
    printf("PASS test_base_pw_stoich (pw=%u µs, expected=%.0f µs)\n",
           pw, expected_us);
}

/* -----------------------------------------------------------------------
 * Test 2 — Base PW scales linearly with air mass
 * ----------------------------------------------------------------------- */

static void test_base_pw_linear_with_airmass(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    fuel_init();

    pw_us_t pw1 = fuel_compute_base_pw(100.0f, 1.0f);
    pw_us_t pw2 = fuel_compute_base_pw(200.0f, 1.0f);

    /* pw2 should be ~2× pw1 */
    float ratio = (float)pw2 / (float)pw1;
    assert(approx(ratio, 2.0f, FLOAT_TOL));
    printf("PASS test_base_pw_linear_with_airmass (ratio=%.3f)\n", ratio);
}

/* -----------------------------------------------------------------------
 * Test 3 — Wall wetting converges to zero correction at steady state
 *
 * If base_pw is constant across cycles, the wall-wetting correction
 * should eventually approach zero (film reaches equilibrium, no extra fuel needed).
 * ----------------------------------------------------------------------- */

static void test_wallwet_steady_state(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    fuel_init();

    wallwet_params_t ww = { .x = 0.7f, .tau = 0.1f };
    pw_us_t base_pw = 2000;
    float   dt_s    = 0.02f;   /* 50 Hz firing rate (1500 RPM, 4-cyl) */

    pw_us_t prev = 0;
    for (int i = 0; i < 200; i++)
        prev = fuel_apply_wallwet(0, base_pw, &ww, dt_s);

    /* After convergence, correction should be < 5% of base_pw */
    float correction_pct = fabsf((float)prev - (float)base_pw) / (float)base_pw;
    assert(correction_pct < 0.05f);
    printf("PASS test_wallwet_steady_state (final_pw=%u, base=%u, err=%.1f%%)\n",
           prev, base_pw, correction_pct * 100.0f);
}

/* -----------------------------------------------------------------------
 * Test 4 — Wall wetting adds fuel on tip-in (sudden increase)
 * ----------------------------------------------------------------------- */

static void test_wallwet_tip_in(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    fuel_init();

    wallwet_params_t ww = { .x = 0.5f, .tau = 0.3f };
    float dt_s = 0.02f;

    /* Idle steady state */
    for (int i = 0; i < 100; i++)
        fuel_apply_wallwet(1, 1000, &ww, dt_s);

    /* Sudden tip-in: 3× fuel demand */
    pw_us_t tip_in_pw = fuel_apply_wallwet(1, 3000, &ww, dt_s);

    /* Should be MORE than base 3000 (extra fuel to fill wall film) */
    assert(tip_in_pw > 3000);
    printf("PASS test_wallwet_tip_in (tip_in_pw=%u > 3000)\n", tip_in_pw);
}

/* -----------------------------------------------------------------------
 * Test 5 — Dead-time increases with lower battery voltage
 * ----------------------------------------------------------------------- */

static void test_deadtime_voltage_dependence(void)
{
    hal_mock_reset();
    calibration_load_defaults();

    pw_us_t pw_base = 2000;
    pw_us_t pw_14v  = fuel_apply_deadtime(pw_base, 14.0f);
    pw_us_t pw_12v  = fuel_apply_deadtime(pw_base, 12.0f);
    pw_us_t pw_16v  = fuel_apply_deadtime(pw_base, 16.0f);

    /* Lower voltage → longer dead time → higher total PW */
    assert(pw_12v > pw_14v);
    assert(pw_14v > pw_16v);
    printf("PASS test_deadtime_voltage_dependence "
           "(12V=%u > 14V=%u > 16V=%u µs)\n", pw_12v, pw_14v, pw_16v);
}

/* -----------------------------------------------------------------------
 * Test 6 — PW clamp: below minimum returns 0 (skip injection)
 * ----------------------------------------------------------------------- */

static void test_pw_clamp_min(void)
{
    hal_mock_reset();
    calibration_load_defaults();

    pw_us_t tiny = fuel_clamp_pw(100);   /* below min 500 µs */
    assert(tiny == 0U);
    printf("PASS test_pw_clamp_min (tiny PW clamped to 0)\n");
}

/* -----------------------------------------------------------------------
 * Test 7 — Spark advance from table is within calibrated limits
 * ----------------------------------------------------------------------- */

static void test_spark_advance_within_limits(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    ignition_init();

    sensor_data_t sensors = {
        .map = 100.0f, .maf = 0.0f, .tps = 50.0f,
        .iat = 25.0f, .ect = 90.0f, .lambda = 1.0f, .batt = 14.0f
    };

    float adv_min = -10.0f, adv_max = 50.0f;
    calibration_get(CAL_ID_IGN_ADVANCE_MIN_DEG, &adv_min);
    calibration_get(CAL_ID_IGN_ADVANCE_MAX_DEG, &adv_max);

    for (float rpm = 1000.0f; rpm <= 8000.0f; rpm += 500.0f) {
        for (float load = 20.0f; load <= 120.0f; load += 20.0f) {
            ignition_output_t out = ignition_compute(rpm, load, &sensors);
            assert(out.advance_deg >= adv_min);
            assert(out.advance_deg <= adv_max);
        }
    }
    printf("PASS test_spark_advance_within_limits\n");
}

/* -----------------------------------------------------------------------
 * Test 8 — Knock retard reduces advance; recovery restores it
 * ----------------------------------------------------------------------- */

static void test_knock_retard_and_recovery(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    ignition_init();

    sensor_data_t sensors = {
        .map = 100.0f, .maf = 0.0f, .tps = 50.0f,
        .iat = 25.0f, .ect = 90.0f, .lambda = 1.0f, .batt = 14.0f
    };

    ignition_output_t baseline = ignition_compute(3000.0f, 80.0f, &sensors);

    /* Apply 3 knock events */
    for (int i = 0; i < 3; i++)
        ignition_apply_knock_retard(0.0f);

    ignition_output_t retarded = ignition_compute(3000.0f, 80.0f, &sensors);
    assert(retarded.advance_deg < baseline.advance_deg);

    /* Recovery: call recover 100 times */
    for (int i = 0; i < 100; i++)
        ignition_recover_knock();

    ignition_output_t recovered = ignition_compute(3000.0f, 80.0f, &sensors);
    assert(approx(recovered.advance_deg, baseline.advance_deg, 0.02f));

    printf("PASS test_knock_retard_and_recovery "
           "(base=%.1f, retarded=%.1f, recovered=%.1f)\n",
           baseline.advance_deg, retarded.advance_deg, recovered.advance_deg);
}

/* -----------------------------------------------------------------------
 * Test 9 — Dwell decreases with higher battery voltage
 * ----------------------------------------------------------------------- */

static void test_dwell_voltage_dependence(void)
{
    hal_mock_reset();
    calibration_load_defaults();
    ignition_init();

    sensor_data_t s12 = { .ect=90,.iat=25,.batt=12.0f,.map=100,.tps=50,.lambda=1 };
    sensor_data_t s16 = { .ect=90,.iat=25,.batt=16.0f,.map=100,.tps=50,.lambda=1 };

    ignition_output_t out12 = ignition_compute(3000.0f, 80.0f, &s12);
    ignition_output_t out16 = ignition_compute(3000.0f, 80.0f, &s16);

    assert(out12.dwell_us > out16.dwell_us);
    printf("PASS test_dwell_voltage_dependence "
           "(12V=%u µs > 16V=%u µs)\n", out12.dwell_us, out16.dwell_us);
}

/* -----------------------------------------------------------------------
 * Main
 * ----------------------------------------------------------------------- */

int main(void)
{
    printf("=== fuel + ignition tests ===\n");
    test_base_pw_stoich();
    test_base_pw_linear_with_airmass();
    test_wallwet_steady_state();
    test_wallwet_tip_in();
    test_deadtime_voltage_dependence();
    test_pw_clamp_min();
    test_spark_advance_within_limits();
    test_knock_retard_and_recovery();
    test_dwell_voltage_dependence();
    printf("All tests passed.\n");
    return 0;
}
