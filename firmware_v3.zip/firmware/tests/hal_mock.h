/**
 * @file    hal_mock.h
 * @brief   Testable HAL mock for host-side unit tests.
 *
 * How it works
 * ------------
 * The production HAL (hal.c) defines hal_timer_get(), hal_gpio_set(), etc.
 * as direct register accesses.
 *
 * This mock replaces those with function-pointer hooks that test code can
 * override, plus in-memory state arrays to inspect GPIO and compare outputs.
 *
 * Usage in test files:
 *
 *   #include "hal_mock.h"
 *
 *   void test_missing_tooth_detection(void) {
 *       hal_mock_reset();
 *
 *       // Simulate 5 normal teeth then a gap
 *       uint32_t t = 0;
 *       for (int i = 0; i < 5; i++) {
 *           hal_mock_set_timer(t);
 *           crank_tooth_interrupt(t);
 *           t += 1000;  // 1000 µs per tooth = 6206 RPM
 *       }
 *       // Gap tooth: ~2x period
 *       hal_mock_set_timer(t + 2100);
 *       crank_tooth_interrupt(t + 2100);
 *
 *       assert(crank_is_synced() == true);
 *       assert(crank_get_tooth_index() == 0);
 *   }
 *
 * Note: tests include hal_mock.c instead of the production hal.c.
 *       Link: gcc crank_decoder.c hal_mock.c crank_decoder_test.c -o test
 */

#ifndef HAL_MOCK_H
#define HAL_MOCK_H

#include "hal.h"
#include <string.h>

/* -----------------------------------------------------------------------
 * Mock state
 * ----------------------------------------------------------------------- */

#define HAL_MOCK_MAX_PINS      32U
#define HAL_MOCK_MAX_CHANNELS  8U

extern uint32_t hal_mock_timer_value;
extern uint8_t  hal_mock_gpio_state[HAL_MOCK_MAX_PINS];
extern uint32_t hal_mock_compare_value[HAL_MOCK_MAX_CHANNELS];
extern bool     hal_mock_compare_armed[HAL_MOCK_MAX_CHANNELS];

/* -----------------------------------------------------------------------
 * Control functions (call from test code)
 * ----------------------------------------------------------------------- */

/** @brief  Reset all mock state to zero. Call at start of each test. */
static inline void hal_mock_reset(void)
{
    hal_mock_timer_value = 0;
    memset(hal_mock_gpio_state,     0, sizeof(hal_mock_gpio_state));
    memset(hal_mock_compare_value,  0, sizeof(hal_mock_compare_value));
    memset(hal_mock_compare_armed,  0, sizeof(hal_mock_compare_armed));
}

/** @brief  Advance the mock timer. */
static inline void hal_mock_set_timer(uint32_t t)
{
    hal_mock_timer_value = t;
}

/** @brief  Advance timer by delta µs. */
static inline void hal_mock_advance_timer(uint32_t delta_us)
{
    hal_mock_timer_value += delta_us;
}

/** @brief  Read GPIO pin state (0 or 1). */
static inline uint8_t hal_mock_get_gpio(uint8_t pin)
{
    return (pin < HAL_MOCK_MAX_PINS) ? hal_mock_gpio_state[pin] : 0;
}

/** @brief  Read compare channel target timestamp. */
static inline uint32_t hal_mock_get_compare(uint8_t ch)
{
    return (ch < HAL_MOCK_MAX_CHANNELS) ? hal_mock_compare_value[ch] : 0;
}

/** @brief  true if a compare channel is currently armed. */
static inline bool hal_mock_compare_is_armed(uint8_t ch)
{
    return (ch < HAL_MOCK_MAX_CHANNELS) ? hal_mock_compare_armed[ch] : false;
}

/**
 * @brief  Simulate time passing: if mock_timer passes an armed compare,
 *         call scheduler_on_compare_isr() automatically.
 *         Call this after advancing the timer in tests that check outputs.
 */
void hal_mock_tick(void);

#endif /* HAL_MOCK_H */
