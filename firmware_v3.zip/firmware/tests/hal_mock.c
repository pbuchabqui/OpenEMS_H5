/**
 * @file    hal_mock.c
 * @brief   HAL mock implementation — compile in place of hal.c for tests.
 */

#include "hal_mock.h"
#include "../engine/event_scheduler.h"

/* -----------------------------------------------------------------------
 * Mock state storage
 * ----------------------------------------------------------------------- */

uint32_t hal_mock_timer_value                        = 0;
uint8_t  hal_mock_gpio_state[HAL_MOCK_MAX_PINS]      = {0};
uint32_t hal_mock_compare_value[HAL_MOCK_MAX_CHANNELS] = {0};
bool     hal_mock_compare_armed[HAL_MOCK_MAX_CHANNELS] = {false};

/* -----------------------------------------------------------------------
 * HAL implementation — matches hal.h declarations
 * ----------------------------------------------------------------------- */

uint32_t hal_timer_get(void)
{
    return hal_mock_timer_value;
}

void hal_timer_set_compare(uint8_t channel, uint32_t timestamp)
{
    if (channel < HAL_MOCK_MAX_CHANNELS)
    {
        hal_mock_compare_value[channel] = timestamp;
        hal_mock_compare_armed[channel] = true;
    }
}

void hal_timer_clear_compare(uint8_t channel)
{
    if (channel < HAL_MOCK_MAX_CHANNELS)
        hal_mock_compare_armed[channel] = false;
}

void hal_gpio_set(uint8_t pin)
{
    if (pin < HAL_MOCK_MAX_PINS)
        hal_mock_gpio_state[pin] = 1;
}

void hal_gpio_clear(uint8_t pin)
{
    if (pin < HAL_MOCK_MAX_PINS)
        hal_mock_gpio_state[pin] = 0;
}

uint16_t hal_adc_read(uint8_t channel)
{
    (void)channel;
    return 2048U;  /* mid-scale default; override per test if needed */
}

hal_irq_state_t hal_enter_critical(void)
{
    /* No real IRQs in host tests — return dummy state */
    return 0U;
}

void hal_exit_critical(hal_irq_state_t state)
{
    (void)state;
}

void hal_cam_set_polarity(cam_polarity_t pol)
{
    (void)pol;
}

/* -----------------------------------------------------------------------
 * Mock tick: fire any armed compares that the timer has passed
 * ----------------------------------------------------------------------- */

void hal_mock_tick(void)
{
    for (uint8_t ch = 0; ch < HAL_MOCK_MAX_CHANNELS; ch++)
    {
        if (hal_mock_compare_armed[ch] &&
            hal_mock_timer_value >= hal_mock_compare_value[ch])
        {
            scheduler_on_compare_isr(ch);
        }
    }
}
