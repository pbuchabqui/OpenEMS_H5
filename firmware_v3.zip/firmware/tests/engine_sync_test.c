/**
 * @file    engine_sync_test.c
 * @brief   Unit tests for engine_sync module.
 *
 * Build:
 *   gcc -I.. engine_sync.c crank_decoder.c angle_tracker.c \
 *       ../tests/hal_mock.c engine_sync_test.c -o test_engine_sync -lm
 *   ./test_engine_sync
 */

#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>

#include "../tests/hal_mock.h"
#include "crank_decoder.h"
#include "engine_sync.h"
#include "angle_tracker.h"

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

/** Feed N normal teeth then a gap to get crank sync. */
static uint32_t get_crank_sync(uint32_t start_ts, uint32_t period_us)
{
    uint32_t t = start_ts;
    /* 5 normal teeth to build prev_period, then gap */
    for (int i = 0; i < 5; i++) {
        t += period_us;
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    /* Gap tooth */
    t += period_us * 5 / 2;
    crank_tooth_interrupt(t);
    engine_sync_on_tooth(crank_get_tooth_index(), t);
    angle_tracker_on_tooth(crank_get_tooth_index(), t);
    return t;
}

/** Feed N normal teeth after sync. */
static uint32_t feed_teeth_synced(uint32_t start_ts, uint32_t period_us,
                                  uint8_t count)
{
    uint32_t t = start_ts;
    for (uint8_t i = 0; i < count; i++) {
        t += period_us;
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);
    }
    return t;
}

/* -----------------------------------------------------------------------
 * Test 1 — State is NONE before any signal
 * ----------------------------------------------------------------------- */

static void test_initial_state_none(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    assert(engine_sync_get_state() == ENGINE_SYNC_NONE);
    printf("PASS test_initial_state_none\n");
}

/* -----------------------------------------------------------------------
 * Test 2 — State reaches CRANK_SYNC after missing tooth, before cam
 * ----------------------------------------------------------------------- */

static void test_crank_sync_before_cam(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    get_crank_sync(0, 1000);

    /* After gap: crank synced, but no cam pulse yet */
    assert(crank_is_synced() == true);
    /* engine_sync still NONE until we manually promote — in real flow
       the sync module needs a cam pulse. State stays NONE or CRANK_SYNC
       depending on implementation; we set it in on_tooth after crank syncs. */
    printf("PASS test_crank_sync_before_cam\n");
}

/* -----------------------------------------------------------------------
 * Test 3 — FULL_SYNC after cam pulse in expected window
 * ----------------------------------------------------------------------- */

static void test_full_sync_after_cam_in_window(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    uint32_t t = get_crank_sync(0, 1000);

    /* Advance to the expected cam tooth (ENGINE_CAM_EXPECTED_TOOTH = 10) */
    t = feed_teeth_synced(t, 1000, ENGINE_CAM_EXPECTED_TOOTH);

    /* Fire cam pulse at this tooth */
    engine_sync_on_cam_pulse(t);

    assert(engine_sync_get_state()    == ENGINE_SYNC_FULL);
    assert(engine_sync_cam_ok()       == true);
    assert(engine_sync_get_cylinder_index() == 0);
    printf("PASS test_full_sync_after_cam_in_window\n");
}

/* -----------------------------------------------------------------------
 * Test 4 — Cam pulse outside window degrades to CRANK_SYNC
 * ----------------------------------------------------------------------- */

static void test_cam_outside_window_degrades(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    uint32_t t = get_crank_sync(0, 1000);

    /* Advance to tooth 40 — far outside expected window (tooth 10 ± 5) */
    t = feed_teeth_synced(t, 1000, 40);

    engine_sync_on_cam_pulse(t);

    /* Should NOT promote to FULL_SYNC */
    assert(engine_sync_get_state() != ENGINE_SYNC_FULL);
    assert(engine_sync_cam_ok()    == false);
    printf("PASS test_cam_outside_window_degrades\n");
}

/* -----------------------------------------------------------------------
 * Test 5 — Cylinder index advances correctly over two revolutions
 * ----------------------------------------------------------------------- */

static void test_cylinder_sequence(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    uint32_t t = get_crank_sync(0, 1000);

    /* Cam pulse at expected tooth → FULL_SYNC, cyl index = 0 */
    t = feed_teeth_synced(t, 1000, ENGINE_CAM_EXPECTED_TOOTH);
    engine_sync_on_cam_pulse(t);
    assert(engine_sync_get_state() == ENGINE_SYNC_FULL);
    assert(engine_sync_get_cylinder_index() == 0);

    /* Complete first revolution (58 - ENGINE_CAM_EXPECTED_TOOTH teeth remain) */
    uint8_t remaining = 58 - ENGINE_CAM_EXPECTED_TOOTH;
    t = feed_teeth_synced(t, 1000, remaining);
    /* After one full revolution: tooth wraps 57→0, cylinder advances by 2 */
    assert(engine_sync_get_cylinder_index() == 2);

    /* Complete second revolution */
    t = feed_teeth_synced(t, 1000, 58);
    assert(engine_sync_get_cylinder_index() == 0);  /* wraps back to 0 */

    printf("PASS test_cylinder_sequence\n");
}

/* -----------------------------------------------------------------------
 * Test 6 — Cycle angle stays in [0, 720) range
 * ----------------------------------------------------------------------- */

static void test_cycle_angle_range(void)
{
    hal_mock_reset();
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    uint32_t t = get_crank_sync(0, 1000);
    t = feed_teeth_synced(t, 1000, ENGINE_CAM_EXPECTED_TOOTH);
    engine_sync_on_cam_pulse(t);

    /* Feed a full 720° cycle and check angle stays in range */
    for (int i = 0; i < 116; i++) {   /* 2 × 58 teeth */
        t += 1000;
        crank_tooth_interrupt(t);
        engine_sync_on_tooth(crank_get_tooth_index(), t);
        angle_tracker_on_tooth(crank_get_tooth_index(), t);

        float angle = engine_sync_get_cycle_angle();
        assert(angle >= 0.0f && angle < 720.0f);
    }

    printf("PASS test_cycle_angle_range\n");
}

/* -----------------------------------------------------------------------
 * Main
 * ----------------------------------------------------------------------- */

int main(void)
{
    printf("=== engine_sync tests ===\n");
    test_initial_state_none();
    test_crank_sync_before_cam();
    test_full_sync_after_cam_in_window();
    test_cam_outside_window_degrades();
    test_cylinder_sequence();
    test_cycle_angle_range();
    printf("All tests passed.\n");
    return 0;
}
