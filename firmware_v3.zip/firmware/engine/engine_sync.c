/**
 * @file    engine_sync.c
 * @brief   Engine phase synchronisation — inline-4, 60-2 + cam.
 *
 * 720° cycle layout (TDC = 0°, each cylinder 180° apart):
 *
 *   Cycle angle    Event
 *   0°             TDC cyl-1 compression  (firing order index 0)
 *   180°           TDC cyl-3 compression  (firing order index 1)
 *   360°           TDC cyl-4 compression  (firing order index 2)
 *   540°           TDC cyl-2 compression  (firing order index 3)
 *
 * Cam pulse expected at ENGINE_CAM_EXPECTED_TOOTH in the FIRST 360°
 * (revolution 0).  When we receive the cam pulse during revolution 0,
 * we know which half of the cycle we are in and can assign cycle angles.
 */

#include "engine_sync.h"
#include "crank_decoder.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Constants
 * ----------------------------------------------------------------------- */

#define TEETH_ACTIVE          58U
#define DEGREES_PER_TOOTH     (360.0f / TEETH_ACTIVE)   /* ≈ 6.207° */

/* -----------------------------------------------------------------------
 * Firing order: index → physical cylinder (1-based), inline-4 1-3-4-2
 * ----------------------------------------------------------------------- */

const uint8_t engine_firing_order[ENGINE_NUM_CYLINDERS] = { 1, 3, 4, 2 };

/* -----------------------------------------------------------------------
 * Private state
 * ----------------------------------------------------------------------- */

static volatile engine_sync_state_t s_sync_state      = ENGINE_SYNC_NONE;
static volatile uint8_t             s_cylinder_index  = 0;
static volatile float               s_cycle_angle     = 0.0f;
static volatile bool                s_cam_ok          = false;
static volatile bool                s_in_revolution1  = false; /**< true = second 360° half */

/* Cam validation */
static volatile uint8_t  s_tooth_at_cam  = 0xFF;  /**< tooth index when cam fired */

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

static inline bool tooth_in_cam_window(uint8_t tooth)
{
    /* Unsigned wrap-safe window check */
    int16_t diff = (int16_t)tooth - (int16_t)ENGINE_CAM_EXPECTED_TOOTH;
    if (diff < 0) diff = -diff;
    return ((uint8_t)diff <= ENGINE_CAM_WINDOW_TEETH);
}

/* -----------------------------------------------------------------------
 * Public — event inputs
 * ----------------------------------------------------------------------- */

void engine_sync_init(void)
{
    s_sync_state     = ENGINE_SYNC_NONE;
    s_cylinder_index = 0;
    s_cycle_angle    = 0.0f;
    s_cam_ok         = false;
    s_in_revolution1 = false;
    s_tooth_at_cam   = 0xFF;
}

void engine_sync_on_tooth(uint8_t tooth_index, uint32_t timestamp)
{
    (void)timestamp;  /* reserved for future inter-tooth angle tracking */

    if (s_sync_state == ENGINE_SYNC_NONE)
        return;

    /*
     * Detect revolution boundary: tooth_index wraps 57 → 0.
     * On each wrap we toggle the revolution half-flag.
     */
    static uint8_t s_prev_tooth = 0xFF;

    if (tooth_index == 0U && s_prev_tooth == TEETH_ACTIVE - 1U)
    {
        s_in_revolution1 = !s_in_revolution1;

        /* Update cylinder index on each revolution */
        if (s_sync_state == ENGINE_SYNC_FULL)
        {
            /* Two revolutions = one 4-stroke cycle = 4 cylinders.
             * Advance by 2 cylinders per revolution (720° / 4 = 180° apart,
             * but 2 cylinders fire per revolution). */
            s_cylinder_index = (s_cylinder_index + 2U) % ENGINE_NUM_CYLINDERS;
        }
    }
    s_prev_tooth = tooth_index;

    /* Update cycle angle */
    if (s_sync_state == ENGINE_SYNC_FULL)
    {
        float rev_angle = (float)tooth_index * DEGREES_PER_TOOTH;
        s_cycle_angle   = s_in_revolution1
                          ? (360.0f + rev_angle)
                          : rev_angle;
    }
}

void engine_sync_on_cam_pulse(uint32_t timestamp)
{
    (void)timestamp;

    uint8_t tooth = crank_get_tooth_index();

    if (s_sync_state == ENGINE_SYNC_NONE)
    {
        /* Can't use cam without crank sync */
        return;
    }

    s_tooth_at_cam = tooth;

    if (tooth_in_cam_window(tooth))
    {
        /*
         * Cam pulse received in expected window.
         * This pulse marks the start of revolution 0 (first 360°).
         * Set cylinder index to 0 (cyl-1 compression stroke approaching).
         */
        s_in_revolution1 = false;
        s_cylinder_index = 0;
        s_cam_ok         = true;
        s_sync_state     = ENGINE_SYNC_FULL;
    }
    else
    {
        /*
         * Cam pulse outside expected window — possible sync error or
         * a second cam tooth (if VVT fitted later).  Degrade to CRANK_SYNC.
         */
        s_cam_ok     = false;
        s_sync_state = ENGINE_SYNC_CRANK;
    }
}

/* -----------------------------------------------------------------------
 * Public — state queries (ISR-safe)
 * ----------------------------------------------------------------------- */

engine_sync_state_t engine_sync_get_state(void)
{
    hal_irq_state_t s = hal_enter_critical();
    engine_sync_state_t v = s_sync_state;
    hal_exit_critical(s);
    return v;
}

uint8_t engine_sync_get_cylinder_index(void)
{
    hal_irq_state_t s = hal_enter_critical();
    uint8_t v = s_cylinder_index;
    hal_exit_critical(s);
    return v;
}

float engine_sync_get_cycle_angle(void)
{
    hal_irq_state_t s = hal_enter_critical();
    float v = s_cycle_angle;
    hal_exit_critical(s);
    return v;
}

bool engine_sync_cam_ok(void)
{
    hal_irq_state_t s = hal_enter_critical();
    bool v = s_cam_ok;
    hal_exit_critical(s);
    return v;
}
