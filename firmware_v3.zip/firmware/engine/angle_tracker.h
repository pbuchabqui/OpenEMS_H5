/**
 * @file    angle_tracker.h
 * @brief   Sub-tooth crank angle interpolation with digital PLL.
 *
 * Provides real-time crank angle at any instant between teeth by
 * interpolating using elapsed timer ticks since the last tooth edge.
 *
 *   angle = tooth_base_angle + (ticks_since_tooth / tooth_period) * DEGREES_PER_TOOTH
 *
 * A simple digital PLL smooths the per-tooth period estimate to reduce
 * jitter from sensor noise and trigger wheel manufacturing tolerances.
 *
 * Resolution: better than 0.1° at all speeds (0.06° at 8000 RPM with
 * 1 µs timer).
 *
 * ISR safety:
 *   angle_tracker_on_tooth()  — called from crank ISR, writes state.
 *   angle_tracker_get_*()     — called from any context, use critical section.
 */

#ifndef ANGLE_TRACKER_H
#define ANGLE_TRACKER_H

#include <stdint.h>
#include <stdbool.h>

/** @brief  Initialise tracker state. */
void angle_tracker_init(void);

/**
 * @brief  Update on every tooth edge. Call from crank ISR.
 * @param  tooth_index   Current tooth [0..57].
 * @param  timestamp     HAL timer at edge [µs].
 */
void angle_tracker_on_tooth(uint8_t tooth_index, uint32_t timestamp);

/**
 * @brief  Get interpolated crank angle at the current instant [0..359.99°].
 *         ISR-safe.
 */
float angle_tracker_get_current(void);

/**
 * @brief  Get interpolated 720° cycle angle [0..719.99°].
 *         Valid only when engine is fully synchronised.
 *         ISR-safe.
 */
float angle_tracker_get_cycle_angle(void);

/**
 * @brief  Get smoothed tooth period from PLL [µs].
 *         ISR-safe.
 */
uint32_t angle_tracker_get_tooth_period(void);

/**
 * @brief  Convert a future cycle angle to a HAL timer timestamp [µs].
 *         Used by the event scheduler to program compare registers.
 * @param  target_cycle_angle  Target angle in 720° space [0..719.99°].
 * @return Absolute HAL timestamp when that angle will be reached.
 *         Returns 0 if angle has already passed or engine not synced.
 */
uint32_t angle_tracker_angle_to_timestamp(float target_cycle_angle);

#endif /* ANGLE_TRACKER_H */
