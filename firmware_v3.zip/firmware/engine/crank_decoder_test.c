/**
 * @file    crank_decoder_test.c
 * @brief   Unit tests for crank_decoder — compile with hal_mock.c.
 *
 * Build:
 *   gcc -I.. crank_decoder.c ../tests/hal_mock.c crank_decoder_test.c -o test_crank -lm
 *   ./test_crank
 */

#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <stdbool.h>

#include "../tests/hal_mock.h"
#include "crank_decoder.h"

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

/**
 * Feed N normal teeth at a constant period, then optionally a gap tooth.
 * Returns the timestamp after the last tooth.
 */
static uint32_t feed_teeth(uint32_t start_ts,
                            uint32_t period_us,
                            uint8_t  count,
                            bool     add_gap)
{
    uint32_t t = start_ts;
    for (uint8_t i = 0; i < count; i++)
    {
        t += period_us;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
    }
    if (add_gap)
    {
        /* Gap tooth: ~2.5× normal period */
        t += period_us * 5U / 2U;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
    }
    return t;
}

/* -----------------------------------------------------------------------
 * Test 1 — No sync before missing tooth
 * ----------------------------------------------------------------------- */

static void test_no_sync_before_gap(void)
{
    hal_mock_reset();
    crank_init();

    /* Feed 10 normal teeth — no gap yet */
    feed_teeth(0, 1000, 10, false);

    assert(crank_is_synced() == false);
    printf("PASS test_no_sync_before_gap\n");
}

/* -----------------------------------------------------------------------
 * Test 2 — Sync detected after missing tooth (fixes original bug)
 * ----------------------------------------------------------------------- */

static void test_sync_after_gap(void)
{
    hal_mock_reset();
    crank_init();

    /* Feed 5 normal teeth to build up a prev_period, then gap */
    feed_teeth(0, 1000, 5, true);

    assert(crank_is_synced() == true);
    assert(crank_get_tooth_index() == 0);
    printf("PASS test_sync_after_gap\n");
}

/* -----------------------------------------------------------------------
 * Test 3 — Tooth index increments correctly after sync
 * ----------------------------------------------------------------------- */

static void test_tooth_index_increments(void)
{
    hal_mock_reset();
    crank_init();

    uint32_t t = feed_teeth(0, 1000, 5, true);  /* gap → tooth_index = 0 */

    /* Next 3 teeth should be 1, 2, 3 */
    for (uint8_t expected = 1; expected <= 3; expected++)
    {
        t += 1000;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
        assert(crank_get_tooth_index() == expected);
    }
    printf("PASS test_tooth_index_increments\n");
}

/* -----------------------------------------------------------------------
 * Test 4 — RPM calculation at 6000 RPM
 *
 * At 6000 RPM: tooth period = 60_000_000 / (6000 * 58) ≈ 172 µs
 * After EMA warmup, crank_get_rpm() should be close to 6000.
 * ----------------------------------------------------------------------- */

static void test_rpm_calculation(void)
{
    hal_mock_reset();
    crank_init();

    const uint32_t period_us = 172U;  /* ≈ 6000 RPM */

    /* Feed enough teeth for EMA to settle (>32 teeth) */
    uint32_t t = feed_teeth(0, period_us, 10, true);  /* get sync */
    t = feed_teeth(t, period_us, 58, false);           /* full revolution */

    uint16_t rpm = crank_get_rpm();
    /* Allow ±300 RPM tolerance for EMA lag */
    assert(rpm > 5700 && rpm < 6300);
    printf("PASS test_rpm_calculation (got %u RPM)\n", rpm);
}

/* -----------------------------------------------------------------------
 * Test 5 — Tooth wrap at index 57 → 0
 * ----------------------------------------------------------------------- */

static void test_tooth_wrap(void)
{
    hal_mock_reset();
    crank_init();

    uint32_t t = feed_teeth(0, 1000, 5, true);  /* sync, index=0 */

    /* Advance to tooth 57 */
    for (uint8_t i = 1; i < 58; i++)
    {
        t += 1000;
        hal_mock_set_timer(t);
        crank_tooth_interrupt(t);
    }
    assert(crank_get_tooth_index() == 57);

    /* One more normal tooth — should wrap to 0 */
    t += 1000;
    hal_mock_set_timer(t);
    crank_tooth_interrupt(t);
    assert(crank_get_tooth_index() == 0);

    printf("PASS test_tooth_wrap\n");
}

/* -----------------------------------------------------------------------
 * Main
 * ----------------------------------------------------------------------- */

int main(void)
{
    printf("=== crank_decoder tests ===\n");
    test_no_sync_before_gap();
    test_sync_after_gap();
    test_tooth_index_increments();
    test_rpm_calculation();
    test_tooth_wrap();
    printf("All tests passed.\n");
    return 0;
}
