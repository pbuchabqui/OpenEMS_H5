/**
 * @file    combustion.c
 * @brief   Combustion analysis via crankshaft acceleration.
 *
 * Acceleration index:
 *   For each pair of consecutive teeth, instantaneous period P[n].
 *   Acceleration ∝ (P[n-1] - P[n]) / P[n-1]²
 *   Positive = speeding up (combustion event), negative = slowing down.
 *
 * Window: evaluate 6 teeth centred on TDC+45° for each cylinder.
 *   (6 teeth × 6.207° ≈ 37° window — captures peak combustion accel)
 *
 * Adaptive baseline: slow EMA of tooth periods during non-firing windows
 * represents the motoring (no-fuel) reference. Torque index normalises
 * actual acceleration against this baseline.
 *
 * Misfire confirmation: misfire_count[cyl] increments each cycle the
 * torque index is below MISFIRE_THRESHOLD, resets when above.
 * misfire_detected fires when count ≥ MISFIRE_CONFIRM_CYCLES.
 */

#include "combustion.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */

#define TEETH_ACTIVE             58U
#define WINDOW_TEETH             6U        /* teeth evaluated per cylinder */
#define MISFIRE_THRESHOLD        0.40f     /* torque index below = misfire  */
#define MISFIRE_CONFIRM_CYCLES   2U        /* consecutive cycles to confirm */
#define BASELINE_EMA_SHIFT       5U        /* alpha = 1/32 (slow)           */

/* TDC tooth index for each cylinder in firing order (inline-4, 1-3-4-2).
 * These are the tooth indices at TDC compression for each cylinder.
 * Tune after first engine run by checking against ignition timing marks. */
static const uint8_t CYL_TDC_TOOTH[COMBUSTION_NUM_CYLINDERS] = { 0, 29, 14, 43 };

/* -----------------------------------------------------------------------
 * Ring buffer for tooth periods
 * ----------------------------------------------------------------------- */

#define RING_SIZE  64U   /* must be power of 2, >= TEETH_ACTIVE */

static volatile uint32_t s_ring[RING_SIZE];
static volatile uint8_t  s_ring_head = 0;

/* -----------------------------------------------------------------------
 * Per-cylinder state
 * ----------------------------------------------------------------------- */

typedef struct {
    float    torque_index;
    float    baseline_period;     /* adaptive motoring period [µs] */
    uint8_t  misfire_count;
    bool     misfire_detected;
    float    window_accel_sum;
    uint8_t  window_teeth_seen;
    bool     window_active;
} cyl_state_t;

static cyl_state_t s_cyl[COMBUSTION_NUM_CYLINDERS];

/* -----------------------------------------------------------------------
 * Helpers
 * ----------------------------------------------------------------------- */

static inline uint32_t ring_get(uint8_t idx)
{
    return s_ring[idx & (RING_SIZE - 1U)];
}

/* Compute normalised acceleration for current tooth vs previous */
static float tooth_accel(uint32_t p_prev, uint32_t p_curr)
{
    if (p_prev == 0U || p_curr == 0U) return 0.0f;
    /* accel = (p_prev - p_curr) / p_prev  (dimensionless, positive = speeding up) */
    return ((float)p_prev - (float)p_curr) / (float)p_prev;
}

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void combustion_init(void)
{
    for (uint8_t i = 0; i < RING_SIZE; i++) s_ring[i] = 0;
    s_ring_head = 0;

    for (uint8_t c = 0; c < COMBUSTION_NUM_CYLINDERS; c++)
    {
        s_cyl[c].torque_index      = 1.0f;
        s_cyl[c].baseline_period   = 1000.0f;  /* seed: 1 ms/tooth ≈ 1034 RPM */
        s_cyl[c].misfire_count     = 0;
        s_cyl[c].misfire_detected  = false;
        s_cyl[c].window_accel_sum  = 0.0f;
        s_cyl[c].window_teeth_seen = 0;
        s_cyl[c].window_active     = false;
    }
}

void combustion_update(uint8_t tooth_index, uint32_t tooth_time)
{
    /* Store in ring buffer */
    s_ring[s_ring_head & (RING_SIZE - 1U)] = tooth_time;
    s_ring_head++;

    uint32_t p_prev = ring_get(s_ring_head - 2U);
    uint32_t p_curr = tooth_time;

    /* Check if this tooth starts or continues a cylinder window */
    for (uint8_t c = 0; c < COMBUSTION_NUM_CYLINDERS; c++)
    {
        uint8_t tdc  = CYL_TDC_TOOTH[c];
        uint8_t dist = (tooth_index >= tdc)
                       ? (tooth_index - tdc)
                       : (TEETH_ACTIVE + tooth_index - tdc);

        /* Window: TDC+2 to TDC+8 teeth (after TDC, during power stroke) */
        if (dist == 2U)
        {
            s_cyl[c].window_active     = true;
            s_cyl[c].window_accel_sum  = 0.0f;
            s_cyl[c].window_teeth_seen = 0;
        }

        if (s_cyl[c].window_active)
        {
            float a = tooth_accel(p_prev, p_curr);
            s_cyl[c].window_accel_sum  += a;
            s_cyl[c].window_teeth_seen++;

            if (s_cyl[c].window_teeth_seen >= WINDOW_TEETH)
            {
                /* Window complete — compute torque index */
                float avg_accel   = s_cyl[c].window_accel_sum / (float)WINDOW_TEETH;
                float baseline_a  = 0.0f; /* motoring = near-zero accel */

                /* Normalise: index 1.0 = healthy combustion event.
                   Use baseline period to estimate expected accel. */
                float idx = (s_cyl[c].baseline_period > 0.0f)
                            ? (avg_accel / (1.0f / s_cyl[c].baseline_period) + 1.0f)
                            : 1.0f;
                (void)baseline_a;

                /* Clamp to [0, 3] */
                if (idx < 0.0f) idx = 0.0f;
                if (idx > 3.0f) idx = 3.0f;

                hal_irq_state_t irqs = hal_enter_critical();
                s_cyl[c].torque_index = idx;
                hal_exit_critical(irqs);

                /* Misfire detection */
                if (idx < MISFIRE_THRESHOLD)
                {
                    s_cyl[c].misfire_count++;
                    if (s_cyl[c].misfire_count >= MISFIRE_CONFIRM_CYCLES)
                        s_cyl[c].misfire_detected = true;
                }
                else
                {
                    s_cyl[c].misfire_count = 0;
                }

                s_cyl[c].window_active = false;
            }
        }
        else
        {
            /* Outside window: update motoring baseline with slow EMA */
            s_cyl[c].baseline_period +=
                ((float)p_curr - s_cyl[c].baseline_period)
                / (float)(1U << BASELINE_EMA_SHIFT);
        }
    }
}

float combustion_get_torque_index(uint8_t cylinder)
{
    if (cylinder >= COMBUSTION_NUM_CYLINDERS) return 0.0f;
    hal_irq_state_t irqs = hal_enter_critical();
    float v = s_cyl[cylinder].torque_index;
    hal_exit_critical(irqs);
    return v;
}

bool combustion_misfire_detected(uint8_t cylinder)
{
    if (cylinder >= COMBUSTION_NUM_CYLINDERS) return false;
    hal_irq_state_t irqs = hal_enter_critical();
    bool v = s_cyl[cylinder].misfire_detected;
    hal_exit_critical(irqs);
    return v;
}

void combustion_clear_misfire(uint8_t cylinder)
{
    if (cylinder >= COMBUSTION_NUM_CYLINDERS) return;
    hal_irq_state_t irqs = hal_enter_critical();
    s_cyl[cylinder].misfire_detected = false;
    s_cyl[cylinder].misfire_count    = 0;
    hal_exit_critical(irqs);
}
