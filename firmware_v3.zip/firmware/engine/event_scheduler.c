/**
 * @file    event_scheduler.c
 * @brief   Angle-based event scheduler — hardware compare register backend.
 *
 * HAL compare channel assignment:
 *   Channel 0-3  → ignition coils (cyl 0-3)
 *   Channel 4-7  → injectors      (cyl 0-3)
 *
 * Each cylinder therefore uses two channels at any time:
 *   one for DWELL/FIRE (shared — dwell arms ch0, fire reprograms ch0)
 *   one for OPEN/CLOSE (shared — open arms ch4, close reprograms ch4)
 */

#include "event_scheduler.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Internal queue
 * ----------------------------------------------------------------------- */

static sched_event_t s_queue[SCHEDULER_QUEUE_SIZE];
static uint32_t      s_overflow_count = 0;

/* Map: hw_channel → queue slot (-1 = unassigned) */
#define MAX_HW_CHANNELS  8U
static int8_t s_channel_to_slot[MAX_HW_CHANNELS];

/* -----------------------------------------------------------------------
 * Helper: GPIO pin for each event type + cylinder
 * These must match the board schematic.  Placeholder values here.
 * ----------------------------------------------------------------------- */

static const uint8_t IGN_PINS[4]    = { 10, 11, 12, 13 };   /* coil drivers */
static const uint8_t INJECT_PINS[4] = { 20, 21, 22, 23 };   /* injector drivers */

/* -----------------------------------------------------------------------
 * Init
 * ----------------------------------------------------------------------- */

void scheduler_init(void)
{
    for (uint8_t i = 0; i < SCHEDULER_QUEUE_SIZE; i++)
        s_queue[i].type = SCHED_EVENT_NONE;

    for (uint8_t i = 0; i < MAX_HW_CHANNELS; i++)
        s_channel_to_slot[i] = -1;

    s_overflow_count = 0;
}

/* -----------------------------------------------------------------------
 * Internal: find free slot
 * ----------------------------------------------------------------------- */

static int8_t find_free_slot(void)
{
    for (uint8_t i = 0; i < SCHEDULER_QUEUE_SIZE; i++)
    {
        if (s_queue[i].type == SCHED_EVENT_NONE)
            return (int8_t)i;
    }
    return -1;
}

/* -----------------------------------------------------------------------
 * Internal: assign HW channel for event type + cylinder
 *
 * Ignition events (dwell + fire) share one channel per cylinder.
 * Injection events (open + close) share one channel per cylinder.
 * ----------------------------------------------------------------------- */

static uint8_t channel_for_event(sched_event_type_t type, uint8_t cylinder)
{
    if (type == SCHED_EVENT_IGN_DWELL || type == SCHED_EVENT_IGN_FIRE)
        return cylinder;              /* channels 0-3 */
    else
        return 4U + cylinder;         /* channels 4-7 */
}

/* -----------------------------------------------------------------------
 * Public: schedule_event
 * ----------------------------------------------------------------------- */

bool scheduler_schedule_event(sched_event_type_t type,
                               uint8_t            cylinder,
                               uint32_t           timestamp)
{
    hal_irq_state_t irqs = hal_enter_critical();

    int8_t slot = find_free_slot();
    if (slot < 0)
    {
        s_overflow_count++;
        hal_exit_critical(irqs);
        return false;
    }

    uint8_t ch = channel_for_event(type, cylinder);

    s_queue[slot].type       = type;
    s_queue[slot].cylinder   = cylinder;
    s_queue[slot].timestamp  = timestamp;
    s_queue[slot].hw_channel = ch;

    s_channel_to_slot[ch] = slot;

    hal_timer_set_compare(ch, timestamp);

    hal_exit_critical(irqs);
    return true;
}

/* -----------------------------------------------------------------------
 * Public: convenience wrappers
 * ----------------------------------------------------------------------- */

bool scheduler_schedule_ignition(uint8_t  cylinder,
                                  uint32_t dwell_start_ts,
                                  uint32_t fire_ts)
{
    bool ok = true;
    ok &= scheduler_schedule_event(SCHED_EVENT_IGN_DWELL, cylinder, dwell_start_ts);
    ok &= scheduler_schedule_event(SCHED_EVENT_IGN_FIRE,  cylinder, fire_ts);
    return ok;
}

bool scheduler_schedule_injection(uint8_t  cylinder,
                                   uint32_t open_ts,
                                   uint32_t close_ts)
{
    bool ok = true;
    ok &= scheduler_schedule_event(SCHED_EVENT_INJECT_OPEN,  cylinder, open_ts);
    ok &= scheduler_schedule_event(SCHED_EVENT_INJECT_CLOSE, cylinder, close_ts);
    return ok;
}

/* -----------------------------------------------------------------------
 * Public: compare ISR handler
 * Must complete < 2 µs.
 * ----------------------------------------------------------------------- */

void scheduler_on_compare_isr(uint8_t hw_channel)
{
    if (hw_channel >= MAX_HW_CHANNELS)
        return;

    int8_t slot = s_channel_to_slot[hw_channel];
    if (slot < 0 || slot >= SCHEDULER_QUEUE_SIZE)
        return;

    sched_event_t *ev = &s_queue[slot];

    /* Execute GPIO action */
    switch (ev->type)
    {
        case SCHED_EVENT_IGN_DWELL:
            hal_gpio_set(IGN_PINS[ev->cylinder]);
            break;

        case SCHED_EVENT_IGN_FIRE:
            hal_gpio_clear(IGN_PINS[ev->cylinder]);
            break;

        case SCHED_EVENT_INJECT_OPEN:
            hal_gpio_set(INJECT_PINS[ev->cylinder]);
            break;

        case SCHED_EVENT_INJECT_CLOSE:
            hal_gpio_clear(INJECT_PINS[ev->cylinder]);
            break;

        default:
            break;
    }

    /* Clear slot */
    ev->type = SCHED_EVENT_NONE;
    s_channel_to_slot[hw_channel] = -1;
    hal_timer_clear_compare(hw_channel);
}

/* -----------------------------------------------------------------------
 * Diagnostics
 * ----------------------------------------------------------------------- */

uint32_t scheduler_get_overflow_count(void)
{
    hal_irq_state_t s = hal_enter_critical();
    uint32_t v = s_overflow_count;
    hal_exit_critical(s);
    return v;
}

void scheduler_reset_overflow_count(void)
{
    hal_irq_state_t s = hal_enter_critical();
    s_overflow_count = 0;
    hal_exit_critical(s);
}

uint8_t scheduler_get_pending_count(void)
{
    uint8_t count = 0;
    hal_irq_state_t s = hal_enter_critical();
    for (uint8_t i = 0; i < SCHEDULER_QUEUE_SIZE; i++)
        if (s_queue[i].type != SCHED_EVENT_NONE) count++;
    hal_exit_critical(s);
    return count;
}
