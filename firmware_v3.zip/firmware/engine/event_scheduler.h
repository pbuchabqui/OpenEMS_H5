/**
 * @file    event_scheduler.h
 * @brief   Angle-based event scheduler using hardware timer compare registers.
 *
 * Events are programmed as absolute HAL timer timestamps derived from
 * angle_tracker_angle_to_timestamp().  The hardware compare ISR fires the
 * output (ignition dwell start/end, injector open/close) directly.
 *
 * Queue design
 * ------------
 * Fixed-size array of SCHEDULER_QUEUE_SIZE slots — no dynamic allocation.
 * Slots are one-shot: they are cleared after the compare fires.
 *
 * Each event has a type (IGNITION_DWELL, IGNITION_FIRE, INJECT_OPEN,
 * INJECT_CLOSE) and a cylinder index [0..3].
 *
 * Overflow policy
 * ---------------
 * If all slots are occupied when schedule_event() is called, the new event
 * is DROPPED and a diagnostic counter is incremented.  The caller can check
 * scheduler_get_overflow_count().  This is preferable to silent overwrite of
 * an already-armed event.
 *
 * ISR safety
 * ----------
 * schedule_event()     — may be called from task context only.
 *                        Uses critical section internally.
 * scheduler_on_compare — called from compare ISR, executes the GPIO action
 *                        and clears the slot. < 2 µs.
 */

#ifndef EVENT_SCHEDULER_H
#define EVENT_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */

/**
 * Maximum number of simultaneously pending events.
 * Inline-4 needs at most 8 at any time:
 *   4 cylinders × (INJECT_OPEN + INJECT_CLOSE) = 8
 *   4 cylinders × (IGN_DWELL  + IGN_FIRE)      = 8
 * We keep 12 for margin.
 */
#define SCHEDULER_QUEUE_SIZE  12U

/* -----------------------------------------------------------------------
 * Event types
 * ----------------------------------------------------------------------- */

typedef enum {
    SCHED_EVENT_NONE         = 0,
    SCHED_EVENT_IGN_DWELL    = 1,  /**< Start coil charge (GPIO set)   */
    SCHED_EVENT_IGN_FIRE     = 2,  /**< Release coil — spark (GPIO clr) */
    SCHED_EVENT_INJECT_OPEN  = 3,  /**< Open injector (GPIO set)        */
    SCHED_EVENT_INJECT_CLOSE = 4   /**< Close injector (GPIO clr)       */
} sched_event_type_t;

typedef struct {
    sched_event_type_t type;
    uint8_t            cylinder;    /**< [0..NUM_CYLINDERS-1] */
    uint32_t           timestamp;   /**< Absolute HAL timer value [µs] */
    uint8_t            hw_channel;  /**< HAL compare channel assigned  */
} sched_event_t;

/* -----------------------------------------------------------------------
 * API
 * ----------------------------------------------------------------------- */

/** @brief  Initialise scheduler. Call before enabling IRQs. */
void scheduler_init(void);

/**
 * @brief  Schedule a future event.
 * @param  type       Event type.
 * @param  cylinder   Cylinder index [0..3].
 * @param  timestamp  Absolute HAL timer value when event should fire [µs].
 * @return true if event was queued, false if queue was full (overflow).
 *
 * [TASK ONLY] — do not call from ISR.
 */
bool scheduler_schedule_event(sched_event_type_t type,
                               uint8_t            cylinder,
                               uint32_t           timestamp);

/**
 * @brief  Convenience wrappers for common event pairs.
 *
 * @param  cylinder          Cylinder index [0..3].
 * @param  dwell_start_ts    HAL timestamp to start coil charge [µs].
 * @param  fire_ts           HAL timestamp to fire spark [µs].
 */
bool scheduler_schedule_ignition(uint8_t  cylinder,
                                  uint32_t dwell_start_ts,
                                  uint32_t fire_ts);

/**
 * @param  cylinder     Cylinder index [0..3].
 * @param  open_ts      HAL timestamp to open injector [µs].
 * @param  close_ts     HAL timestamp to close injector [µs].
 */
bool scheduler_schedule_injection(uint8_t  cylinder,
                                   uint32_t open_ts,
                                   uint32_t close_ts);

/**
 * @brief  Called from hardware compare ISR when a compare fires.
 * @param  hw_channel  HAL compare channel that triggered.
 */
void scheduler_on_compare_isr(uint8_t hw_channel);

/** @brief  Number of events dropped due to queue full since last reset. */
uint32_t scheduler_get_overflow_count(void);

/** @brief  Reset overflow counter. */
void scheduler_reset_overflow_count(void);

/** @brief  Number of events currently pending in the queue. */
uint8_t scheduler_get_pending_count(void);

#endif /* EVENT_SCHEDULER_H */
