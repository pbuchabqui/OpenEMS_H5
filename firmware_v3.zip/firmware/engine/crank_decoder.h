/**
 * @file    crank_decoder.h
 * @brief   60-2 crank wheel decoder — public interface.
 *
 * All getters are ISR-safe (use internal critical section).
 * crank_tooth_interrupt() must be called from the input-capture ISR only.
 */

#ifndef CRANK_DECODER_H
#define CRANK_DECODER_H

#include <stdint.h>
#include <stdbool.h>

/** @brief  Initialise decoder state. Call once before enabling capture IRQ. */
void crank_init(void);

/**
 * @brief  Process one crank tooth edge. Call from input-capture ISR.
 * @param  timestamp  HAL timer value at edge [µs].
 */
void crank_tooth_interrupt(uint32_t timestamp);

/** @brief  Smoothed engine speed [RPM]. */
uint16_t crank_get_rpm(void);

/**
 * @brief  Current tooth index within the 58-tooth active window [0..57].
 *         Valid only when crank_is_synced() == true.
 */
uint8_t crank_get_tooth_index(void);

/** @brief  true once the missing tooth has been detected at least once. */
bool crank_is_synced(void);

/** @brief  Period of the most recent tooth [µs]. Used by angle tracker. */
uint32_t crank_get_tooth_period_us(void);

#endif /* CRANK_DECODER_H */
