/**
 * @file    crank_decoder.c
 * @brief   60-2 crank wheel decoder — STM32H562
 *
 * Timer resolution: 1 µs (HAL_TIMER_TICKS_PER_US = 1).
 *
 * Missing tooth detection:
 *   A gap tooth produces a period ~2× the normal tooth period.
 *   Threshold: dt > (prev_tooth_period * 3 / 2).
 *   Uses the PREVIOUS period (saved before overwrite) — fixes the
 *   original bug where tooth_period was overwritten before comparison.
 *
 * ISR safety:
 *   All state written only in crank_tooth_interrupt() (ISR context).
 *   Readers use hal_enter_critical() to guarantee consistent 32-bit reads
 *   on Cortex-M33 where float/uint32 may not be single-instruction.
 */

#include "crank_decoder.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Constants
 * ----------------------------------------------------------------------- */

#define TEETH_TOTAL    60U
#define TEETH_MISSING  2U
#define TEETH_ACTIVE   (TEETH_TOTAL - TEETH_MISSING)   /* 58 */

/**
 * Missing-tooth threshold factor (Q8 fixed-point: 192/128 = 1.5).
 * A real tooth period is ~T. The gap spans 3 missing teeth worth of time,
 * so its measured period is ~3T. We trigger when dt > 1.5 * prev_period.
 */
#define MISSING_TOOTH_THRESHOLD_NUM  3U
#define MISSING_TOOTH_THRESHOLD_DEN  2U

/** RPM smoothing: exponential moving average, alpha = 1/8. */
#define RPM_EMA_SHIFT  3U

/* -----------------------------------------------------------------------
 * Private state (written from ISR only)
 * ----------------------------------------------------------------------- */

static volatile uint32_t s_last_timestamp  = 0;
static volatile uint32_t s_prev_period     = 0;   /**< period of tooth N-1 */
static volatile uint32_t s_tooth_period    = 0;   /**< period of tooth N   */

static volatile uint8_t  s_tooth_index    = 0;
static volatile uint16_t s_rpm            = 0;
static volatile bool     s_synced         = false;

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void crank_init(void)
{
    s_last_timestamp = 0;
    s_prev_period    = 0;
    s_tooth_period   = 0;
    s_tooth_index    = 0;
    s_rpm            = 0;
    s_synced         = false;
}

/**
 * @brief  Called from input-capture ISR on every rising edge of crank signal.
 * @param  timestamp  HAL timer value at edge [µs].
 *
 * Must complete in < 10 µs at 8000 RPM (inter-tooth interval ≈ 129 µs).
 */
void crank_tooth_interrupt(uint32_t timestamp)
{
    /* --- Compute period ------------------------------------------------ */
    uint32_t dt = timestamp - s_last_timestamp;
    s_last_timestamp = timestamp;

    /*
     * FIX (was bug): save previous period BEFORE overwriting it.
     * Original code did:
     *   tooth_period = dt;
     *   if (dt > tooth_period * 2)  ← always false, compared dt to itself
     */
    s_prev_period  = s_tooth_period;
    s_tooth_period = dt;

    /* --- Missing tooth detection --------------------------------------- */
    /*
     * Guard: skip detection until we have at least one valid previous period
     * (s_prev_period == 0 on the very first tooth).
     */
    bool is_gap = false;
    if (s_prev_period > 0U)
    {
        /* dt > prev_period * 1.5  →  gap tooth */
        is_gap = (dt > (s_prev_period * MISSING_TOOTH_THRESHOLD_NUM
                        / MISSING_TOOTH_THRESHOLD_DEN));
    }

    if (is_gap)
    {
        /* Reset tooth counter — tooth after the gap is tooth 0. */
        s_tooth_index = 0;
        s_synced      = true;
    }
    else
    {
        if (s_synced)
        {
            s_tooth_index++;
            if (s_tooth_index >= TEETH_ACTIVE)
                s_tooth_index = 0;
        }
    }

    /* --- RPM calculation ----------------------------------------------- */
    /*
     * One revolution = TEETH_ACTIVE tooth periods (the gap counts as
     * the two missing teeth, so we still use 58 as divisor for per-tooth
     * period → RPM mapping).
     *
     * period_per_tooth [µs] = dt  (for a normal tooth)
     * RPM = 60_000_000 / (dt * TEETH_ACTIVE)
     *
     * Smoothed with EMA to reduce jitter from individual tooth spacing error.
     */
    if (dt > 0U && !is_gap)
    {
        uint16_t rpm_inst = (uint16_t)(60000000UL / ((uint32_t)dt * TEETH_ACTIVE));

        /* EMA: rpm = rpm + (rpm_inst - rpm) >> shift */
        if (s_rpm == 0U)
            s_rpm = rpm_inst;   /* first reading — seed directly */
        else
            s_rpm = (uint16_t)(s_rpm + ((int32_t)(rpm_inst - s_rpm) >> RPM_EMA_SHIFT));
    }
}

/* -----------------------------------------------------------------------
 * ISR-safe getters — use critical section to prevent torn reads
 * ----------------------------------------------------------------------- */

uint16_t crank_get_rpm(void)
{
    hal_irq_state_t state = hal_enter_critical();
    uint16_t v = s_rpm;
    hal_exit_critical(state);
    return v;
}

uint8_t crank_get_tooth_index(void)
{
    hal_irq_state_t state = hal_enter_critical();
    uint8_t v = s_tooth_index;
    hal_exit_critical(state);
    return v;
}

bool crank_is_synced(void)
{
    hal_irq_state_t state = hal_enter_critical();
    bool v = s_synced;
    hal_exit_critical(state);
    return v;
}

uint32_t crank_get_tooth_period_us(void)
{
    hal_irq_state_t state = hal_enter_critical();
    uint32_t v = s_tooth_period;
    hal_exit_critical(state);
    return v;
}
