/**
 * @file    engine_sync.h
 * @brief   Engine phase synchronisation — crank 60-2 + cam sensor.
 *
 * For a 4-stroke inline-4, the crank makes 2 revolutions (720°) per cycle.
 * The 60-2 crank wheel alone cannot determine which 360° half we are in.
 * The cam sensor (1 pulse per cam revolution = 1 pulse per 720° crank)
 * resolves the ambiguity, enabling:
 *   - Sequential fuel injection (each cylinder injected once per cycle)
 *   - Full-sequential ignition (correct coil fired at correct stroke)
 *
 * Sync state machine:
 *
 *   NO_SYNC
 *     │  missing tooth detected (crank_is_synced)
 *     ▼
 *   CRANK_SYNC
 *     │  cam pulse received while crank synced
 *     ▼
 *   FULL_SYNC  ◄──── normal running state
 *     │  crank signal lost (timeout) or sync error
 *     ▼
 *   NO_SYNC
 *
 * Cylinder firing order (inline-4, assumed 1-3-4-2):
 *   Cylinder 0 = physical cyl 1
 *   Cylinder 1 = physical cyl 3
 *   Cylinder 2 = physical cyl 4
 *   Cylinder 3 = physical cyl 2
 */

#ifndef ENGINE_SYNC_H
#define ENGINE_SYNC_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Types
 * ----------------------------------------------------------------------- */

typedef enum {
    ENGINE_SYNC_NONE   = 0,  /**< No crank signal or missing tooth not yet seen */
    ENGINE_SYNC_CRANK  = 1,  /**< Missing tooth seen, phase unknown             */
    ENGINE_SYNC_FULL   = 2   /**< Cam pulse received — full 720° sync           */
} engine_sync_state_t;

/* -----------------------------------------------------------------------
 * Configuration
 * ----------------------------------------------------------------------- */

/**
 * @brief  Tooth index (0..57) at which the cam pulse is expected to arrive.
 *
 * Set this to match the physical cam sensor position relative to the
 * missing tooth.  A window of ±CAM_WINDOW_TEETH teeth is accepted.
 * Tune after first engine run.
 */
#define ENGINE_CAM_EXPECTED_TOOTH   10U
#define ENGINE_CAM_WINDOW_TEETH      5U

/**
 * @brief  Number of cylinders.
 */
#define ENGINE_NUM_CYLINDERS         4U

/**
 * @brief  Firing order index → physical cylinder number (1-based).
 * Inline-4 default: 1-3-4-2.
 */
extern const uint8_t engine_firing_order[ENGINE_NUM_CYLINDERS];

/* -----------------------------------------------------------------------
 * Initialisation
 * ----------------------------------------------------------------------- */

/** @brief  Reset sync state. Call before enabling IRQs. */
void engine_sync_init(void);

/* -----------------------------------------------------------------------
 * Event inputs (call from ISR)
 * ----------------------------------------------------------------------- */

/**
 * @brief  Notify sync module of each crank tooth.
 *         Call from crank ISR AFTER crank_tooth_interrupt().
 * @param  tooth_index  Current tooth [0..57] from crank_decoder.
 * @param  timestamp    HAL timer at tooth edge [µs].
 */
void engine_sync_on_tooth(uint8_t tooth_index, uint32_t timestamp);

/**
 * @brief  Notify sync module of cam sensor pulse.
 *         Call from cam input-capture ISR.
 * @param  timestamp  HAL timer at cam edge [µs].
 */
void engine_sync_on_cam_pulse(uint32_t timestamp);

/* -----------------------------------------------------------------------
 * State queries (ISR-safe)
 * ----------------------------------------------------------------------- */

/** @brief  Current synchronisation state. */
engine_sync_state_t engine_sync_get_state(void);

/**
 * @brief  Current firing-order index [0..3].
 *         Maps to physical cylinder via engine_firing_order[].
 *         Valid only when state == ENGINE_SYNC_FULL.
 */
uint8_t engine_sync_get_cylinder_index(void);

/**
 * @brief  Current 720° cycle angle [0.0 .. 719.9°].
 *         0° = TDC cylinder 1 compression.
 *         Valid only when state == ENGINE_SYNC_FULL.
 */
float engine_sync_get_cycle_angle(void);

/**
 * @brief  true if a cam pulse was received in the expected window
 *         on the last revolution.
 */
bool engine_sync_cam_ok(void);

#endif /* ENGINE_SYNC_H */
