/**
 * @file    angle_tracker.c
 * @brief   Sub-tooth crank angle interpolation with digital PLL.
 *
 * Algorithm overview
 * ------------------
 * On each tooth ISR:
 *   1. Record timestamp and tooth_index.
 *   2. Update PLL period estimate.
 *
 * Between teeth (when a task or ISR calls angle_tracker_get_current):
 *   1. Read elapsed = hal_timer_get() - last_tooth_timestamp.
 *   2. Interpolate: offset = (elapsed / pll_period) * DEGREES_PER_TOOTH.
 *   3. Return tooth_base_angle + offset, clamped to [0, 360).
 *
 * PLL (digital phase-locked loop)
 * --------------------------------
 * Smooths tooth-to-tooth period variation:
 *   pll_period += (measured_period - pll_period) * PLL_ALPHA
 * where PLL_ALPHA = 1/8 (implemented as right-shift by PLL_ALPHA_SHIFT).
 *
 * This is a first-order IIR low-pass filter. It suppresses tooth-to-tooth
 * jitter (~10% variation is typical) while tracking genuine speed changes
 * with a lag of ~8 teeth (≈50 ms at idle, ≈7 ms at 8000 RPM).
 */

#include "angle_tracker.h"
#include "engine_sync.h"
#include "../hal/hal.h"

/* -----------------------------------------------------------------------
 * Constants
 * ----------------------------------------------------------------------- */

#define TEETH_ACTIVE         58U
#define DEGREES_PER_REV      360.0f
#define DEGREES_PER_TOOTH    (DEGREES_PER_REV / (float)TEETH_ACTIVE)  /* 6.2069° */

/** PLL alpha = 1 / (1 << PLL_ALPHA_SHIFT) = 1/8 */
#define PLL_ALPHA_SHIFT      3U

/**
 * Maximum interpolation guard: if elapsed > period * MAX_INTERP_FACTOR,
 * the engine has stalled — clamp to avoid runaway angle values.
 */
#define MAX_INTERP_FACTOR    2U

/* -----------------------------------------------------------------------
 * Private state (written from crank ISR)
 * ----------------------------------------------------------------------- */

static volatile uint32_t s_last_tooth_timestamp = 0;
static volatile uint32_t s_pll_period           = 0;    /**< smoothed period [µs] */
static volatile float    s_tooth_base_angle     = 0.0f; /**< 360° angle of last tooth */
static volatile float    s_cycle_base_angle     = 0.0f; /**< 720° angle of last tooth */
static volatile bool     s_valid                = false;

/* -----------------------------------------------------------------------
 * Public API
 * ----------------------------------------------------------------------- */

void angle_tracker_init(void)
{
    s_last_tooth_timestamp = 0;
    s_pll_period           = 0;
    s_tooth_base_angle     = 0.0f;
    s_cycle_base_angle     = 0.0f;
    s_valid                = false;
}

void angle_tracker_on_tooth(uint8_t tooth_index, uint32_t timestamp)
{
    uint32_t dt = timestamp - s_last_tooth_timestamp;
    s_last_tooth_timestamp = timestamp;

    /* Seed PLL on first tooth, then filter */
    if (s_pll_period == 0U)
        s_pll_period = dt;
    else
        s_pll_period = s_pll_period + (uint32_t)((int32_t)(dt - s_pll_period) >> PLL_ALPHA_SHIFT);

    /* Base angle of this tooth in 360° space */
    s_tooth_base_angle = (float)tooth_index * DEGREES_PER_TOOTH;

    /* Base angle in 720° space from engine sync */
    s_cycle_base_angle = engine_sync_get_cycle_angle();

    s_valid = true;
}

/**
 * @brief  Interpolate current 360° crank angle.
 *
 * Called from any context.  Uses critical section to get a consistent
 * snapshot of the three volatile values, then does maths outside the
 * critical section to keep IRQ latency low.
 */
float angle_tracker_get_current(void)
{
    /* Snapshot under critical section */
    hal_irq_state_t irqs = hal_enter_critical();
    uint32_t last_ts   = s_last_tooth_timestamp;
    uint32_t period    = s_pll_period;
    float    base      = s_tooth_base_angle;
    bool     valid     = s_valid;
    hal_exit_critical(irqs);

    if (!valid || period == 0U)
        return 0.0f;

    uint32_t elapsed = hal_timer_get() - last_ts;

    /* Clamp: if elapsed > 2× period the engine has stalled */
    if (elapsed > period * MAX_INTERP_FACTOR)
        elapsed = period * MAX_INTERP_FACTOR;

    float offset = ((float)elapsed / (float)period) * DEGREES_PER_TOOTH;
    float angle  = base + offset;

    /* Wrap to [0, 360) */
    if (angle >= DEGREES_PER_REV)
        angle -= DEGREES_PER_REV;

    return angle;
}

float angle_tracker_get_cycle_angle(void)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint32_t last_ts   = s_last_tooth_timestamp;
    uint32_t period    = s_pll_period;
    float    base      = s_cycle_base_angle;
    bool     valid     = s_valid;
    hal_exit_critical(irqs);

    if (!valid || period == 0U)
        return 0.0f;

    uint32_t elapsed = hal_timer_get() - last_ts;
    if (elapsed > period * MAX_INTERP_FACTOR)
        elapsed = period * MAX_INTERP_FACTOR;

    float offset = ((float)elapsed / (float)period) * DEGREES_PER_TOOTH;
    float angle  = base + offset;

    /* Wrap to [0, 720) */
    if (angle >= 720.0f)
        angle -= 720.0f;

    return angle;
}

uint32_t angle_tracker_get_tooth_period(void)
{
    hal_irq_state_t s = hal_enter_critical();
    uint32_t v = s_pll_period;
    hal_exit_critical(s);
    return v;
}

uint32_t angle_tracker_angle_to_timestamp(float target_cycle_angle)
{
    hal_irq_state_t irqs = hal_enter_critical();
    uint32_t last_ts = s_last_tooth_timestamp;
    uint32_t period  = s_pll_period;
    float    base    = s_cycle_base_angle;
    bool     valid   = s_valid;
    hal_exit_critical(irqs);

    if (!valid || period == 0U)
        return 0U;

    /* Angle remaining from base to target */
    float delta = target_cycle_angle - base;
    if (delta < 0.0f)
        delta += 720.0f;

    /* Convert angle delta to time delta [µs] */
    float teeth_to_go    = delta / DEGREES_PER_TOOTH;
    uint32_t us_to_event = (uint32_t)(teeth_to_go * (float)period);

    return last_ts + us_to_event;
}
