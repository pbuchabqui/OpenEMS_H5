/**
 * @file    combustion.h
 * @brief   Combustion analysis via crankshaft acceleration.
 *
 * Method: instantaneous crank acceleration is computed from tooth-to-tooth
 * timing variations. A firing cylinder accelerates the crank; a misfiring
 * cylinder shows no acceleration or mild deceleration relative to motoring.
 *
 * Pipeline per tooth:
 *   1. Record tooth period (µs) in a ring buffer
 *   2. At TDC+90° window per cylinder: compute acceleration index
 *   3. Compare against adaptive baseline (motoring reference)
 *   4. Torque index = (actual_accel - motoring_accel) / motoring_accel
 *   5. Misfire if torque_index < MISFIRE_THRESHOLD for N consecutive cycles
 */

#ifndef COMBUSTION_H
#define COMBUSTION_H

#include <stdint.h>
#include <stdbool.h>

#define COMBUSTION_NUM_CYLINDERS  4U

/** @brief  Initialise combustion analysis state. */
void combustion_init(void);

/**
 * @brief  Update on every tooth. Call from crank ISR or main loop.
 * @param  tooth_index  Current tooth [0..57].
 * @param  tooth_time   Period of this tooth [µs].
 */
void combustion_update(uint8_t tooth_index, uint32_t tooth_time);

/**
 * @brief  Torque index for a cylinder in the last complete cycle.
 *         1.0 = nominal, < 0.5 = likely misfire.
 *         ISR-safe.
 */
float combustion_get_torque_index(uint8_t cylinder);

/**
 * @brief  true if misfire detected for this cylinder in last N cycles.
 *         ISR-safe.
 */
bool combustion_misfire_detected(uint8_t cylinder);

/** @brief  Reset misfire counter for a cylinder. */
void combustion_clear_misfire(uint8_t cylinder);

#endif /* COMBUSTION_H */
