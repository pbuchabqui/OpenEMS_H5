/**
 * @file    main.c
 * @brief   ECU firmware entry point — STM32H562RGT6.
 *
 * Startup sequence (enforced order — see safe_state.h):
 *   1.  hal_timer_init()
 *   2.  hal_gpio_init()        [outputs to safe levels via safe_state]
 *   3.  sensors_init()
 *   4.  crank_init()
 *   5.  engine_sync_init()
 *   6.  angle_tracker_init()
 *   7.  scheduler_init()
 *   8.  calibration_load()
 *   9.  fuel_init()
 *  10.  ignition_init()
 *  11.  knock_init()
 *  12.  safe_state_init()      [arms watchdog, enables fuel pump]
 *  13.  [enable IRQs]
 *
 * Main loop tasks (priority order executed cooperatively):
 *   - safe_state_update()      100 Hz
 *   - sensors_update()         1 kHz
 *   - engine_control_update()  synced to crank events via flag
 *   - comm_process()           background
 *
 * Crank ISR → engine_sync_on_tooth() → angle_tracker_on_tooth()
 *           → safe_state_notify_tooth()
 *           → sets g_new_tooth_flag
 *
 * Cam ISR   → engine_sync_on_cam_pulse()
 *
 * Compare ISR → scheduler_on_compare_isr()
 */

#include <stdint.h>
#include <stdbool.h>

/* HAL */
#include "hal/hal.h"

/* Engine core */
#include "engine/crank_decoder.h"
#include "engine/engine_sync.h"
#include "engine/angle_tracker.h"
#include "engine/event_scheduler.h"
#include "engine/combustion.h"

/* Sensors */
#include "sensors/sensors.h"

/* Fuel */
#include "fuel/load_model.h"
#include "fuel/fuel_control.h"
#include "fuel/lambda_ctrl.h"

/* Ignition */
#include "ignition/ignition_control.h"
#include "ignition/rev_limiter.h"

/* Knock */
#include "knock/knock_dsp.h"

/* Calibration */
#include "calibration/calibration.h"
#include "calibration/calibration_ids.h"
#include "calibration/cal_flash.h"

/* Diagnostics */
#include "diagnostics/safe_state.h"
#include "diagnostics/diagnostics.h"

/* Communication */
#include "communication/comm.h"

/* Logging */
#include "logging/logging.h"

/* -----------------------------------------------------------------------
 * Inter-ISR / main-loop flags
 * Use volatile + critical section for multi-word state; single-byte flags
 * are atomically written on Cortex-M33.
 * ----------------------------------------------------------------------- */

static volatile bool g_new_tooth_flag   = false;  /**< Set by crank ISR */
static volatile bool g_full_cycle_flag  = false;  /**< Set on tooth 0 after full sync */

/* -----------------------------------------------------------------------
 * Engine control — called once per tooth (from main loop after ISR sets flag)
 * ----------------------------------------------------------------------- */

static void engine_control_update(void)
{
    if (!safe_state_outputs_enabled())
        return;

    if (engine_sync_get_state() != ENGINE_SYNC_FULL)
        return;

    /* Only schedule events at tooth 0 (start of revolution) */
    if (crank_get_tooth_index() != 0U)
        return;

    /* Current cylinder firing index */
    uint8_t cyl = engine_sync_get_cylinder_index();

    /* Get sensor snapshot */
    sensor_data_t sensors = sensors_get();

    /* Compute engine load */
    float rpm  = (float)crank_get_rpm();
    float load = load_compute_engine_load(&sensors);

    /* --- Fuel ---------------------------------------------------------- */
    float air_mass = load_compute_air_mass(&sensors, rpm);

    float lambda_target = 1.0f;
    calibration_lookup_2d(CAL_ID_LAMBDA_TARGET_TABLE, rpm, load, &lambda_target);

    pw_us_t base_pw = fuel_compute_base_pw(air_mass, lambda_target);

    /* Wall-wetting parameters from calibration */
    wallwet_params_t ww;
    calibration_lookup_1d(CAL_ID_WALLWET_TAU, sensors.ect, &ww.tau);
    calibration_lookup_2d(CAL_ID_WALLWET_X,   sensors.ect, sensors.tps, &ww.x);

    float dt_s = (float)angle_tracker_get_tooth_period() * 58.0f / 1e6f;
    pw_us_t corrected_pw = fuel_apply_wallwet(cyl, base_pw, &ww, dt_s);

    /* Lambda closed-loop correction */
    float lambda_corr = lambda_ctrl_get_correction();
    corrected_pw = (pw_us_t)((float)corrected_pw * lambda_corr);

    /* Per-cylinder trim, dead-time, clamp */
    pw_us_t final_pw = fuel_apply_cyl_trim(cyl, corrected_pw);
    final_pw         = fuel_apply_deadtime(final_pw, sensors.batt);
    final_pw         = fuel_clamp_pw(final_pw);

    /* Rev limiter — skip injection if over RPM limit */
    if (!rev_limiter_injection_allowed(cyl, (uint16_t)rpm))
        final_pw = 0U;

    /* Schedule injection: open at 300° BTDC, close after pulse width */
    float inj_open_angle = 300.0f;  /* degrees in 720° cycle space */
    uint32_t inj_open_ts  = angle_tracker_angle_to_timestamp(inj_open_angle);
    uint32_t inj_close_ts = inj_open_ts + final_pw;
    scheduler_schedule_injection(cyl, inj_open_ts, inj_close_ts);

    /* --- Ignition ------------------------------------------------------ */
    ignition_output_t ign = ignition_compute(rpm, load, &sensors);

    /*
     * Spark angle in 720° cycle space:
     *   TDC cylinder N is at cycle_angle = cyl * 180°
     *   BTDC advance means fire slightly before TDC
     */
    float tdc_angle   = (float)cyl * 180.0f;
    float fire_angle  = tdc_angle - ign.advance_deg;
    float dwell_angle = fire_angle - ((float)ign.dwell_us
                        / (float)angle_tracker_get_tooth_period()
                        * (360.0f / 58.0f));

    if (fire_angle  < 0.0f) fire_angle  += 720.0f;
    if (dwell_angle < 0.0f) dwell_angle += 720.0f;

    uint32_t dwell_ts = angle_tracker_angle_to_timestamp(dwell_angle);
    uint32_t fire_ts  = angle_tracker_angle_to_timestamp(fire_angle);
    scheduler_schedule_ignition(cyl, dwell_ts, fire_ts);

    /* --- Knock recovery (once per revolution at tooth 0) --------------- */
    ignition_recover_knock();
}

/* -----------------------------------------------------------------------
 * ISR handlers (weak declarations — override in startup file or HAL)
 *
 * On STM32H562: these would be registered in the vector table as:
 *   TIM2_IRQHandler         → crank capture
 *   TIM3_IRQHandler         → cam capture
 *   TIM4/5_IRQHandler       → compare channels for scheduler
 *   ADC1_IRQHandler         → knock sample
 * ----------------------------------------------------------------------- */

/**
 * @brief  Crank input capture ISR.
 *         Called by TIM capture compare interrupt on crank signal edge.
 */
void ECU_CrankCapture_ISR(uint32_t timestamp)
{
    crank_tooth_interrupt(timestamp);

    uint8_t tooth = crank_get_tooth_index();

    engine_sync_on_tooth(tooth, timestamp);
    angle_tracker_on_tooth(tooth, timestamp);
    safe_state_notify_tooth();

    g_new_tooth_flag = true;
    if (tooth == 0U && crank_is_synced())
        g_full_cycle_flag = true;
}

/**
 * @brief  Cam input capture ISR.
 */
void ECU_CamCapture_ISR(uint32_t timestamp)
{
    engine_sync_on_cam_pulse(timestamp);
}

/**
 * @brief  Compare match ISR (fires scheduled events).
 * @param  channel  HAL compare channel [0..7].
 */
void ECU_Compare_ISR(uint8_t channel)
{
    scheduler_on_compare_isr(channel);
}

/**
 * @brief  ADC conversion complete ISR (knock sample).
 * @param  sample  Raw ADC value [0..4095].
 */
void ECU_ADC_Knock_ISR(uint16_t sample)
{
    knock_process_sample((int16_t)sample);
}

/* -----------------------------------------------------------------------
 * Main
 * ----------------------------------------------------------------------- */

int main(void)
{
    /* === Startup sequence (order is mandatory) === */

    /* 1. Timers */
    hal_timer_init();

    /* 2. GPIO — all outputs safe-low before safe_state_init() */
    hal_gpio_init();

    /* 3. Sensors */
    sensors_init();

    /* 4-6. Engine core */
    crank_init();
    engine_sync_init();
    angle_tracker_init();

    /* 7. Scheduler */
    scheduler_init();

    /* 8. Calibration — must be before any module that reads cal values */
    calibration_load();

    /* 9-11. Control modules — depend on calibration */
    fuel_init();
    ignition_init();
    knock_init();

    /* 12. Safe state — arms watchdog, transitions to CRANKING */
    safe_state_init();

    /* 13. Enable interrupts (platform-specific — here symbolically) */
    hal_enable_irqs();

    /* === Main loop === */
    uint32_t last_sensor_ts     = hal_timer_get();
    uint32_t last_safe_state_ts = hal_timer_get();
    uint32_t last_lambda_ts     = hal_timer_get();
    uint32_t last_diag_ts       = hal_timer_get();

    while (1)
    {
        uint32_t now = hal_timer_get();

        /* Sensors at 1 kHz (every 1000 µs) */
        if ((now - last_sensor_ts) >= 1000U)
        {
            sensors_update();
            last_sensor_ts = now;
        }

        /* Safe state at 100 Hz (every 10000 µs) */
        if ((now - last_safe_state_ts) >= 10000U)
        {
            safe_state_update();
            last_safe_state_ts = now;
        }

        /* Lambda closed-loop at 10 Hz */
        if ((now - last_lambda_ts) >= 100000U)
        {
            sensor_data_t s = sensors_get();
            float lambda_target = 1.0f;
            calibration_lookup_2d(CAL_ID_LAMBDA_TARGET_TABLE,
                                  (float)crank_get_rpm(),
                                  load_compute_engine_load(&s),
                                  &lambda_target);
            lambda_ctrl_update(&s, lambda_target, 0.1f);
            last_lambda_ts = now;
        }

        /* Diagnostics at 10 Hz */
        if ((now - last_diag_ts) >= 100000U)
        {
            diagnostics_update();
            last_diag_ts = now;
        }

        /* Engine control — execute once per new tooth if flagged */
        if (g_new_tooth_flag)
        {
            g_new_tooth_flag = false;
            engine_control_update();
        }

        /* Log drain and communication — background */
        log_flush_can(4);
        comm_process();

        /* Kick watchdog */
        hal_watchdog_kick();
    }

    return 0;  /* never reached */
}
