# ECU Firmware — STM32H562RGT6

Custom ECU firmware for a 4-cylinder inline engine, 60-2 crank wheel + cam sensor.

---

## Hardware target

| Item | Value |
|---|---|
| MCU | STM32H562RGT6 (Cortex-M33, 250 MHz) |
| Crank trigger | 60-2 wheel |
| Cam sensor | 1 pulse / cam revolution (720° crank) |
| Engine | Inline-4, 4-stroke |
| Max RPM | 8000 |
| Timer resolution | 1 µs (TIM2 @ 1 MHz) |
| Ignition precision | ±0.3° crank (RSS error budget) |

---

## Repository layout

```
firmware/
├── hal/                HAL — STM32H562 register-level drivers
│   ├── hal.h           Interface (timer, GPIO, ADC, critical section)
│   └── hal.c           Implementation (TIM2/3/4/5, FDCAN1, IWDG)
│
├── engine/             Engine position and scheduling
│   ├── crank_decoder   60-2 decode, RPM, missing-tooth detection
│   ├── engine_sync     Cam + crank phase sync, 720° cycle, firing order
│   ├── angle_tracker   Sub-tooth interpolation, digital PLL
│   ├── event_scheduler Angle-based event queue, hardware compare
│   └── combustion      Crank acceleration, misfire detection, torque index
│
├── sensors/            Sensor ADC sampling and conversion
│   └── sensors         MAP/MAF/TPS/IAT/ECT/Lambda/Batt → engineering units
│
├── fuel/               Fuel control pipeline
│   ├── load_model      Speed Density + MAF → air mass [mg/cyl/cycle]
│   ├── fuel_control    Base PW, wall wetting (Aquino), dead time, trims
│   └── lambda_ctrl     Closed-loop lambda PI controller
│
├── ignition/           Ignition control
│   ├── ignition_control Spark table, corrections, knock retard, dwell
│   └── rev_limiter     Soft RPM cut via per-cylinder injection skip
│
├── knock/              Knock detection DSP
│   └── knock_dsp       Biquad bandpass, windowed energy, background norm.
│
├── calibration/        Calibration system
│   ├── calibration_ids.h  All CAL_ID_xxx constants
│   ├── calibration     RAM store, bilinear interpolation, defaults
│   └── cal_flash       STM32H562 flash erase/write/CRC
│
├── diagnostics/        Fault management
│   ├── safe_state      Watchdog, crank timeout, output cutoff, startup seq.
│   └── diagnostics     DTC set/clear, confirmation, flash persistence
│
├── communication/      External interfaces
│   └── comm            FDCAN1 telemetry TX + calibration RX protocol
│
├── logging/            High-speed signal logger
│   └── logging         Lock-free ring buffer, CAN drain
│
├── tests/              Host-side unit tests (no hardware required)
│   ├── hal_mock        Fake HAL with injectable timer and GPIO state
│   ├── crank_decoder_test
│   ├── engine_sync_test
│   ├── fuel_ign_test
│   ├── integration_test
│   └── Makefile
│
└── main.c              Entry point, startup sequence, main loop, ISR hooks
```

---

## Startup sequence

Modules must be initialised in this exact order (see `main.c`):

```
1.  hal_timer_init()       TIM2/3/4/5, GPIO, NVIC
2.  hal_gpio_init()        All outputs to safe-low
3.  sensors_init()         ADC buffers
4.  crank_init()           Decoder state
5.  engine_sync_init()     Sync state machine
6.  angle_tracker_init()   PLL state
7.  scheduler_init()       Event queue
8.  calibration_load()     Flash → RAM, CRC verify, load defaults on fail
9.  fuel_init()            Wall-film state
10. ignition_init()        Knock retard = 0
11. knock_init()           Biquad coefficients from calibration
12. lambda_ctrl_init()     PI integrator
13. safe_state_init()      Arms IWDG, enables fuel pump
14. hal_enable_irqs()      Start capture + compare interrupts
```

---

## Main loop task rates

| Task | Rate | Notes |
|---|---|---|
| `sensors_update()` | 1 kHz | ADC sampling |
| `safe_state_update()` | 100 Hz | Crank timeout, sync check |
| `lambda_ctrl_update()` | 10 Hz | Closed-loop O2 |
| `diagnostics_update()` | 10 Hz | DTC confirmation |
| `engine_control_update()` | Per tooth | Triggered by crank ISR flag |
| `log_flush_can()` | Background | Drain log ring buffer |
| `comm_process()` | Background | CAN TX telemetry + RX calibration |
| `hal_watchdog_kick()` | Every loop | IWDG refresh |

---

## ISR priority scheme (STM32H562 NVIC)

| Priority | ISR | Function |
|---|---|---|
| 0 (highest) | TIM3 | Crank + cam input capture |
| 1 | TIM4 | Ignition compare events |
| 1 | TIM5 | Injector compare events |
| 2 | ADC1 | Knock sample |
| 3+ | All others | |

---

## CAN protocol (500 kbit/s, FDCAN1)

| ID | Dir | Content | Rate |
|---|---|---|---|
| 0x100 | TX | RPM, sync state, tooth index | 10 Hz |
| 0x101 | TX | MAP, TPS, IAT, ECT | 10 Hz |
| 0x102 | TX | Lambda, battery, load | 10 Hz |
| 0x103 | TX | Spark advance, knock retard, knock level | 10 Hz |
| 0x104 | TX | Injector PW cyl 0-3 | 10 Hz |
| 0x110 | TX | Active DTC list | 1 Hz |
| 0x300 | TX | Signal log entries | Background |
| 0x200 | RX | Calibration write `[u16 id][f32 value]` | On demand |
| 0x201 | RX | Calibration read request `[u16 id]` | On demand |
| 0x202 | TX | Calibration read response `[u16 id][f32 value]` | On demand |
| 0x2FF | RX | Save calibration to flash | On demand |

---

## Running the unit tests

No hardware needed — tests run on any Linux/macOS host with GCC.

```bash
cd firmware/tests
make test
```

Expected output:
```
--- crank decoder ---
PASS test_no_sync_before_gap
PASS test_sync_after_gap
...
--- engine sync ---
PASS test_initial_state_none
...
--- fuel + ignition ---
PASS test_base_pw_stoich
...
--- integration ---
PASS test_full_720_sync
...
All tests passed.
```

---

## Calibration workflow

1. Connect CAN interface (500 kbit/s)
2. Send `0x2FF` to restore defaults (or edit values individually via `0x200`)
3. Read current value: send `0x201` with CAL_ID, receive `0x202`
4. Write value: send `0x200` with CAL_ID + float32
5. Save to flash: send `0x2FF` — engine must be stopped (erase takes ~50 ms)

All `CAL_ID_xxx` constants are in `calibration/calibration_ids.h`.

---

## Key calibration IDs to tune first

| ID | Description | Default |
|---|---|---|
| `CAL_ID_VE_TABLE` | Volumetric efficiency 2D map (RPM × MAP) | 80% flat |
| `CAL_ID_SPARK_TABLE` | Spark advance 2D map (RPM × load) | 15° flat |
| `CAL_ID_LAMBDA_TARGET_TABLE` | Target lambda 2D map | 1.0 flat |
| `CAL_ID_INJECTOR_FLOW_CC_MIN` | Injector flow rate [cc/min] | 440 |
| `CAL_ID_CAM_EXPECTED_TOOTH` | Cam pulse tooth index [0-57] | 10 |
| `CAL_ID_KNOCK_FREQ_HZ` | Knock filter centre frequency [Hz] | 7500 |
| `CAL_ID_WALLWET_TAU` | Wall-film time constant table (vs ECT) | See table |
| `CAL_ID_RPM_LIMIT` | Rev limiter [RPM] | 8000 |

---

## CPU load budget (8000 RPM, 60-2, 4 cylinders)

At maximum speed the crank ISR fires ~7733 times/sec with ~129 µs between teeth.
Estimated load on the Cortex-M33 at 250 MHz:

| Module | CPU |
|---|---|
| Crank decoding | 23% |
| Knock DSP | 10% |
| Communication | 3% |
| Diagnostics | 2% |
| Sensors | 1% |
| Fuel calc | 0.7% |
| Scheduler | 0.5% |
| **Total** | **≈ 40%** |

60% headroom remains for future features (VVT, boost control, traction control).

---

## Ignition timing error budget

Sources of error contributing to final spark angle uncertainty:

| Source | Error |
|---|---|
| Sensor jitter | 0.10° |
| Timer resolution | 0.02° |
| Interrupt latency | 0.14° |
| Sub-tooth interpolation | 0.08° |
| Scheduler jitter | 0.10° |
| Coil delay variation | 0.19° |
| **Combined (RSS)** | **≈ ±0.3°** |

±0.3° is considered excellent for a production ECU. Use this as the acceptance
criterion when validating timing on an oscilloscope against the crank trigger signal.

---

## Global ECU state model

The firmware uses per-module state structs today. If a centralised state snapshot
is needed for logging or telemetry serialisation, the intended top-level shape is:

```c
typedef struct {
    EngineState    engine;    /* rpm, tooth_index, sync_state, cycle_angle */
    SensorState    sensors;   /* map, tps, iat, ect, lambda, batt          */
    FuelState      fuel;      /* pw[4], lambda_corr, wall_film[4]          */
    IgnitionState  ignition;  /* advance, dwell, knock_retard              */
    DiagnosticsState diag;    /* active_dtcs[], confirmed_dtcs[]           */
} ECU_State;
```

Not yet implemented — add to `main.c` and populate at the start of each
`engine_control_update()` call if needed.

---

## Known stubs (not yet production-ready)

- `cal_flash.c` — flash write uses simplified message RAM offset; verify against
  STM32H562 reference manual section 47 (FDCAN message RAM layout) before use.
- `comm.c` — FDCAN message RAM access uses placeholder offsets; adapt to actual
  FDCAN RAM configuration from STM32CubeH5 FDCAN init.
- `sensors.c` — ADC init not shown; configure ADC1 scan mode + DMA via
  STM32CubeH5 HAL or CubeMX before calling `sensors_update()`.
- `diagnostics.c` — confirmed DTCs stored in RAM only; hook into `cal_flash`
  for persistence across resets.
