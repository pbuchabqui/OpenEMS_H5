/**
 * @file    ignition_control.c
 * @brief   Ignition control pipeline.
 *
 * Advance corrections applied in order:
 *   1. Base advance from spark table (RPM × load)
 *   2. ECT correction     (cold engine → retard)
 *   3. IAT correction     (hot intake → retard)
 *   4. Knock retard       (accumulated)
 *   5. Clamp to [min, max]
 *
 * Dwell:
 *   dwell_us = base_dwell + vcoef * (batt_v - 14.0)
 *   Clamped to [1000, 6000] µs.
 */

#include "ignition_control.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"

/* ECT correction: -0.1° per °C below 80°C (simplified) */
#define ECT_CORRECTION_DEG_PER_C   0.1f
#define ECT_NOMINAL_C              80.0f

/* IAT correction: -0.1° per °C above 35°C (simplified) */
#define IAT_CORRECTION_DEG_PER_C   0.1f
#define IAT_NOMINAL_C              35.0f

static volatile float s_knock_retard_deg = 0.0f;

void ignition_init(void)
{
    s_knock_retard_deg = 0.0f;
}

ignition_output_t ignition_compute(float rpm,
                                   float load,
                                   const sensor_data_t *sensors)
{
    ignition_output_t out;

    /* --- Base advance from table --------------------------------------- */
    float base_advance = 15.0f;
    calibration_lookup_2d(CAL_ID_SPARK_TABLE, rpm, load, &base_advance);

    /* --- ECT correction (cold engine retard) --------------------------- */
    float ect_corr = 0.0f;
    if (sensors->ect < ECT_NOMINAL_C)
        ect_corr = -(ECT_NOMINAL_C - sensors->ect) * ECT_CORRECTION_DEG_PER_C;

    /* --- IAT correction (hot intake retard) ---------------------------- */
    float iat_corr = 0.0f;
    if (sensors->iat > IAT_NOMINAL_C)
        iat_corr = -(sensors->iat - IAT_NOMINAL_C) * IAT_CORRECTION_DEG_PER_C;

    /* --- Knock retard (accumulated, applied last) ---------------------- */
    float knock_corr = -s_knock_retard_deg;   /* retard = reduce advance */

    /* --- Sum and clamp ------------------------------------------------- */
    float final = base_advance + ect_corr + iat_corr + knock_corr;

    float adv_min = -10.0f;
    float adv_max =  50.0f;
    calibration_get(CAL_ID_IGN_ADVANCE_MIN_DEG, &adv_min);
    calibration_get(CAL_ID_IGN_ADVANCE_MAX_DEG, &adv_max);

    if (final < adv_min) final = adv_min;
    if (final > adv_max) final = adv_max;

    out.advance_deg = final;

    /* --- Dwell --------------------------------------------------------- */
    float base_dwell = 3500.0f;
    float vcoef      = -100.0f;
    calibration_get(CAL_ID_IGN_DWELL_BASE_US, &base_dwell);
    calibration_get(CAL_ID_IGN_DWELL_VCOEF,   &vcoef);

    float dwell = base_dwell + vcoef * (sensors->batt - 14.0f);
    if (dwell < 1000.0f) dwell = 1000.0f;
    if (dwell > 6000.0f) dwell = 6000.0f;

    out.dwell_us = (uint32_t)dwell;

    return out;
}

void ignition_apply_knock_retard(float retard_deg)
{
    float step = 1.5f;
    calibration_get(CAL_ID_KNOCK_RETARD_STEP_DEG, &step);

    s_knock_retard_deg += step;

    float adv_min = -10.0f;
    float adv_max =  50.0f;
    calibration_get(CAL_ID_IGN_ADVANCE_MIN_DEG, &adv_min);
    calibration_get(CAL_ID_IGN_ADVANCE_MAX_DEG, &adv_max);

    /* Max retard is limited to [base_advance - adv_min] implicitly by clamp.
       Here we cap accumulated retard to 20° as a sanity limit. */
    if (s_knock_retard_deg > 20.0f)
        s_knock_retard_deg = 20.0f;

    (void)retard_deg;
}

void ignition_recover_knock(void)
{
    float recovery = 0.2f;
    calibration_get(CAL_ID_KNOCK_RECOVERY_DEG_REV, &recovery);

    s_knock_retard_deg -= recovery;
    if (s_knock_retard_deg < 0.0f)
        s_knock_retard_deg = 0.0f;
}

float ignition_get_knock_retard(void)
{
    return s_knock_retard_deg;
}
