/**
 * @file    rev_limiter.h
 * @brief   Soft rev limiter via per-cylinder injection skip.
 */

#ifndef REV_LIMITER_H
#define REV_LIMITER_H

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief  Check if injection is allowed for this cylinder at current RPM.
 * @param  cylinder  Cylinder index [0..3].
 * @param  rpm       Current engine speed.
 * @return true if injection should fire, false if it should be skipped.
 */
bool rev_limiter_injection_allowed(uint8_t cylinder, uint16_t rpm);

/** @brief  true if RPM is at or above the configured limit. */
bool rev_limiter_active(uint16_t rpm);

#endif /* REV_LIMITER_H */
