/**
 * @file    ignition_control.h
 * @brief   Ignition control — spark advance, dwell, knock retard.
 */

#ifndef IGNITION_CONTROL_H
#define IGNITION_CONTROL_H

#include <stdint.h>
#include "../sensors/sensors.h"

typedef struct {
    float advance_deg;      /**< Final spark advance [°BTDC]    */
    uint32_t dwell_us;      /**< Coil dwell time [µs]           */
} ignition_output_t;

/** @brief  Initialise ignition state (knock retard = 0). */
void ignition_init(void);

/**
 * @brief  Compute ignition parameters for the current cycle.
 * @param  rpm      Engine speed [RPM].
 * @param  load     Engine load [%] for table lookup.
 * @param  sensors  Current sensor snapshot.
 * @return Computed ignition output.
 */
ignition_output_t ignition_compute(float rpm,
                                   float load,
                                   const sensor_data_t *sensors);

/**
 * @brief  Apply knock retard request. Call from knock module.
 * @param  retard_deg  Additional retard to apply [°]. Positive = retard.
 */
void ignition_apply_knock_retard(float retard_deg);

/**
 * @brief  Advance knock recovery (call once per engine revolution).
 *         Gradually removes accumulated retard.
 */
void ignition_recover_knock(void);

/** @brief  Current accumulated knock retard [°]. */
float ignition_get_knock_retard(void);

#endif /* IGNITION_CONTROL_H */
