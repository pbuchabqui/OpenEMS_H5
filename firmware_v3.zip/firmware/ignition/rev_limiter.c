/**
 * @file    rev_limiter.c
 * @brief   Soft rev limiter — per-cylinder injection skip.
 *
 * Strategy: above RPM_LIMIT, skip injection for cylinders in round-robin.
 * Ignition is retained to burn any residual fuel and avoid backfires.
 * As RPM drops below (RPM_LIMIT - HYSTERESIS), full injection resumes.
 *
 * Cut ratio increases with RPM overshoot:
 *   0-500 RPM over limit → skip 1 of 4 cylinders (25% cut)
 *   500+ RPM over limit  → skip 2 of 4 cylinders (50% cut)
 */

#include "rev_limiter.h"
#include "../calibration/calibration.h"
#include "../calibration/calibration_ids.h"
#include "../hal/hal.h"

#define HYSTERESIS_RPM  100U
#define SOFT_CUT_1_OVER 0U
#define SOFT_CUT_2_OVER 500U

static uint8_t s_skip_counter = 0;

bool rev_limiter_injection_allowed(uint8_t cylinder, uint16_t rpm)
{
    float rpm_limit_f = 8000.0f;
    calibration_get(CAL_ID_RPM_LIMIT, &rpm_limit_f);
    uint16_t rpm_limit = (uint16_t)rpm_limit_f;

    if (rpm < rpm_limit)
        return true;  /* under limit — all cylinders fire */

    uint16_t over = rpm - rpm_limit;

    /* Determine how many cylinders to skip per revolution */
    uint8_t skip_count = (over >= SOFT_CUT_2_OVER) ? 2U : 1U;

    /* Round-robin: skip this cylinder if its index is in the skip window */
    bool skip = (cylinder < skip_count);

    (void)s_skip_counter;
    return !skip;
}

bool rev_limiter_active(uint16_t rpm)
{
    float rpm_limit_f = 8000.0f;
    calibration_get(CAL_ID_RPM_LIMIT, &rpm_limit_f);
    return rpm >= (uint16_t)rpm_limit_f;
}
